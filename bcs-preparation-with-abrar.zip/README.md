# BCS Preparation With Abrar

**BCS Preparation With Abrar** is an educational learning management and course-selling web application specifically built for candidates preparing for the Bangladesh Civil Service (BCS) Preliminary and Written examinations.

Developed for instructor **Abrar**, the platform features organized video lectures, Google Drive class notes, subject-wise curriculum navigation, WhatsApp click-to-chat inquiry tracking, dual payment support (WhatsApp/Manual bKash/Nagad and Online Gateway), student progress tracking, and a 16-section Admin Panel.

---

## Key Features

- **Full BPSC Syllabus Coverage**: Pre-seeded with all 11 core BCS subjects (Bangla Grammar, Bangla Literature, English Language, English Literature, Mathematics, Bangladesh Affairs, International Affairs, General Science, ICT, Ethics, Geography).
- **Dual Payment Workflow**:
  - **Method A (WhatsApp & Manual)**: Direct WhatsApp click-to-chat with pre-filled course title & ID, followed by manual bKash/Nagad TrxID submission for admin review and approval.
  - **Method B (Online Payment)**: Automated checkout with server-side validation logic and instant automatic enrollment.
- **WhatsApp Inquiry Tracking**: Every click-to-chat inquiry is logged into the `course_inquiries` database table for lead tracking (New, Contacted, Awaiting Payment, Payment Confirmed, Access Granted, Closed).
- **Embedded Player & Drive Handnotes**: Clean YouTube embed handling and Google Drive lecture notes preview.
- **Granular Access Control**: Super Admin can grant or revoke access at Course, Subject, Chapter, or Lecture levels.
- **16-Section Admin Panel**:
  1. Overview (Real database statistics & revenue)
  2. Subjects
  3. Chapters & Topics
  4. Lectures (YouTube URL, Drive notes, exam type, preview toggle)
  5. Courses & Packages (BDT pricing & features)
  6. Batches
  7. Students & Profiles
  8. Course Enrollments
  9. Granular Access Control
  10. Payments & TrxID Verification
  11. WhatsApp Inquiries
  12. Coupons & Discounts
  13. Announcements
  14. Analytics & CSV Exports
  15. Website Settings (WhatsApp number, merchant numbers, branding)
  16. Security & Activity Logs

---

## Technology Stack

- **Frontend**: React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons
- **Backend & Database**: Supabase PostgreSQL, Supabase Auth, Row Level Security (RLS)
- **Deployment**: Netlify (configured via `netlify.toml` and `public/_redirects`)

---

## Getting Started

### 1. Installation

```bash
npm install
npm run dev
```

### 2. Environment Variables

Create a `.env` file from `.env.example`:

```env
# Supabase Database & Auth (From your Supabase Project Settings -> API)
VITE_SUPABASE_URL="https://your-project.supabase.co"
VITE_SUPABASE_ANON_KEY="your-anon-public-key"

# Official Platform Contact
VITE_WHATSAPP_NUMBER="8801758898767"
```

### 3. Supabase Database Migration

1. Create a project at [supabase.com](https://supabase.com).
2. Go to the **SQL Editor** in the Supabase Dashboard.
3. Open `supabase/migrations/20260101_init_bcs_platform.sql` (or copy directly from the Admin Panel -> Reports & Analytics tab).
4. Run the query to create all tables, indexes, and Row Level Security (RLS) policies.

### 4. Netlify Deployment

- The project is pre-configured with `netlify.toml` and `public/_redirects` to handle single-page application (SPA) routing.
- Set build command to `npm run build` and publish directory to `dist`.
- Add `VITE_SUPABASE_URL` and `VITE_SUPABASE_ANON_KEY` in Netlify Environment Variables.

---

## Default Administrator Account

- **Name**: Abrar (Super Admin)
- **Email**: `abrar@bcsprepabrar.com`
- **WhatsApp**: `01758898767`
