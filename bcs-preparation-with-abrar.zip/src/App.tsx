import React, { useState, useEffect } from 'react';
import { DatabaseService, subscribeToDatabase } from './services/db';
import { UserProfile, Course, Lecture } from './types';
import { Navbar } from './components/Navbar';
import { Footer } from './components/Footer';
import { CheckoutModal } from './components/CheckoutModal';
import { LecturePlayerModal } from './components/LecturePlayerModal';
import { AccessRequestModal } from './components/AccessRequestModal';

import { HomePage } from './pages/HomePage';
import { CoursesPage } from './pages/CoursesPage';
import { CourseDetailPage } from './pages/CourseDetailPage';
import { SubjectsPage } from './pages/SubjectsPage';
import { SubjectDetailPage } from './pages/SubjectDetailPage';
import { FreeDemoPage } from './pages/FreeDemoPage';
import { StudentDashboard } from './pages/StudentDashboard';
import { AuthPages } from './pages/AuthPages';
import { PricingPage, ContactPage, TermsPage, PrivacyPage } from './pages/PricingContactLegal';
import { AdminPanel } from './pages/AdminPanel';

export function App() {
  const [currentView, setCurrentView] = useState<string>('home');
  const [selectedEntityId, setSelectedEntityId] = useState<string | undefined>(undefined);
  const [, setDbVersion] = useState<number>(0);

  // Active user & language
  const currentUser = DatabaseService.getCurrentUser();
  const language = DatabaseService.getLanguage();

  // Modals
  const [checkoutModal, setCheckoutModal] = useState<{ open: boolean; course: Course | null }>({
    open: false,
    course: null
  });

  const [lectureModal, setLectureModal] = useState<{ open: boolean; lecture: Lecture | null }>({
    open: false,
    lecture: null
  });

  const [requestModal, setRequestModal] = useState<{ open: boolean; course: Course | null }>({
    open: false,
    course: null
  });

  // Re-render when database updates
  useEffect(() => {
    const unsubscribe = subscribeToDatabase(() => {
      setDbVersion(v => v + 1);
    });
    return unsubscribe;
  }, []);

  const handleNavigate = (view: string, id?: string) => {
    setCurrentView(view);
    setSelectedEntityId(id);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleOpenCheckout = (course: Course) => {
    setCheckoutModal({ open: true, course });
  };

  const handleOpenWhatsAppModal = (course: Course) => {
    // Open checkout modal in WhatsApp tab
    setCheckoutModal({ open: true, course });
  };

  const handleOpenLecture = (lecture: Lecture) => {
    // Record lecture opened
    if (currentUser.id) {
      DatabaseService.recordLectureOpened(currentUser.id, lecture.id);
    }
    setLectureModal({ open: true, lecture });
  };

  const handleOpenAccessRequest = (course: Course) => {
    setRequestModal({ open: true, course });
  };

  // If in admin view, render AdminPanel directly with back button
  if (currentView === 'admin') {
    return (
      <AdminPanel
        currentUser={currentUser}
        onNavigateHome={() => handleNavigate('home')}
      />
    );
  }

  return (
    <div className="min-h-screen flex flex-col bg-slate-50 text-slate-900 selection:bg-teal-500 selection:text-white">
      {/* Universal Top Navigation */}
      <Navbar
        currentView={currentView}
        onNavigate={handleNavigate}
        currentUser={currentUser}
        language={language}
        onLanguageChange={lang => DatabaseService.setLanguage(lang)}
      />

      {/* Main Content Area */}
      <main className="flex-1">
        {currentView === 'home' && (
          <HomePage
            onNavigate={handleNavigate}
            onOpenCheckout={handleOpenCheckout}
            onOpenWhatsAppModal={handleOpenWhatsAppModal}
            onOpenLecture={handleOpenLecture}
            currentUser={currentUser}
          />
        )}

        {currentView === 'courses' && (
          <CoursesPage
            onNavigate={handleNavigate}
            onOpenCheckout={handleOpenCheckout}
            onOpenWhatsAppModal={handleOpenWhatsAppModal}
            currentUser={currentUser}
          />
        )}

        {currentView === 'course-detail' && selectedEntityId && (
          <CourseDetailPage
            courseId={selectedEntityId}
            onBack={() => handleNavigate('courses')}
            onOpenCheckout={handleOpenCheckout}
            onOpenWhatsAppModal={handleOpenWhatsAppModal}
            onOpenLecture={handleOpenLecture}
            onOpenAccessRequest={handleOpenAccessRequest}
            currentUser={currentUser}
          />
        )}

        {currentView === 'subjects' && (
          <SubjectsPage
            onNavigate={handleNavigate}
          />
        )}

        {currentView === 'subject-detail' && selectedEntityId && (
          <SubjectDetailPage
            subjectId={selectedEntityId}
            onBack={() => handleNavigate('subjects')}
            onOpenLecture={handleOpenLecture}
            currentUser={currentUser}
          />
        )}

        {currentView === 'free-demo' && (
          <FreeDemoPage
            onOpenLecture={handleOpenLecture}
            onNavigate={handleNavigate}
            currentUser={currentUser}
          />
        )}

        {currentView === 'dashboard' && (
          <StudentDashboard
            currentUser={currentUser}
            onNavigate={handleNavigate}
            onOpenLecture={handleOpenLecture}
          />
        )}

        {(currentView === 'login' || currentView === 'register' || currentView === 'forgot-password') && (
          <AuthPages
            initialMode={currentView as any}
            onSuccess={() => handleNavigate('dashboard')}
            onSwitchMode={mode => handleNavigate(mode)}
          />
        )}

        {currentView === 'pricing' && (
          <PricingPage
            onOpenCheckout={handleOpenCheckout}
            onOpenWhatsAppModal={handleOpenWhatsAppModal}
            onNavigate={handleNavigate}
          />
        )}

        {currentView === 'contact' && <ContactPage />}
        {currentView === 'terms' && <TermsPage />}
        {currentView === 'privacy' && <PrivacyPage />}
      </main>

      {/* Footer */}
      <Footer onNavigate={handleNavigate} language={language} />

      {/* Checkout Modal (Dual Payment: WhatsApp & Online Gateway) */}
      {checkoutModal.course && (
        <CheckoutModal
          course={checkoutModal.course}
          isOpen={checkoutModal.open}
          onClose={() => setCheckoutModal({ open: false, course: null })}
          currentUser={currentUser}
          onSuccess={() => {
            setCheckoutModal({ open: false, course: null });
            handleNavigate('dashboard');
          }}
        />
      )}

      {/* Lecture Player & Notes Viewer Modal */}
      {lectureModal.lecture && (
        <LecturePlayerModal
          lecture={lectureModal.lecture}
          isOpen={lectureModal.open}
          onClose={() => setLectureModal({ open: false, lecture: null })}
          currentUser={currentUser}
          onEnrollClick={courseId => {
            setLectureModal({ open: false, lecture: null });
            handleNavigate('course-detail', courseId);
          }}
        />
      )}

      {/* Access Request Modal */}
      {requestModal.course && (
        <AccessRequestModal
          course={requestModal.course}
          currentUser={currentUser}
          isOpen={requestModal.open}
          onClose={() => setRequestModal({ open: false, course: null })}
          onSuccess={() => {
            handleNavigate('dashboard');
          }}
        />
      )}
    </div>
  );
}

export default App;
