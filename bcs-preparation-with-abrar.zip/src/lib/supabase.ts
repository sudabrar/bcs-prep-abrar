import { createClient, SupabaseClient } from '@supabase/supabase-js';

const ENV_URL = import.meta.env.VITE_SUPABASE_URL || '';
const ENV_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

const STORAGE_KEY_URL = 'bcs_custom_supabase_url_v1';
const STORAGE_KEY_KEY = 'bcs_custom_supabase_anon_key_v1';

export function getEffectiveSupabaseCredentials(): { url: string; key: string } {
  try {
    const customUrl = localStorage.getItem(STORAGE_KEY_URL) || '';
    const customKey = localStorage.getItem(STORAGE_KEY_KEY) || '';
    if (customUrl && customKey) {
      return { url: customUrl, key: customKey };
    }
  } catch {
    // fallback
  }
  return { url: ENV_URL, key: ENV_KEY };
}

export function saveCustomSupabaseCredentials(url: string, key: string): void {
  try {
    if (url && key) {
      localStorage.setItem(STORAGE_KEY_URL, url.trim());
      localStorage.setItem(STORAGE_KEY_KEY, key.trim());
    } else {
      localStorage.removeItem(STORAGE_KEY_URL);
      localStorage.removeItem(STORAGE_KEY_KEY);
    }
  } catch (err) {
    console.error('Failed to save Supabase credentials:', err);
  }
}

const credentials = getEffectiveSupabaseCredentials();

export const isSupabaseConfigured = Boolean(
  credentials.url && 
  credentials.key && 
  credentials.url.startsWith('https://') &&
  !credentials.url.includes('your-project')
);

export const supabase: SupabaseClient | null = isSupabaseConfigured
  ? createClient(credentials.url, credentials.key)
  : null;

export interface SupabaseConfigStatus {
  isConfigured: boolean;
  url: string;
  hasKey: boolean;
}

export function getSupabaseStatus(): SupabaseConfigStatus {
  const creds = getEffectiveSupabaseCredentials();
  const configured = Boolean(
    creds.url && 
    creds.key && 
    creds.url.startsWith('https://') &&
    !creds.url.includes('your-project')
  );
  return {
    isConfigured: configured,
    url: creds.url ? creds.url.replace(/^(https:\/\/[^.]+).*/, '$1.supabase.co') : 'Not connected (Local persistent fallback active)',
    hasKey: Boolean(creds.key)
  };
}

export async function testSupabaseConnection(url: string, key: string): Promise<{ success: boolean; message: string }> {
  try {
    if (!url.startsWith('https://') || !url.includes('.supabase.co')) {
      return { success: false, message: 'Invalid URL. It must be in the format: https://[project-ref].supabase.co' };
    }
    const client = createClient(url, key);
    // Ping public table or auth
    const { error } = await client.from('subjects').select('count', { count: 'exact', head: true });
    if (error && error.code !== 'PGRST116' && !error.message.includes('relation "public.subjects" does not exist')) {
      // If error is about subjects not existing yet, the connection works but migrations haven't run yet!
      return { 
        success: true, 
        message: 'Connected to Supabase project successfully! Note: You need to run the SQL migration script in your SQL Editor to create the tables.' 
      };
    }
    return { success: true, message: 'Successfully connected and verified Supabase connection!' };
  } catch (err: unknown) {
    return { success: false, message: (err as Error).message || 'Connection failed.' };
  }
}
