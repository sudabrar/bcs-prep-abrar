export type UserRole = 'super_admin' | 'content_manager' | 'student' | 'guest';

export type AccountStatus = 'pending' | 'approved' | 'suspended' | 'rejected';

export type ExamType = 'preliminary' | 'written' | 'both';

export type LectureAccessType = 
  | 'public' 
  | 'free_preview' 
  | 'approved_students' 
  | 'enrolled_students' 
  | 'selected_students' 
  | 'specific_batch' 
  | 'specific_course';

export type PaymentMethod = 'whatsapp_manual' | 'bkash' | 'nagad' | 'rocket' | 'bank';

export type PaymentStatus = 'pending' | 'verified' | 'rejected' | 'refunded';

export type InquiryStatus = 'new' | 'contacted' | 'awaiting_payment' | 'payment_confirmed' | 'access_granted' | 'closed';

export type RequestStatus = 'pending' | 'approved' | 'rejected' | 'cancelled';

export interface UserProfile {
  id: string;
  email: string;
  fullName: string;
  phone: string;
  role: UserRole;
  status: AccountStatus;
  avatarUrl?: string;
  district?: string;
  targetBcsCadre?: string;
  createdAt: string;
}

export interface Subject {
  id: string;
  titleBn: string;
  titleEn: string;
  code: string;
  description: string;
  examType: ExamType;
  orderIndex: number;
  isPublished: boolean;
  totalChapters?: number;
  totalLectures?: number;
}

export interface Chapter {
  id: string;
  subjectId: string;
  titleBn: string;
  titleEn: string;
  orderIndex: number;
  isPublished: boolean;
  topicsCount?: number;
}

export interface Topic {
  id: string;
  chapterId: string;
  titleBn: string;
  titleEn: string;
  orderIndex: number;
}

export interface Lecture {
  id: string;
  subjectId: string;
  chapterId: string;
  topicId?: string;
  courseIds: string[];
  batchIds?: string[];
  titleBn: string;
  titleEn: string;
  examType: ExamType;
  description: string;
  youtubeUrl: string;
  driveNotesUrl: string;
  thumbnailUrl?: string;
  teacherName: string;
  lectureNumber: number;
  durationMinutes: number;
  tags: string[];
  isFreePreview: boolean;
  publicationStatus: 'published' | 'draft' | 'archived';
  accessType: LectureAccessType;
  orderIndex: number;
  createdAt: string;
}

export interface Course {
  id: string;
  titleBn: string;
  titleEn: string;
  slug: string;
  category: 'complete' | 'preliminary' | 'written' | 'subject_wise';
  description: string;
  thumbnailUrl: string;
  subjectIds: string[];
  lectureIds?: string[];
  durationWeeks: number;
  regularPriceBdt: number;
  promotionalPriceBdt?: number;
  startDate?: string;
  endDate?: string;
  enrollmentStatus: 'open' | 'closed' | 'upcoming';
  features: string[];
  accessDays: number;
  isPublished: boolean;
  isFeatured: boolean;
  createdAt: string;
}

export interface Batch {
  id: string;
  courseId: string;
  name: string;
  description: string;
  startDate: string;
  endDate: string;
  maxStudents: number;
  enrolledStudentsCount: number;
  isActive: boolean;
  createdAt: string;
}

export interface Enrollment {
  id: string;
  userId: string;
  courseId: string;
  batchId?: string;
  status: 'active' | 'expired' | 'revoked' | 'pending';
  startDate: string;
  expiresAt: string;
  grantedBy: string;
  paymentId?: string;
  createdAt: string;
}

export interface StudentPermission {
  id: string;
  userId: string;
  entityType: 'course' | 'subject' | 'chapter' | 'lecture';
  entityId: string;
  isGranted: boolean;
  grantedBy: string;
  createdAt: string;
}

export interface StudentProgress {
  id: string;
  userId: string;
  lectureId: string;
  isCompleted: boolean;
  completedAt?: string;
  lastOpenedAt: string;
}

export interface Bookmark {
  id: string;
  userId: string;
  lectureId: string;
  note?: string;
  createdAt: string;
}

export interface AccessRequest {
  id: string;
  userId: string;
  userEmail: string;
  userName: string;
  userPhone: string;
  courseId: string;
  courseTitle: string;
  message?: string;
  status: RequestStatus;
  reviewedBy?: string;
  reviewedAt?: string;
  createdAt: string;
}

export interface CourseInquiry {
  id: string;
  courseId: string;
  courseTitle: string;
  userId?: string;
  contactName: string;
  contactPhone: string;
  userEmail?: string;
  message: string;
  status: InquiryStatus;
  adminNotes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Payment {
  id: string;
  userId: string;
  userEmail: string;
  courseId: string;
  courseTitle: string;
  amountBdt: number;
  currency: 'BDT';
  paymentMethod: PaymentMethod;
  transactionRef: string;
  senderPhone: string;
  verificationStatus: PaymentStatus;
  verifiedBy?: string;
  adminNotes?: string;
  createdAt: string;
  verifiedAt?: string;
}

export interface Coupon {
  id: string;
  code: string;
  discountType: 'percentage' | 'fixed';
  discountValue: number;
  minSpendBdt: number;
  maxDiscountBdt?: number;
  validFrom: string;
  validUntil: string;
  usageLimit: number;
  timesUsed: number;
  isActive: boolean;
  eligibleCourseIds?: string[];
}

export interface Announcement {
  id: string;
  title: string;
  content: string;
  targetAudience: 'all' | 'specific_course' | 'specific_batch';
  targetId?: string;
  priority: 'normal' | 'important' | 'urgent';
  isPublished: boolean;
  createdAt: string;
}

export interface SiteSettings {
  siteTitle: string;
  ownerName: string;
  phoneLocal: string;
  phoneIntl: string;
  whatsappMessageTemplate: string;
  emailContact: string;
  bkashMerchantNumber: string;
  nagadMerchantNumber: string;
  bankAccountDetails: string;
  announcementBarText: string;
  isRegistrationOpen: boolean;
  demoVideoUrl: string;
  heroHeadlineBn: string;
  heroHeadlineEn: string;
  heroSubtitleBn: string;
  heroSubtitleEn: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userEmail: string;
  action: string;
  entityType: string;
  entityId: string;
  details: string;
  createdAt: string;
}
