import React, { useState } from 'react';
import { 
  BookOpen, 
  CheckCircle, 
  Bookmark as BookmarkIcon, 
  Bell, 
  Play, 
  Clock, 
  FileText, 
  ChevronRight, 
  Send, 
  User, 
  LogOut,
  Calendar,
  AlertCircle
} from 'lucide-react';
import { Course, Lecture, UserProfile } from '../types';
import { DatabaseService } from '../services/db';

interface StudentDashboardProps {
  currentUser: UserProfile;
  onNavigate: (view: string, id?: string) => void;
  onOpenLecture: (lecture: Lecture) => void;
}

export const StudentDashboard: React.FC<StudentDashboardProps> = ({
  currentUser,
  onNavigate,
  onOpenLecture
}) => {
  const [activeTab, setActiveTab] = useState<'courses' | 'progress' | 'bookmarks' | 'announcements' | 'requests'>('courses');

  const enrollments = DatabaseService.getEnrollments(currentUser.id);
  const allCourses = DatabaseService.getCourses();
  const allLectures = DatabaseService.getLectures();
  const progressList = DatabaseService.getProgress(currentUser.id);
  const bookmarks = DatabaseService.getBookmarks(currentUser.id);
  const announcements = DatabaseService.getAnnouncements();
  const requests = DatabaseService.getAccessRequests().filter(r => r.userId === currentUser.id);

  // Enrolled courses objects
  const enrolledCourses = allCourses.filter(c => enrollments.some(e => e.courseId === c.id));

  // Completed count
  const completedCount = progressList.filter(p => p.isCompleted).length;

  // Bookmarked lectures
  const bookmarkedLectures = allLectures.filter(l => bookmarks.some(b => b.lectureId === l.id));

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Student Welcome Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-6 shadow-xs">
        <div className="flex items-center gap-4">
          <div className="w-14 h-14 rounded-full bg-blue-900 text-white font-bold text-xl flex items-center justify-center shrink-0">
            {currentUser.fullName.charAt(0)}
          </div>
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <h1 className="text-xl font-bold text-slate-900">{currentUser.fullName}</h1>
              <span className="text-[11px] font-semibold px-2 py-0.5 rounded bg-emerald-50 text-emerald-700">
                {currentUser.status === 'approved' ? 'ভেরিফাইড শিক্ষার্থী' : 'অনুমোদন প্রক্রিয়াধীন'}
              </span>
            </div>
            <p className="text-xs text-slate-500 font-mono">
              {currentUser.email} · {currentUser.phone || 'মোবাইল যুক্ত নেই'}
            </p>
            {currentUser.targetBcsCadre && (
              <p className="text-xs text-teal-800 font-medium">
                টার্গেট ক্যাডার: {currentUser.targetBcsCadre}
              </p>
            )}
          </div>
        </div>

        {/* Quick Progress Stats */}
        <div className="flex items-center gap-6 border-t md:border-t-0 pt-4 md:pt-0 border-slate-100 text-xs w-full md:w-auto justify-between md:justify-end">
          <div>
            <div className="text-xl font-bold font-mono text-blue-950 tabular-nums">{enrolledCourses.length}</div>
            <div className="text-slate-400">নিবন্ধিত কোর্স</div>
          </div>
          <div>
            <div className="text-xl font-bold font-mono text-emerald-600 tabular-nums">{completedCount}</div>
            <div className="text-slate-400">পড়া সম্পন্ন লেকচার</div>
          </div>
          <div>
            <div className="text-xl font-bold font-mono text-amber-600 tabular-nums">{bookmarkedLectures.length}</div>
            <div className="text-slate-400">বুকমার্ক লেকচার</div>
          </div>
        </div>
      </div>

      {/* Tabs */}
      <div className="border-b border-slate-200">
        <nav className="flex space-x-6 overflow-x-auto text-xs font-semibold text-slate-600">
          <button
            onClick={() => setActiveTab('courses')}
            className={`pb-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'courses' ? 'border-blue-900 text-blue-900' : 'border-transparent hover:text-slate-900'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>আমার কোর্সসমূহ ({enrolledCourses.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('progress')}
            className={`pb-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'progress' ? 'border-blue-900 text-blue-900' : 'border-transparent hover:text-slate-900'
            }`}
          >
            <CheckCircle className="w-4 h-4" />
            <span>শেখার অগ্রগতি ({completedCount})</span>
          </button>

          <button
            onClick={() => setActiveTab('bookmarks')}
            className={`pb-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'bookmarks' ? 'border-blue-900 text-blue-900' : 'border-transparent hover:text-slate-900'
            }`}
          >
            <BookmarkIcon className="w-4 h-4" />
            <span>বুকমার্ক লেকচার ({bookmarkedLectures.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('announcements')}
            className={`pb-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'announcements' ? 'border-blue-900 text-blue-900' : 'border-transparent hover:text-slate-900'
            }`}
          >
            <Bell className="w-4 h-4" />
            <span>নোটিশ ও ঘোষণা ({announcements.length})</span>
          </button>

          <button
            onClick={() => setActiveTab('requests')}
            className={`pb-3 border-b-2 whitespace-nowrap transition-colors flex items-center gap-2 ${
              activeTab === 'requests' ? 'border-blue-900 text-blue-900' : 'border-transparent hover:text-slate-900'
            }`}
          >
            <Send className="w-4 h-4" />
            <span>অ্যাক্সেস রিকোয়েস্ট ({requests.length})</span>
          </button>
        </nav>
      </div>

      {/* Tab Panels */}
      {activeTab === 'courses' && (
        <div className="space-y-6">
          {enrolledCourses.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {enrolledCourses.map(course => {
                const courseLectures = allLectures.filter(l => l.courseIds.includes(course.id));
                const completedInCourse = courseLectures.filter(l => 
                  progressList.some(p => p.lectureId === l.id && p.isCompleted)
                ).length;
                const progressPct = courseLectures.length > 0 ? Math.round((completedInCourse / courseLectures.length) * 100) : 0;

                return (
                  <div key={course.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs flex flex-col justify-between">
                    <div className="p-5 space-y-3">
                      <div className="text-[11px] font-mono text-slate-400 capitalize">
                        {course.category.replace('_', ' ')}
                      </div>
                      <h3 className="text-sm font-bold text-slate-900 line-clamp-2">
                        {course.titleBn}
                      </h3>
                      <p className="text-xs text-slate-500 line-clamp-2">
                        {course.description}
                      </p>

                      {/* Progress Bar */}
                      <div className="space-y-1.5 pt-2">
                        <div className="flex justify-between text-xs text-slate-600">
                          <span>অগ্রগতি:</span>
                          <span className="font-mono font-bold text-blue-900 tabular-nums">{progressPct}%</span>
                        </div>
                        <div className="w-full bg-slate-100 rounded-full h-2 overflow-hidden">
                          <div className="bg-teal-500 h-2 rounded-full transition-all" style={{ width: `${progressPct}%` }}></div>
                        </div>
                        <div className="text-[11px] text-slate-400 text-right">
                          {completedInCourse} / {courseLectures.length} লেকচার সম্পন্ন
                        </div>
                      </div>
                    </div>

                    <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between">
                      <button
                        onClick={() => onNavigate('course-detail', course.id)}
                        className="w-full py-2 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                      >
                        <Play className="w-3.5 h-3.5" />
                        <span>পড়া শুরু / রিজিউম করুন</span>
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          ) : (
            <div className="p-12 text-center bg-white rounded-xl border border-slate-200 space-y-4">
              <BookOpen className="w-12 h-12 text-slate-300 mx-auto" />
              <div className="space-y-1">
                <h3 className="text-sm font-bold text-slate-800">আপনি এখনও কোনো কোর্সে ভর্তি হননি</h3>
                <p className="text-xs text-slate-500 max-w-sm mx-auto">
                  বিসিএস প্রিলিমিনারি ও লিখিত সিলেবাসের সেরা প্রস্তুতির জন্য আমাদের কোর্সগুলো ঘুরে দেখুন।
                </p>
              </div>
              <button
                onClick={() => onNavigate('courses')}
                className="px-5 py-2.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold rounded-lg transition-colors"
              >
                কোর্সসমূহ ঘুরে দেখুন
              </button>
            </div>
          )}
        </div>
      )}

      {/* Progress Tab */}
      {activeTab === 'progress' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-baseline justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900">সম্পন্ন করা লেকচারের তালিকা</h3>
            <span className="text-xs font-mono text-slate-500">মোট: {completedCount}টি</span>
          </div>

          {completedCount > 0 ? (
            <div className="divide-y divide-slate-100">
              {progressList.filter(p => p.isCompleted).map(prog => {
                const lec = allLectures.find(l => l.id === prog.lectureId);
                if (!lec) return null;
                return (
                  <div key={prog.id} className="py-3 flex items-center justify-between gap-4">
                    <div className="flex items-center gap-3 truncate">
                      <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0" />
                      <div className="truncate">
                        <h4 className="text-xs font-semibold text-slate-900 truncate">{lec.titleBn}</h4>
                        <p className="text-[11px] text-slate-400">
                          {prog.completedAt ? `সম্পন্ন হয়েছে: ${new Date(prog.completedAt).toLocaleDateString()}` : 'সম্পন্ন'}
                        </p>
                      </div>
                    </div>
                    <button
                      onClick={() => onOpenLecture(lec)}
                      className="px-3 py-1 bg-slate-100 hover:bg-slate-200 text-slate-700 text-xs font-medium rounded transition-colors shrink-0"
                    >
                      পুনরায় দেখুন
                    </button>
                  </div>
                );
              })}
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic py-6 text-center">
              কোনো লেকচার পড়া শেষ হিসেবে মার্ক করা হয়নি। লেকচার দেখার পর "পড়া শেষ" বোতামে চাপ দিন।
            </p>
          )}
        </div>
      )}

      {/* Bookmarks Tab */}
      {activeTab === 'bookmarks' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <h3 className="text-sm font-bold text-slate-900 border-b border-slate-100 pb-3">
            সংরক্ষিত (বুকমার্ক) লেকচার
          </h3>

          {bookmarkedLectures.length > 0 ? (
            <div className="divide-y divide-slate-100">
              {bookmarkedLectures.map(lec => (
                <div key={lec.id} className="py-3 flex items-center justify-between gap-4">
                  <div className="flex items-center gap-3 truncate">
                    <BookmarkIcon className="w-4 h-4 text-amber-500 fill-amber-500 shrink-0" />
                    <div className="truncate">
                      <h4 className="text-xs font-semibold text-slate-900 truncate">{lec.titleBn}</h4>
                      <p className="text-[11px] text-slate-400">{lec.durationMinutes} মিনিট · {lec.teacherName}</p>
                    </div>
                  </div>
                  <button
                    onClick={() => onOpenLecture(lec)}
                    className="px-3 py-1 bg-blue-900 text-white text-xs font-medium rounded hover:bg-blue-800 transition-colors shrink-0"
                  >
                    প্লে করুন
                  </button>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic py-6 text-center">
              আপনার কোনো বুকমার্ক লেকচার নেই। গুরুত্বপূর্ণ ক্লাস রিভিশনের জন্য বুকমার্ক আইকনে ক্লিক করুন।
            </p>
          )}
        </div>
      )}

      {/* Announcements Tab */}
      {activeTab === 'announcements' && (
        <div className="space-y-4">
          {announcements.map(ann => (
            <div key={ann.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-2">
              <div className="flex items-center justify-between">
                <span className={`text-[10px] font-semibold uppercase px-2 py-0.5 rounded ${
                  ann.priority === 'urgent' ? 'bg-rose-100 text-rose-800' : ann.priority === 'important' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                }`}>
                  {ann.priority}
                </span>
                <span className="text-[11px] font-mono text-slate-400">
                  {new Date(ann.createdAt).toLocaleDateString()}
                </span>
              </div>
              <h3 className="text-sm font-bold text-slate-900">{ann.title}</h3>
              <p className="text-xs text-slate-600 leading-relaxed whitespace-pre-line">{ann.content}</p>
            </div>
          ))}
        </div>
      )}

      {/* Requests Tab */}
      {activeTab === 'requests' && (
        <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4">
          <div className="flex items-baseline justify-between border-b border-slate-100 pb-3">
            <h3 className="text-sm font-bold text-slate-900">কোর্স অ্যাক্সেস রিকোয়েস্টের অবস্থা</h3>
            <span className="text-xs text-slate-500 font-mono">মোট: {requests.length}টি</span>
          </div>

          {requests.length > 0 ? (
            <div className="divide-y divide-slate-100">
              {requests.map(req => (
                <div key={req.id} className="py-3.5 space-y-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-slate-900">{req.courseTitle}</span>
                    <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                      req.status === 'approved' ? 'bg-emerald-100 text-emerald-800' : req.status === 'rejected' ? 'bg-rose-100 text-rose-800' : 'bg-amber-100 text-amber-800'
                    }`}>
                      {req.status}
                    </span>
                  </div>
                  {req.message && <p className="text-xs text-slate-500">{req.message}</p>}
                  <p className="text-[11px] font-mono text-slate-400">
                    আবেদনের তারিখ: {new Date(req.createdAt).toLocaleString()}
                  </p>
                </div>
              ))}
            </div>
          ) : (
            <p className="text-xs text-slate-500 italic py-6 text-center">
              আপনার কোনো পেন্ডিং অ্যাক্সেস রিকোয়েস্ট নেই।
            </p>
          )}
        </div>
      )}
    </div>
  );
};
