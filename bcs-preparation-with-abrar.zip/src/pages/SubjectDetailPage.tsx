import React from 'react';
import { ArrowLeft, BookOpen, Layers, Play, Lock, FileText } from 'lucide-react';
import { Subject, Lecture, UserProfile } from '../types';
import { DatabaseService } from '../services/db';

interface SubjectDetailPageProps {
  subjectId: string;
  onBack: () => void;
  onOpenLecture: (lecture: Lecture) => void;
  currentUser: UserProfile;
}

export const SubjectDetailPage: React.FC<SubjectDetailPageProps> = ({
  subjectId,
  onBack,
  onOpenLecture,
  currentUser
}) => {
  const subject = DatabaseService.getSubjectById(subjectId);
  const chapters = DatabaseService.getChapters(subjectId);
  const allLectures = DatabaseService.getLectures();
  const subjectLectures = allLectures.filter(l => l.subjectId === subjectId);

  if (!subject) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-xl font-bold text-slate-800">বিষয়টি পাওয়া যায়নি</h2>
        <button onClick={onBack} className="text-xs font-semibold text-blue-900 underline">
          সকল বিষয়ে ফিরে যান
        </button>
      </div>
    );
  }

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-blue-900 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>সকল বিষয়ের সিলেবাসে ফিরে যান</span>
      </button>

      {/* Subject Header */}
      <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-3">
        <div className="flex items-center gap-2 text-xs text-slate-500">
          <span className="font-mono font-bold text-blue-900">{subject.code}</span>
          <span aria-hidden="true">·</span>
          <span className="capitalize">{subject.examType === 'both' ? 'প্রিলিমিনারি ও লিখিত উভয়' : subject.examType}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">{chapters.length}টি অধ্যায়</span>
        </div>

        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">
          {subject.titleBn}
        </h1>
        <p className="text-xs font-semibold text-slate-500 uppercase tracking-wider">
          {subject.titleEn}
        </p>

        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed pt-2">
          {subject.description}
        </p>
      </div>

      {/* Chapters Accordion / List */}
      <div className="space-y-6">
        <h2 className="text-lg font-bold text-slate-900">
          অধ্যায় ও লেকচার বিন্যাস ({chapters.length}টি অধ্যায়)
        </h2>

        {chapters.length > 0 ? (
          <div className="space-y-4">
            {chapters.map((ch, idx) => {
              const chapterLectures = subjectLectures.filter(l => l.chapterId === ch.id);
              const topics = DatabaseService.getTopics(ch.id);

              return (
                <div key={ch.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-4">
                  <div className="flex items-baseline justify-between border-b border-slate-100 pb-3">
                    <div className="space-y-0.5">
                      <div className="text-[11px] font-mono text-teal-700 font-semibold">
                        অধ্যায় {idx + 1}
                      </div>
                      <h3 className="text-base font-bold text-slate-900">
                        {ch.titleBn}
                      </h3>
                      <p className="text-xs text-slate-500">{ch.titleEn}</p>
                    </div>
                    <span className="text-xs font-mono text-slate-400">
                      {chapterLectures.length} লেকচার
                    </span>
                  </div>

                  {/* Topics List if any */}
                  {topics.length > 0 && (
                    <div className="bg-slate-50/70 p-3 rounded-lg text-xs space-y-1">
                      <span className="font-semibold text-slate-700 block text-[11px]">গুরুত্বপূর্ণ টপিকসমূহ:</span>
                      <div className="flex flex-wrap gap-2 text-slate-600">
                        {topics.map(t => (
                          <span key={t.id} className="inline-flex items-center gap-1 bg-white px-2 py-0.5 rounded border border-slate-200 text-[11px]">
                            • {t.titleBn}
                          </span>
                        ))}
                      </div>
                    </div>
                  )}

                  {/* Lectures in this chapter */}
                  {chapterLectures.length > 0 ? (
                    <div className="space-y-2 pt-2">
                      {chapterLectures.map(lec => {
                        const canAccess = DatabaseService.canUserAccessLecture(lec, currentUser).allowed;
                        return (
                          <div
                            key={lec.id}
                            onClick={() => onOpenLecture(lec)}
                            className="p-3 rounded-lg border border-slate-100 hover:border-slate-300 bg-slate-50/50 hover:bg-white flex items-center justify-between gap-3 cursor-pointer transition-colors group"
                          >
                            <div className="flex items-center gap-3 truncate">
                              <div className={`w-7 h-7 rounded-md flex items-center justify-center shrink-0 text-xs font-bold ${
                                canAccess ? 'bg-teal-100 text-teal-800' : 'bg-slate-200 text-slate-600'
                              }`}>
                                {canAccess ? <Play className="w-3.5 h-3.5 fill-teal-700" /> : <Lock className="w-3.5 h-3.5" />}
                              </div>
                              <div className="truncate">
                                <h4 className="text-xs font-semibold text-slate-900 group-hover:text-blue-900 transition-colors truncate">
                                  {lec.titleBn}
                                </h4>
                                <div className="text-[11px] text-slate-400">
                                  {lec.durationMinutes} মিনিট · {lec.teacherName}
                                  {lec.isFreePreview && <span className="text-teal-700 font-semibold ml-1">· ফ্রি ডেমো</span>}
                                </div>
                              </div>
                            </div>

                            <span className="text-xs font-semibold text-blue-900 group-hover:underline shrink-0">
                              {canAccess ? 'প্লে করুন' : 'লক করা'}
                            </span>
                          </div>
                        );
                      })}
                    </div>
                  ) : (
                    <p className="text-xs text-slate-400 italic">এই অধ্যায়ের লেকচার রেকর্ডিং চলমান রয়েছে।</p>
                  )}
                </div>
              );
            })}
          </div>
        ) : (
          <div className="p-8 text-center bg-white rounded-xl border border-slate-200 text-xs text-slate-500">
            এই বিষয়ের অধ্যায়সমূহ শিডিউল করা হচ্ছে।
          </div>
        )}
      </div>
    </div>
  );
};
