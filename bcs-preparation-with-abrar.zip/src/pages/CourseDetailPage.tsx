import React from 'react';
import { 
  ArrowLeft, 
  Check, 
  Clock, 
  Calendar, 
  BookOpen, 
  CreditCard, 
  MessageCircle, 
  Play, 
  FileText, 
  Lock, 
  HelpCircle,
  ExternalLink
} from 'lucide-react';
import { Course, Lecture, UserProfile } from '../types';
import { DatabaseService } from '../services/db';

interface CourseDetailPageProps {
  courseId: string;
  onBack: () => void;
  onOpenCheckout: (course: Course) => void;
  onOpenWhatsAppModal: (course: Course) => void;
  onOpenLecture: (lecture: Lecture) => void;
  onOpenAccessRequest: (course: Course) => void;
  currentUser: UserProfile;
}

export const CourseDetailPage: React.FC<CourseDetailPageProps> = ({
  courseId,
  onBack,
  onOpenCheckout,
  onOpenWhatsAppModal,
  onOpenLecture,
  onOpenAccessRequest,
  currentUser
}) => {
  const course = DatabaseService.getCourseById(courseId);
  const subjects = DatabaseService.getSubjects();
  const allLectures = DatabaseService.getLectures();
  const enrollments = DatabaseService.getEnrollments(currentUser.id);
  const settings = DatabaseService.getSettings();

  if (!course) {
    return (
      <div className="max-w-4xl mx-auto px-4 py-16 text-center space-y-4">
        <h2 className="text-xl font-bold text-slate-800">কোর্সটি খুঁজে পাওয়া যায়নি</h2>
        <button onClick={onBack} className="text-xs font-semibold text-blue-900 underline">
          সকল কোর্সে ফিরে যান
        </button>
      </div>
    );
  }

  const isEnrolled = enrollments.some(e => e.courseId === course.id);
  const includedSubjects = subjects.filter(s => course.subjectIds.includes(s.id));
  const courseLectures = allLectures.filter(l => l.courseIds.includes(course.id));
  const currentPrice = course.promotionalPriceBdt || course.regularPriceBdt;
  const hasDiscount = Boolean(course.promotionalPriceBdt && course.promotionalPriceBdt < course.regularPriceBdt);

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Back Button */}
      <button
        onClick={onBack}
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-slate-600 hover:text-blue-900 transition-colors"
      >
        <ArrowLeft className="w-4 h-4" />
        <span>সকল কোর্সে ফিরে যান</span>
      </button>

      {/* Main Header Split */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-start">
        {/* Left Column (8 cols): Title, Description, Included Subjects & Lectures */}
        <div className="lg:col-span-8 space-y-8">
          <div>
            {/* Clean unboxed metadata line */}
            <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
              <span className="capitalize">{course.category.replace('_', ' ')}</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">{course.durationWeeks} সপ্তাহ</span>
              <span aria-hidden="true">·</span>
              <span className="font-mono tabular-nums">{course.accessDays} দিন অ্যাক্সেস</span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 leading-tight mb-4">
              {course.titleBn}
            </h1>
            <p className="text-sm text-slate-600 leading-relaxed whitespace-pre-line">
              {course.description}
            </p>
          </div>

          {/* Features */}
          {course.features && course.features.length > 0 && (
            <div className="bg-slate-50 rounded-xl p-5 border border-slate-200">
              <h3 className="text-xs font-semibold text-slate-900 uppercase tracking-wider mb-3">
                কোর্সের বিশেষ সুবিধাসমূহ
              </h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-2.5">
                {course.features.map((feat, i) => (
                  <div key={i} className="flex items-start gap-2 text-xs text-slate-700">
                    <Check className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                    <span>{feat}</span>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Included Subjects */}
          <div className="space-y-3">
            <h3 className="text-base font-bold text-slate-900">
              অন্তর্ভুক্ত বিষয়সমূহ ({includedSubjects.length}টি বিষয়)
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {includedSubjects.map(sub => (
                <div key={sub.id} className="p-3 bg-white rounded-lg border border-slate-200 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-semibold text-slate-900">{sub.titleBn}</span>
                    <span className="text-slate-400 block text-[11px]">{sub.titleEn}</span>
                  </div>
                  <span className="font-mono text-slate-500 text-[11px]">{sub.code}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Lecture Syllabus List */}
          <div className="space-y-4 pt-4 border-t border-slate-200">
            <div className="flex items-baseline justify-between">
              <h3 className="text-base font-bold text-slate-900">
                ক্লাস সূচি ও লেকচার তালিকা ({courseLectures.length}টি লেকচার)
              </h3>
              <span className="text-xs text-slate-500">
                {courseLectures.filter(l => l.isFreePreview).length}টি ফ্রি ডেমো ক্লাস
              </span>
            </div>

            <div className="space-y-2">
              {courseLectures.map(lecture => {
                const canAccess = DatabaseService.canUserAccessLecture(lecture, currentUser).allowed;
                return (
                  <div
                    key={lecture.id}
                    onClick={() => onOpenLecture(lecture)}
                    className="p-3.5 bg-white rounded-lg border border-slate-200 hover:border-slate-300 flex items-center justify-between gap-4 cursor-pointer transition-colors group"
                  >
                    <div className="flex items-center gap-3 truncate">
                      <div className={`w-7 h-7 rounded-md flex items-center justify-center shrink-0 text-xs font-bold ${
                        canAccess ? 'bg-teal-50 text-teal-700' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {canAccess ? <Play className="w-3.5 h-3.5 fill-teal-600" /> : <Lock className="w-3.5 h-3.5" />}
                      </div>
                      <div className="truncate">
                        <h4 className="text-xs font-semibold text-slate-900 group-hover:text-blue-900 transition-colors truncate">
                          {lecture.titleBn}
                        </h4>
                        <div className="flex items-center gap-2 text-[11px] text-slate-400">
                          <span className="font-mono">{lecture.durationMinutes} মিনিট</span>
                          <span aria-hidden="true">·</span>
                          <span>{lecture.teacherName}</span>
                          {lecture.isFreePreview && (
                            <>
                              <span aria-hidden="true">·</span>
                              <span className="text-teal-600 font-medium">ফ্রি ডেমো</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-2 shrink-0">
                      {lecture.driveNotesUrl && (
                        <span className="text-[11px] text-slate-500 hidden sm:flex items-center gap-1">
                          <FileText className="w-3 h-3" />
                          <span>নোটস</span>
                        </span>
                      )}
                      <span className="text-xs font-semibold text-blue-900 group-hover:underline">
                        {canAccess ? 'ক্লাস দেখুন' : 'লক করা'}
                      </span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* Right Column (4 cols): Pricing & Action Card (Sticky) */}
        <div className="lg:col-span-4 lg:sticky lg:top-24 space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 shadow-md p-6 space-y-5">
            {/* Thumbnail Preview */}
            <div className="aspect-16/9 rounded-lg overflow-hidden bg-slate-100">
              <img
                src={course.thumbnailUrl}
                alt={course.titleBn}
                referrerPolicy="no-referrer"
                className="w-full h-full object-cover"
              />
            </div>

            {/* Price Box */}
            <div className="border-b border-slate-100 pb-4">
              <div className="flex items-baseline justify-between mb-1">
                <span className="text-xs text-slate-500 font-medium">কোর্স ফি:</span>
                <div className="flex items-baseline gap-2">
                  {hasDiscount && (
                    <span className="text-sm text-slate-400 line-through font-mono tabular-nums">
                      ৳{course.regularPriceBdt.toLocaleString()}
                    </span>
                  )}
                  <span className="text-3xl font-extrabold text-blue-950 font-mono tabular-nums">
                    ৳{currentPrice.toLocaleString()}
                  </span>
                </div>
              </div>
              <p className="text-[11px] text-slate-500 text-right">
                এককালীন পরিশোধ · মেয়াদ {course.accessDays} দিন
              </p>
            </div>

            {/* Primary Action Buttons */}
            {isEnrolled ? (
              <div className="p-3 bg-emerald-50 border border-emerald-200 rounded-lg text-center space-y-1">
                <p className="text-xs font-bold text-emerald-900">আপনি এই কোর্সে নিবন্ধিত আছেন</p>
                <p className="text-[11px] text-emerald-700">বাম পাশের তালিকা থেকে যেকোনো লেকচার চালু করুন।</p>
              </div>
            ) : (
              <div className="space-y-2.5">
                <button
                  onClick={() => onOpenWhatsAppModal(course)}
                  className="w-full py-3 px-4 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg flex items-center justify-center gap-2 shadow-xs transition-colors"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>হোয়াটসঅ্যাপে কিনুন ও ফি জমা দিন (bKash / Nagad)</span>
                </button>

                <button
                  onClick={() => onOpenAccessRequest(course)}
                  className="w-full py-2.5 px-4 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>অ্যাক্সেস রিকোয়েস্ট পাঠান (Submit Access Request)</span>
                </button>
              </div>
            )}

            {/* Support guarantee */}
            <div className="pt-2 text-xs text-slate-500 space-y-1.5">
              <p className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                <span>সকল ডিভাইসে ২৪/৭ ক্লাস অ্যাক্সেস</span>
              </p>
              <p className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                <span>ডাউনলোডযোগ্য গুগল ড্রাইভ হ্যান্ডনোট</span>
              </p>
              <p className="flex items-center gap-1.5">
                <Check className="w-3.5 h-3.5 text-teal-600 shrink-0" />
                <span>হোয়াটসঅ্যাপে মেন্টরিং ও ডাউট সলভ</span>
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
