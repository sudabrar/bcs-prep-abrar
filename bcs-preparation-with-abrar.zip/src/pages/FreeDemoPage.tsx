import React from 'react';
import { Play, FileText, Clock, ExternalLink, BookOpen, ShieldCheck } from 'lucide-react';
import { Lecture, UserProfile } from '../types';
import { DatabaseService } from '../services/db';

interface FreeDemoPageProps {
  onOpenLecture: (lecture: Lecture) => void;
  onNavigate: (view: string) => void;
  currentUser: UserProfile;
}

export const FreeDemoPage: React.FC<FreeDemoPageProps> = ({
  onOpenLecture,
  onNavigate,
  currentUser
}) => {
  const lectures = DatabaseService.getLectures();
  const demoLectures = lectures.filter(l => l.isFreePreview || l.accessType === 'public' || l.accessType === 'free_preview');

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      {/* Header */}
      <div className="border-b border-slate-200 pb-6">
        <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
          বিনা মূল্যে যাচাই করুন
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2">
          ফ্রি ডেমো ভিডিও লেকচার ও ক্লাস নোটস
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 max-w-2xl leading-relaxed">
          আবরার স্যারের ক্লাস বোঝানোর ধরণ, বিষয়ভিত্তিক গভীরতা এবং হ্যান্ডনোটের গুণগত মান দেখতে নিচের ফ্রি ডেমো ক্লাসগুলো সম্পূর্ণ বিনামূল্যে উপভোগ করুন।
        </p>
      </div>

      {/* Grid of Free Demos */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {demoLectures.map(lec => (
          <div
            key={lec.id}
            onClick={() => onOpenLecture(lec)}
            className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs hover:shadow-md transition-shadow cursor-pointer flex flex-col justify-between group"
          >
            <div className="p-5 space-y-3">
              <div className="flex items-center justify-between text-xs text-slate-500">
                <span className="font-mono font-semibold text-teal-700">লেকচার {lec.lectureNumber}</span>
                <span className="flex items-center gap-1 font-mono">
                  <Clock className="w-3.5 h-3.5" />
                  {lec.durationMinutes} মিনিট
                </span>
              </div>

              <h3 className="text-sm font-bold text-slate-900 group-hover:text-blue-900 transition-colors line-clamp-2 leading-snug">
                {lec.titleBn}
              </h3>

              <p className="text-xs text-slate-600 line-clamp-3 leading-relaxed">
                {lec.description}
              </p>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex items-center justify-between text-xs">
              <span className="font-semibold text-blue-900 flex items-center gap-1.5 group-hover:underline">
                <Play className="w-3.5 h-3.5 fill-blue-900" />
                <span>ভিডিও প্লে করুন</span>
              </span>

              {lec.driveNotesUrl && (
                <span className="text-[11px] text-teal-700 font-medium flex items-center gap-1">
                  <FileText className="w-3 h-3" />
                  <span>ড্রাইভ নোটস</span>
                </span>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Enroll banner */}
      <div className="bg-slate-900 text-white rounded-xl p-8 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="space-y-2 text-center md:text-left">
          <h3 className="text-lg font-bold text-white">
            সম্পূর্ণ সিলেবাস শেষ করতে পূর্ণাঙ্গ কোর্সে ভর্তি হোন
          </h3>
          <p className="text-xs text-slate-300 max-w-xl leading-relaxed">
            বিসিএস প্রিলিমিনারি ও লিখিত পরীক্ষার শতভাগ প্রস্তুতি নিশ্চিতে ২০০+ রেকর্ডেড ক্লাস, নিয়মিত লাইভ ক্লাস ও সকল বিষয়ের গুগল ড্রাইভ হ্যান্ডনোট পান।
          </p>
        </div>

        <button
          onClick={() => onNavigate('courses')}
          className="px-6 py-3 bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs font-bold rounded-lg transition-colors whitespace-nowrap shadow-sm"
        >
          কোর্সসমূহ দেখুন
        </button>
      </div>
    </div>
  );
};
