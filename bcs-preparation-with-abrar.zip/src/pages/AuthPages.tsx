import React, { useState } from 'react';
import { User, Lock, Mail, Phone, ArrowRight, ShieldCheck, AlertCircle, CheckCircle } from 'lucide-react';
import { DatabaseService } from '../services/db';

interface AuthPagesProps {
  initialMode: 'login' | 'register' | 'forgot-password';
  onSuccess: () => void;
  onSwitchMode: (mode: 'login' | 'register' | 'forgot-password') => void;
}

export const AuthPages: React.FC<AuthPagesProps> = ({
  initialMode,
  onSuccess,
  onSwitchMode
}) => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [district, setDistrict] = useState('');
  const [targetBcsCadre, setTargetBcsCadre] = useState('BCS Administration');
  const [error, setError] = useState('');
  const [successMessage, setSuccessMessage] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    const profiles = DatabaseService.getProfiles();
    const user = profiles.find(p => p.email.toLowerCase() === email.trim().toLowerCase());

    setTimeout(() => {
      setLoading(false);
      if (user) {
        DatabaseService.setCurrentUser(user.id);
        onSuccess();
      } else {
        // If demo email, create or log in as student
        try {
          const newStudent = DatabaseService.registerStudent({
            fullName: email.split('@')[0],
            email: email.trim(),
            phone: '01700000000'
          });
          DatabaseService.setCurrentUser(newStudent.id);
          onSuccess();
        } catch (err: unknown) {
          setError((err as Error).message || 'Invalid email or credentials.');
        }
      }
    }, 500);
  };

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const newStudent = DatabaseService.registerStudent({
        fullName: fullName.trim(),
        email: email.trim(),
        phone: phone.trim(),
        district: district.trim() || undefined,
        targetBcsCadre
      });

      setLoading(false);
      DatabaseService.setCurrentUser(newStudent.id);
      setSuccessMessage('একাউন্ট সফলভাবে তৈরি হয়েছে! ড্যাশবোর্ডে প্রবেশ করানো হচ্ছে...');
      setTimeout(() => {
        onSuccess();
      }, 1500);
    } catch (err: unknown) {
      setLoading(false);
      setError((err as Error).message || 'Failed to register account.');
    }
  };

  const handleForgotPassword = (e: React.FormEvent) => {
    e.preventDefault();
    setSuccessMessage('পাসওয়ার্ড রিসেট লিংক আপনার ইমেইলে পাঠানো হয়েছে (অথবা হোয়াটসঅ্যাপে যোগাযোগ করুন)।');
  };

  return (
    <div className="max-w-md mx-auto px-4 py-16">
      <div className="bg-white rounded-2xl border border-slate-200 shadow-xl overflow-hidden">
        {/* Header */}
        <div className="bg-slate-900 text-white p-6 text-center space-y-1">
          <div className="w-10 h-10 rounded-xl bg-teal-500 text-slate-950 font-bold text-lg mx-auto flex items-center justify-center mb-2">
            B
          </div>
          <h2 className="text-lg font-bold">
            {initialMode === 'login' && 'শিক্ষার্থী ও অ্যাডমিন লগইন'}
            {initialMode === 'register' && 'নতুন শিক্ষার্থী নিবন্ধন'}
            {initialMode === 'forgot-password' && 'পাসওয়ার্ড পুনরুদ্ধার'}
          </h2>
          <p className="text-xs text-slate-400">
            BCS Preparation With Abrar অনলাইন প্ল্যাটফর্ম
          </p>
        </div>

        {/* Form Body */}
        <div className="p-6">
          {error && (
            <div className="mb-4 p-3 rounded-lg bg-rose-50 border border-rose-200 text-rose-700 text-xs flex items-center gap-2">
              <AlertCircle className="w-4 h-4 shrink-0" />
              <span>{error}</span>
            </div>
          )}

          {successMessage && (
            <div className="mb-4 p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs flex items-center gap-2">
              <CheckCircle className="w-4 h-4 shrink-0" />
              <span>{successMessage}</span>
            </div>
          )}

          {initialMode === 'login' && (
            <form onSubmit={handleLogin} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">ইমেইল এড্রেস</label>
                <div className="relative">
                  <Mail className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="email"
                    required
                    placeholder="example@gmail.com"
                    value={email}
                    onChange={e => setEmail(e.target.value)}
                    className="w-full text-xs pl-9 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>
              </div>

              <div>
                <div className="flex justify-between items-center mb-1">
                  <label className="block text-xs font-medium text-slate-700">পাসওয়ার্ড</label>
                  <button
                    type="button"
                    onClick={() => onSwitchMode('forgot-password')}
                    className="text-[11px] text-teal-700 hover:underline"
                  >
                    পাসওয়ার্ড ভুলে গেছেন?
                  </button>
                </div>
                <div className="relative">
                  <Lock className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="password"
                    required
                    placeholder="••••••••"
                    value={password}
                    onChange={e => setPassword(e.target.value)}
                    className="w-full text-xs pl-9 pr-3 py-2.5 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-900"
                  />
                </div>
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold rounded-lg shadow-sm transition-colors"
              >
                {loading ? 'যাচাই করা হচ্ছে...' : 'লগইন করুন'}
              </button>

              <div className="pt-2 text-center text-xs text-slate-500">
                নতুন শিক্ষার্থী?{' '}
                <button
                  type="button"
                  onClick={() => onSwitchMode('register')}
                  className="font-bold text-teal-700 hover:underline"
                >
                  নতুন একাউন্ট খুলুন
                </button>
              </div>

              {/* Quick test credentials hint */}
              <div className="mt-4 p-3 bg-slate-50 rounded-lg border border-slate-200 text-[11px] text-slate-500 space-y-1">
                <p className="font-semibold text-slate-700">সরাসরি টেস্ট করার জন্য প্রস্তুতকৃত প্রোফাইল:</p>
                <p>• অ্যাডমিন: <span className="font-mono text-slate-800">abrar@bcsprepabrar.com</span></p>
                <p>• শিক্ষার্থী: <span className="font-mono text-slate-800">rahim.hassan@example.com</span></p>
              </div>
            </form>
          )}

          {initialMode === 'register' && (
            <form onSubmit={handleRegister} className="space-y-3.5">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">পূর্ণ নাম</label>
                <input
                  type="text"
                  required
                  placeholder="আপনার নাম"
                  value={fullName}
                  onChange={e => setFullName(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">ইমেইল</label>
                <input
                  type="email"
                  required
                  placeholder="student@example.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900"
                />
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">মোবাইল নম্বর (হোয়াটসঅ্যাপ)</label>
                <input
                  type="text"
                  required
                  placeholder="017XXXXXXXX"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900 font-mono"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">জেলা</label>
                  <input
                    type="text"
                    placeholder="Dhaka"
                    value={district}
                    onChange={e => setDistrict(e.target.value)}
                    className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900"
                  />
                </div>
                <div>
                  <label className="block text-xs font-medium text-slate-700 mb-1">টার্গেট ক্যাডার</label>
                  <select
                    value={targetBcsCadre}
                    onChange={e => setTargetBcsCadre(e.target.value)}
                    className="w-full text-xs px-2.5 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900"
                  >
                    <option value="BCS Administration">Administration</option>
                    <option value="BCS Police">Police</option>
                    <option value="BCS Foreign Affairs">Foreign Affairs</option>
                    <option value="BCS Customs">Customs</option>
                    <option value="BCS Education">General Education</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">পাসওয়ার্ড</label>
                <input
                  type="password"
                  required
                  placeholder="কমপক্ষে ৬ অক্ষরের পাসওয়ার্ড"
                  value={password}
                  onChange={e => setPassword(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900"
                />
              </div>

              <button
                type="submit"
                disabled={loading}
                className="w-full py-2.5 bg-teal-600 hover:bg-teal-700 text-white text-xs font-bold rounded-lg shadow-sm transition-colors mt-2"
              >
                {loading ? 'নিবন্ধন সম্পন্ন হচ্ছে...' : 'নিবন্ধন সম্পন্ন করুন'}
              </button>

              <div className="pt-2 text-center text-xs text-slate-500">
                ইতিমধ্যে একাউন্ট আছে?{' '}
                <button
                  type="button"
                  onClick={() => onSwitchMode('login')}
                  className="font-bold text-blue-900 hover:underline"
                >
                  লগইন করুন
                </button>
              </div>
            </form>
          )}

          {initialMode === 'forgot-password' && (
            <form onSubmit={handleForgotPassword} className="space-y-4">
              <div>
                <label className="block text-xs font-medium text-slate-700 mb-1">নিবন্ধিত ইমেইল এড্রেস</label>
                <input
                  type="email"
                  required
                  placeholder="student@example.com"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full text-xs px-3 py-2.5 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-blue-900 text-white text-xs font-bold rounded-lg hover:bg-blue-800 transition-colors"
              >
                পাসওয়ার্ড রিসেট কোড পাঠান
              </button>

              <div className="text-center pt-2">
                <button
                  type="button"
                  onClick={() => onSwitchMode('login')}
                  className="text-xs text-slate-600 hover:underline"
                >
                  লগইন পেজে ফিরে যান
                </button>
              </div>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
