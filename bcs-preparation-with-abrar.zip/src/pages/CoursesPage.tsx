import React, { useState } from 'react';
import { Search, Filter, BookOpen, Layers } from 'lucide-react';
import { Course, UserProfile } from '../types';
import { DatabaseService } from '../services/db';
import { CourseCard } from '../components/CourseCard';

interface CoursesPageProps {
  onNavigate: (view: string, id?: string) => void;
  onOpenCheckout: (course: Course) => void;
  onOpenWhatsAppModal: (course: Course) => void;
  currentUser: UserProfile;
}

export const CoursesPage: React.FC<CoursesPageProps> = ({
  onNavigate,
  onOpenCheckout,
  onOpenWhatsAppModal,
  currentUser
}) => {
  const [categoryFilter, setCategoryFilter] = useState<'all' | 'complete' | 'preliminary' | 'written' | 'subject_wise'>('all');
  const [searchTerm, setSearchTerm] = useState('');

  const courses = DatabaseService.getCourses();
  const enrollments = DatabaseService.getEnrollments(currentUser.id);

  const filtered = courses.filter(course => {
    const matchesCat = categoryFilter === 'all' || course.category === categoryFilter;
    const matchesSearch = 
      course.titleBn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.titleEn.toLowerCase().includes(searchTerm.toLowerCase()) ||
      course.description.toLowerCase().includes(searchTerm.toLowerCase());
    return matchesCat && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="border-b border-slate-200 pb-6">
        <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
          কোর্স ক্যাটালগ
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2">
          সকল বিসিএস কোর্স ও প্যাকেজ
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 max-w-2xl leading-relaxed">
          আপনার প্রস্তুতি অনুযায়ী বিসিএস পূর্ণাঙ্গ প্যাকেজ অথবা নির্দিষ্ট বিষয়ভিত্তিক কোর্স নির্বাচন করুন। প্রতিটি কোর্সে রয়েছে গোছানো ক্লাস, ড্রাইভ নোট ও পরীক্ষা প্রস্তুতি।
        </p>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        {/* Interactive Tab Filters */}
        <div className="flex flex-wrap items-center gap-1.5 p-1 bg-slate-100 rounded-lg w-full sm:w-auto">
          <button
            onClick={() => setCategoryFilter('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              categoryFilter === 'all'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            সকল ({courses.length})
          </button>
          <button
            onClick={() => setCategoryFilter('complete')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              categoryFilter === 'complete'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            ফুল প্রিপারেশন
          </button>
          <button
            onClick={() => setCategoryFilter('preliminary')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              categoryFilter === 'preliminary'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            প্রিলিমিনারি
          </button>
          <button
            onClick={() => setCategoryFilter('subject_wise')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
              categoryFilter === 'subject_wise'
                ? 'bg-white text-slate-900 shadow-xs'
                : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            বিষয়ভিত্তিক
          </button>
        </div>

        {/* Search */}
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="কোর্স খুঁজুন..."
            value={searchTerm}
            onChange={e => setSearchTerm(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-900"
          />
        </div>
      </div>

      {/* Grid */}
      {filtered.length > 0 ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filtered.map(course => (
            <CourseCard
              key={course.id}
              course={course}
              onViewDetails={id => onNavigate('course-detail', id)}
              onWhatsAppBuy={c => onOpenWhatsAppModal(c)}
              isEnrolled={enrollments.some(e => e.courseId === course.id)}
            />
          ))}
        </div>
      ) : (
        <div className="p-12 text-center bg-white rounded-xl border border-slate-200 space-y-2">
          <BookOpen className="w-10 h-10 text-slate-300 mx-auto" />
          <p className="text-sm font-semibold text-slate-700">কোনো কোর্স পাওয়া যায়নি</p>
          <p className="text-xs text-slate-500">অনুগ্রহ করে অন্য শব্দ লিখে খুঁজুন অথবা ফিল্টার পরিবর্তন করুন।</p>
        </div>
      )}
    </div>
  );
};
