import React, { useState } from 'react';
import { 
  Search, 
  ArrowRight, 
  Phone, 
  Play, 
  BookOpen, 
  CheckCircle, 
  FileText, 
  Sparkles, 
  Users, 
  HelpCircle,
  ExternalLink,
  MessageCircle,
  Clock,
  Layers
} from 'lucide-react';
import { Course, Subject, Lecture, UserProfile } from '../types';
import { DatabaseService } from '../services/db';
import { CourseCard } from '../components/CourseCard';
import { SubjectCard } from '../components/SubjectCard';

interface HomePageProps {
  onNavigate: (view: string, id?: string) => void;
  onOpenCheckout: (course: Course) => void;
  onOpenWhatsAppModal: (course: Course) => void;
  onOpenLecture: (lecture: Lecture) => void;
  currentUser: UserProfile;
}

export const HomePage: React.FC<HomePageProps> = ({
  onNavigate,
  onOpenCheckout,
  onOpenWhatsAppModal,
  onOpenLecture,
  currentUser
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedExamType, setSelectedExamType] = useState<'all' | 'preliminary' | 'written'>('all');

  const settings = DatabaseService.getSettings();
  const courses = DatabaseService.getCourses();
  const subjects = DatabaseService.getSubjects();
  const lectures = DatabaseService.getLectures();
  const enrollments = DatabaseService.getEnrollments(currentUser.id);

  const demoLectures = lectures.filter(l => l.isFreePreview || l.accessType === 'public').slice(0, 3);

  // Filter courses based on search & exam type
  const filteredCourses = courses.filter(c => {
    const matchesSearch = 
      c.titleBn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.titleEn.toLowerCase().includes(searchQuery.toLowerCase()) ||
      c.description.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (!matchesSearch) return false;
    if (selectedExamType === 'all') return true;
    if (selectedExamType === 'preliminary') return c.category === 'preliminary' || c.category === 'complete';
    if (selectedExamType === 'written') return c.category === 'written' || c.category === 'complete';
    return true;
  });

  return (
    <div className="space-y-20 pb-20">
      {/* 1. HERO SECTION */}
      <section className="relative overflow-hidden bg-slate-900 text-white pt-12 pb-20 lg:pt-16 lg:pb-28 border-b border-slate-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            {/* Left Column: Heading & CTAs */}
            <div className="lg:col-span-7 space-y-6">
              {/* Unboxed editorial kicker */}
              <div className="flex items-center gap-2 text-xs font-semibold text-teal-400 tracking-wider uppercase">
                <span>৪৭তম ও ৪৮তম বিসিএস প্রস্তুতি</span>
                <span aria-hidden="true">·</span>
                <span>অফিসিয়াল অনলাইন লার্নিং প্ল্যাটফর্ম</span>
              </div>

              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-extrabold tracking-tight text-white leading-tight text-balance">
                BCS Preparation <br className="hidden sm:inline" />
                <span className="text-teal-400">With Abrar</span>
              </h1>

              <p className="text-sm sm:text-base text-slate-300 leading-relaxed max-w-2xl">
                {settings.heroSubtitleBn}
              </p>

              {/* CTAs */}
              <div className="flex flex-wrap items-center gap-3 pt-2">
                <button
                  onClick={() => onNavigate('courses')}
                  className="px-6 py-3 bg-teal-500 hover:bg-teal-400 text-slate-950 text-xs sm:text-sm font-bold rounded-lg shadow-sm transition-colors flex items-center gap-2 whitespace-nowrap"
                >
                  <BookOpen className="w-4 h-4" />
                  <span>কোর্সসমূহ দেখুন (Explore Courses)</span>
                </button>

                <button
                  onClick={() => onNavigate('free-demo')}
                  className="px-5 py-3 bg-slate-800 hover:bg-slate-700 text-white text-xs sm:text-sm font-semibold rounded-lg border border-slate-700 transition-colors flex items-center gap-2 whitespace-nowrap"
                >
                  <Play className="w-4 h-4 text-teal-400" />
                  <span>ফ্রি ডেমো ক্লাস শুরু করুন</span>
                </button>

                <a
                  href={`https://wa.me/${settings.phoneIntl}?text=${encodeURIComponent('Assalamu Alaikum Abrar Sir. I would like to know about BCS course admission and schedule.')}`}
                  target="_blank"
                  rel="noreferrer"
                  className="px-4 py-3 text-xs sm:text-sm font-semibold text-emerald-400 hover:text-emerald-300 transition-colors flex items-center gap-1.5 whitespace-nowrap"
                >
                  <MessageCircle className="w-4 h-4" />
                  <span>হোয়াটসঅ্যাপ: {settings.phoneLocal}</span>
                </a>
              </div>

              {/* Real metric indicators */}
              <div className="pt-6 border-t border-slate-800/80 grid grid-cols-3 gap-4 text-xs">
                <div>
                  <div className="text-lg font-bold font-mono text-white tabular-nums">১১টি বিষয়</div>
                  <div className="text-slate-400">বিসিএস পূর্ণ সিলেবাস</div>
                </div>
                <div>
                  <div className="text-lg font-bold font-mono text-white tabular-nums">২০০+ লেকচার</div>
                  <div className="text-slate-400">ভিডিও ও ক্লাস নোটস</div>
                </div>
                <div>
                  <div className="text-lg font-bold font-mono text-white tabular-nums">১০০% ভেরিফাইড</div>
                  <div className="text-slate-400">হোয়াটসঅ্যাপ সাপোর্ট</div>
                </div>
              </div>
            </div>

            {/* Right Column: Hero Visual Asset */}
            <div className="lg:col-span-5 relative">
              <div className="rounded-2xl overflow-hidden shadow-2xl border border-slate-700 bg-slate-800 aspect-16/9 sm:aspect-4/3">
                <img
                  src="/src/assets/images/bcs_hero_education_1791590008571.jpg"
                  alt="BCS Preparation Study Environment"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              {/* Subtle caption */}
              <p className="mt-2 text-right text-[11px] text-slate-400 font-medium">
                ঢাকা লাইব্রেরি স্টাডি ও সুসংগঠিত বিসিএস প্রস্তুতি
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* 2. SEARCH & COURSE EXPLORER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 -mt-10 relative z-20">
        <div className="bg-white rounded-xl shadow-lg border border-slate-200 p-4 sm:p-6">
          <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
            {/* Search Input */}
            <div className="relative flex-1 w-full">
              <Search className="w-4 h-4 text-slate-400 absolute left-3.5 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="কোর্সের নাম, বিষয় বা টপিক লিখে খুঁজুন..."
                value={searchQuery}
                onChange={e => setSearchQuery(e.target.value)}
                className="w-full pl-10 pr-4 py-2.5 text-xs sm:text-sm rounded-lg border border-slate-300 focus:outline-none focus:ring-2 focus:ring-blue-900 focus:border-transparent"
              />
            </div>

            {/* Filter Buttons */}
            <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg shrink-0 w-full md:w-auto justify-center">
              <button
                onClick={() => setSelectedExamType('all')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  selectedExamType === 'all'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                সকল কোর্স
              </button>
              <button
                onClick={() => setSelectedExamType('preliminary')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  selectedExamType === 'preliminary'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                প্রিলিমিনারি
              </button>
              <button
                onClick={() => setSelectedExamType('written')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  selectedExamType === 'written'
                    ? 'bg-white text-slate-900 shadow-xs'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                লিখিত পরীক্ষা
              </button>
            </div>
          </div>
        </div>
      </section>

      {/* 3. FEATURED COURSES SECTION */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-baseline justify-between mb-8">
          <div>
            <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
              নিবন্ধনের জন্য উন্মুক্ত
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
              নির্বাচিত বিসিএস কোর্সসমূহ
            </h2>
          </div>
          <button
            onClick={() => onNavigate('courses')}
            className="text-xs font-semibold text-blue-900 hover:text-blue-800 flex items-center gap-1 group whitespace-nowrap"
          >
            <span>সব কোর্স দেখুন</span>
            <ArrowRight className="w-3.5 h-3.5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {filteredCourses.slice(0, 3).map(course => (
            <CourseCard
              key={course.id}
              course={course}
              onViewDetails={id => onNavigate('course-detail', id)}
              onWhatsAppBuy={c => onOpenWhatsAppModal(c)}
              isEnrolled={enrollments.some(e => e.courseId === course.id)}
            />
          ))}
        </div>
      </section>

      {/* 4. BCS SYLLABUS SUBJECTS OVERVIEW */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto mb-10">
          <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
            অফিসিয়াল বিপিএসসি সিলেবাস
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
            বিষয়ভিত্তিক প্রস্তুতি ও পূর্ণাঙ্গ সিলেবাস
          </h2>
          <p className="text-xs sm:text-sm text-slate-600">
            বিসিএস প্রিলিমিনারি ২০০ মার্কস ও লিখিত ৯০০ মার্কসের ১১টি আবশ্যিক বিষয়ের প্রতিটি অধ্যায় ও টপিক সাজানো হয়েছে পরীক্ষার গুরুত্ব অনুযায়ী।
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
          {subjects.map(subject => (
            <SubjectCard
              key={subject.id}
              subject={subject}
              onClick={id => onNavigate('subject-detail', id)}
            />
          ))}
        </div>
      </section>

      {/* 5. FREE DEMO LECTURES SPOTLIGHT */}
      <section className="bg-slate-900 text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row items-baseline justify-between mb-8 gap-4">
            <div>
              <div className="text-xs font-semibold text-teal-400 uppercase tracking-wider mb-1">
                সবার জন্য উন্মুক্ত
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-white">
                ফ্রি ডেমো লেকচার ও ক্লাস নোট
              </h2>
            </div>
            <p className="text-xs text-slate-400 max-w-md">
              কোর্সে ভর্তির পূর্বে ক্লাসের মান, বিষয়বস্তু উপস্থাপনা এবং গুগল ড্রাইভ হ্যান্ডনোট যাচাই করার জন্য ফ্রি ডেমো ক্লাসগুলো দেখে নিন।
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {demoLectures.map(lecture => (
              <div
                key={lecture.id}
                className="bg-slate-800 rounded-xl border border-slate-700 overflow-hidden flex flex-col justify-between hover:border-teal-500/50 transition-colors group cursor-pointer"
                onClick={() => onOpenLecture(lecture)}
              >
                <div className="p-5 space-y-3">
                  <div className="flex items-center justify-between text-xs text-slate-400">
                    <span className="font-mono text-teal-400 font-semibold">লেকচার {lecture.lectureNumber}</span>
                    <span className="flex items-center gap-1 font-mono">
                      <Clock className="w-3.5 h-3.5" />
                      {lecture.durationMinutes} মিনিট
                    </span>
                  </div>

                  <h3 className="text-sm font-bold text-white group-hover:text-teal-300 transition-colors line-clamp-2">
                    {lecture.titleBn}
                  </h3>

                  <p className="text-xs text-slate-300 line-clamp-2 leading-relaxed">
                    {lecture.description}
                  </p>
                </div>

                <div className="p-4 bg-slate-800/80 border-t border-slate-700/80 flex items-center justify-between text-xs">
                  <button className="flex items-center gap-1.5 text-teal-400 font-semibold group-hover:text-teal-300">
                    <Play className="w-3.5 h-3.5 fill-teal-400" />
                    <span>প্লে করুন</span>
                  </button>
                  {lecture.driveNotesUrl && (
                    <span className="flex items-center gap-1 text-slate-400 text-[11px]">
                      <FileText className="w-3 h-3 text-slate-300" />
                      <span>ড্রাইভ নোট যুক্ত</span>
                    </span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 6. INSTRUCTOR PROFILE & STUDY MATERIALS */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Instructor Profile */}
          <div className="space-y-5">
            <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider">
              শিক্ষক ও নির্দেশক পরিচিতি
            </div>
            <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 leading-tight">
              আবরার (Abrar) — আপনার বিসিএস সফলতার সঙ্গী
            </h2>
            <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
              বিসিএস পরীক্ষায় মুখস্থ বিদ্যার চেয়ে কনসেপ্ট ক্লিয়ার থাকা এবং নিয়মিত রিভিশন দেওয়া সবচেয়ে জরুরি। প্রতিটি বিষয়ে অপ্রয়োজনীয় তথ্য বাদ দিয়ে বিপিএসসি এর প্রশ্ন প্যাটার্ন অনুযায়ী গোছানো লেকচার প্রদান করাই আমাদের লক্ষ্য।
            </p>

            <ul className="space-y-2.5 text-xs text-slate-700 pt-2">
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>প্রতিটি বিষয়ের কনসেপ্টচুয়াল ব্যাখ্যা ও বিগত বছরের প্রশ্ন সমাধান</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>লিখিত পরীক্ষার জন্য স্ট্যান্ডার্ড ডেটা, রেফারেন্স ও পয়েন্ট উপস্থাপন কৌশল</span>
              </li>
              <li className="flex items-start gap-2">
                <CheckCircle className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
                <span>হোয়াটসঅ্যাপের মাধ্যমে শিক্ষার্থীদের যেকোনো প্রশ্নের সরাসরি সমাধান</span>
              </li>
            </ul>

            <div className="pt-2 flex items-center gap-4">
              <a
                href={`https://wa.me/${settings.phoneIntl}`}
                target="_blank"
                rel="noreferrer"
                className="px-5 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg flex items-center gap-2 transition-colors shadow-xs"
              >
                <Phone className="w-4 h-4" />
                <span>সরাসরি কথা বলুন (০১৭৫৮৮৯৮৭৬৭)</span>
              </a>
            </div>
          </div>

          {/* Instructor Image Frame */}
          <div className="flex justify-center lg:justify-end">
            <div className="relative max-w-sm w-full">
              <div className="rounded-2xl overflow-hidden shadow-xl border border-slate-200 aspect-square bg-slate-100">
                <img
                  src="/src/assets/images/instructor_abrar_portrait_1791590021132.jpg"
                  alt="Abrar - Instructor"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="absolute -bottom-4 -left-4 bg-white p-3.5 rounded-xl border border-slate-200 shadow-md">
                <p className="text-xs font-bold text-slate-900">Abrar</p>
                <p className="text-[11px] text-teal-700 font-medium">Founder & Lead Mentor</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 7. STRUCTURED STUDY MATERIALS SHOWCASE */}
      <section className="bg-slate-100/70 py-16 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-10 items-center">
            <div className="lg:col-span-5">
              <div className="rounded-xl overflow-hidden shadow-lg border border-slate-200 aspect-4/3 bg-white">
                <img
                  src="/src/assets/images/bcs_study_materials_1791590036299.jpg"
                  alt="BCS Structured Study Materials"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="lg:col-span-7 space-y-4">
              <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider">
                ক্লাস মেটেরিয়ালস ও হ্যান্ডনোট
              </div>
              <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
                গুগল ড্রাইভ হ্যান্ডনোট ও প্রিন্ট-রেডি শিট
              </h2>
              <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
                শুধু লেকচার শোনাই যথেষ্ট নয়; পড়ার পর রিভিশন করার জন্য প্রতিটি ক্লাসের সাথে রয়েছে বিস্তারিত গুগল ড্রাইভ পিডিএফ নোট। আপনি যেকোনো ডিভাইস থেকে পড়তে পারবেন অথবা প্রিন্ট করে সংরক্ষণ করতে পারবেন।
              </p>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-xs">
                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <h4 className="font-bold text-slate-900 mb-1">প্রিন্ট-ফ্রেন্ডলি ফন্ট</h4>
                  <p className="text-slate-500">বাংলা ও ইংরেজি পরিষ্কার টাইপোগ্রাফিতে প্রস্তুতকৃত হ্যান্ডনোট।</p>
                </div>
                <div className="p-3 bg-white rounded-lg border border-slate-200">
                  <h4 className="font-bold text-slate-900 mb-1">মানচিত্র ও চার্ট</h4>
                  <p className="text-slate-500">বাংলাদেশ ও আন্তর্জাতিক বিষয়াবলীর জটিল তথ্য ছক ও মানচিত্রে উপস্থাপিত।</p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 8. FREQUENTLY ASKED QUESTIONS (FAQ) */}
      <section className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-10">
          <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
            সাধারণ জিজ্ঞাসা
          </div>
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900">
            বিসিএস প্রস্তুতি সম্পর্কিত প্রশ্ন ও উত্তর
          </h2>
        </div>

        <div className="space-y-4 text-xs">
          <div className="p-5 bg-white rounded-xl border border-slate-200">
            <h4 className="text-sm font-bold text-slate-900 mb-1.5">
              কোর্সে কীভাবে ভর্তি হওয়া যাবে?
            </h4>
            <p className="text-slate-600 leading-relaxed">
              আপনি দুইভাবে ভর্তি হতে পারেন: ১) কোর্সের নিচে "হোয়াটসঅ্যাপে কিনুন" বোতামে ক্লিক করে সরাসরি আবরার স্যারের সাথে কথা বলে bKash/Nagad এ টাকা পাঠিয়ে ট্রানজেকশন আইডি সাবমিট করতে পারেন; অথবা ২) "অনলাইনে ভর্তি" বোতামে ক্লিক করে কার্ড বা মোবাইল ব্যাংকিং গেটওয়ের মাধ্যমে সাথে সাথে ভর্তি নিশ্চিত করতে পারেন।
            </p>
          </div>

          <div className="p-5 bg-white rounded-xl border border-slate-200">
            <h4 className="text-sm font-bold text-slate-900 mb-1.5">
              আমি কি যেকোনো সময় ক্লাসগুলো দেখতে পারব?
            </h4>
            <p className="text-slate-600 leading-relaxed">
              হ্যাঁ, কোর্সে অন্তর্ভুক্ত সকল ভিডিও লেকচার ও গুগল ড্রাইভ ক্লাস নোট ২৪/৭ আপনার জন্য উন্মুক্ত থাকবে। কোর্সের নির্ধারিত মেয়াদ পর্যন্ত যেকোনো ডিভাইস থেকে যতবার খুশি দেখতে পারবেন।
            </p>
          </div>

          <div className="p-5 bg-white rounded-xl border border-slate-200">
            <h4 className="text-sm font-bold text-slate-900 mb-1.5">
              ক্লাস বুঝতে সমস্যা হলে কীভাবে সমাধান পাব?
            </h4>
            <p className="text-slate-600 leading-relaxed">
              প্রতিটি কোর্সের শিক্ষার্থীদের জন্য রয়েছে ডেডিকেটেড হোয়াটসঅ্যাপ ডিসকাশন সুবিধা। আপনি যেকোনো লেকচারের টপিক না বুঝলে সরাসরি হোয়াটসঅ্যাপে মেসেজ পাঠিয়ে সমাধান নিতে পারবেন।
            </p>
          </div>

          <div className="p-5 bg-white rounded-xl border border-slate-200">
            <h4 className="text-sm font-bold text-slate-900 mb-1.5">
              সিলেবাস কি বর্তমান বিপিএসসি এর নিয়ম অনুযায়ী প্রণীত?
            </h4>
            <p className="text-slate-600 leading-relaxed">
              হ্যাঁ, বাংলাদেশ সরকারি কর্ম কমিশন (BPSC) এর নির্ধারিত সিলেবাস অনুযায়ী প্রতিটি বিষয়ের প্রাথমিক কাঠামো সাজানো হয়েছে। আমরা নিয়মিত সিলেবাসের হালনাগাদ তথ্যানুযায়ী লেকচার সমৃদ্ধ করি।
            </p>
          </div>
        </div>
      </section>

      {/* 9. WHATSAPP DIRECT BANNER */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="bg-emerald-700 text-white rounded-2xl p-8 sm:p-10 shadow-lg flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="space-y-2 text-center md:text-left">
            <h3 className="text-xl sm:text-2xl font-bold">
              কোর্স সম্পর্কিত যেকোনো প্রশ্নে হোয়াটসঅ্যাপে যোগাযোগ করুন
            </h3>
            <p className="text-xs sm:text-sm text-emerald-100 max-w-xl">
              কোর্সের ফি, ব্যাচের সময়সূচি বা পড়াশোনার গাইডলাইন জানতে সরাসরি মেসেজ দিন: <span className="font-mono font-bold text-white">{settings.phoneLocal}</span>
            </p>
          </div>

          <a
            href={`https://wa.me/${settings.phoneIntl}?text=${encodeURIComponent('Assalamu Alaikum Abrar Sir. I would like to consult with you regarding BCS preparation.')}`}
            target="_blank"
            rel="noreferrer"
            className="px-6 py-3.5 bg-white text-emerald-900 hover:bg-emerald-50 text-xs sm:text-sm font-bold rounded-xl shadow-md transition-colors flex items-center gap-2 shrink-0 whitespace-nowrap"
          >
            <MessageCircle className="w-4 h-4 text-emerald-700" />
            <span>হোয়াটসঅ্যাপে চ্যাট করুন</span>
          </a>
        </div>
      </section>
    </div>
  );
};
