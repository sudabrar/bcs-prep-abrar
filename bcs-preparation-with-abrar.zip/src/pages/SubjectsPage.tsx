import React, { useState } from 'react';
import { Search, Layers, BookOpen } from 'lucide-react';
import { DatabaseService } from '../services/db';
import { SubjectCard } from '../components/SubjectCard';

interface SubjectsPageProps {
  onNavigate: (view: string, id?: string) => void;
}

export const SubjectsPage: React.FC<SubjectsPageProps> = ({ onNavigate }) => {
  const [filterType, setFilterType] = useState<'all' | 'preliminary' | 'written' | 'both'>('all');
  const [search, setSearch] = useState('');

  const subjects = DatabaseService.getSubjects();

  const filtered = subjects.filter(s => {
    const matchesFilter = filterType === 'all' || s.examType === filterType || s.examType === 'both';
    const matchesSearch = 
      s.titleBn.toLowerCase().includes(search.toLowerCase()) ||
      s.titleEn.toLowerCase().includes(search.toLowerCase()) ||
      s.code.toLowerCase().includes(search.toLowerCase());
    return matchesFilter && matchesSearch;
  });

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-8">
      {/* Header */}
      <div className="border-b border-slate-200 pb-6">
        <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider mb-1">
          বিপিএসসি কারিকুলাম
        </div>
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900 mb-2">
          বিসিএস বিষয়ভিত্তিক সিলেবাস ও কারিকুলাম
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 max-w-2xl leading-relaxed">
          বাংলাদেশ সরকারি কর্ম কমিশন (BPSC) এর নির্ধারিত ১১টি আবশ্যিক বিষয়ের বিস্তারিত অধ্যায়, টপিক ও লেকচার বিন্যাস।
        </p>
      </div>

      {/* Filter and Search */}
      <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-1.5 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              filterType === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            সকল বিষয় ({subjects.length})
          </button>
          <button
            onClick={() => setFilterType('preliminary')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              filterType === 'preliminary' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            প্রিলিমিনারি ফোকাস
          </button>
          <button
            onClick={() => setFilterType('both')}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
              filterType === 'both' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            প্রিলি ও লিখিত উভয়
          </button>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="বিষয় বা কোড খুঁজুন..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs rounded-lg border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-900"
          />
        </div>
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
        {filtered.map(sub => (
          <SubjectCard
            key={sub.id}
            subject={sub}
            onClick={id => onNavigate('subject-detail', id)}
          />
        ))}
      </div>
    </div>
  );
};
