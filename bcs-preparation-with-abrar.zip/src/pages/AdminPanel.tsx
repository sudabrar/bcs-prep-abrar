import React, { useState } from 'react';
import { 
  LayoutDashboard, 
  BookOpen, 
  Layers, 
  Video, 
  GraduationCap, 
  Users, 
  UserCheck, 
  Key, 
  CreditCard, 
  MessageCircle, 
  Tag, 
  Bell, 
  BarChart3, 
  Settings, 
  ShieldAlert,
  Plus,
  Trash2,
  Edit2,
  Check,
  X,
  Download,
  ExternalLink,
  Search,
  Filter,
  CheckCircle,
  Clock,
  Calendar,
  AlertTriangle,
  RefreshCw,
  Copy
} from 'lucide-react';
import { 
  Subject, 
  Chapter, 
  Topic, 
  Lecture, 
  Course, 
  Batch, 
  UserProfile, 
  Enrollment, 
  StudentPermission, 
  AccessRequest, 
  CourseInquiry, 
  Payment, 
  Coupon, 
  Announcement, 
  SiteSettings, 
  ActivityLog,
  PaymentStatus,
  InquiryStatus,
  RequestStatus,
  UserRole,
  ExamType
} from '../types';
import { DatabaseService } from '../services/db';
import { 
  getSupabaseStatus, 
  testSupabaseConnection, 
  saveCustomSupabaseCredentials, 
  getEffectiveSupabaseCredentials 
} from '../lib/supabase';

type AdminTab = 
  | 'overview'
  | 'subjects'
  | 'chapters'
  | 'lectures'
  | 'courses'
  | 'batches'
  | 'students'
  | 'enrollments'
  | 'access_control'
  | 'payments'
  | 'inquiries'
  | 'coupons'
  | 'announcements'
  | 'reports'
  | 'settings'
  | 'activity_logs';

interface AdminPanelProps {
  currentUser: UserProfile;
  onNavigateHome: () => void;
}

export const AdminPanel: React.FC<AdminPanelProps> = ({ currentUser, onNavigateHome }) => {
  const [activeTab, setActiveTab] = useState<AdminTab>('overview');
  const [searchTerm, setSearchTerm] = useState('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Form Modals State
  const [editingSubject, setEditingSubject] = useState<Partial<Subject> | null>(null);
  const [editingChapter, setEditingChapter] = useState<Partial<Chapter> | null>(null);
  const [editingLecture, setEditingLecture] = useState<Partial<Lecture> | null>(null);
  const [editingCourse, setEditingCourse] = useState<Partial<Course> | null>(null);
  const [editingBatch, setEditingBatch] = useState<Partial<Batch> | null>(null);
  const [editingCoupon, setEditingCoupon] = useState<Partial<Coupon> | null>(null);
  const [editingAnnouncement, setEditingAnnouncement] = useState<Partial<Announcement> | null>(null);

  // Manual enrollment modal
  const [enrollModal, setEnrollModal] = useState<{ open: boolean; studentId: string; courseId: string; days: number }>({
    open: false,
    studentId: '',
    courseId: '',
    days: 365
  });

  // Granular Permission Modal
  const [permModal, setPermModal] = useState<{ open: boolean; userId: string; entityType: 'course' | 'subject' | 'chapter' | 'lecture'; entityId: string; isGranted: boolean }>({
    open: false,
    userId: '',
    entityType: 'subject',
    entityId: '',
    isGranted: true
  });

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Live Database Subscribed State
  const stats = DatabaseService.getDashboardStats();
  const subjects = DatabaseService.getSubjects();
  const chapters = DatabaseService.getChapters();
  const lectures = DatabaseService.getLectures();
  const courses = DatabaseService.getCourses();
  const batches = DatabaseService.getBatches();
  const profiles = DatabaseService.getProfiles();
  const enrollments = DatabaseService.getEnrollments();
  const permissions = DatabaseService.getPermissions();
  const payments = DatabaseService.getPayments();
  const inquiries = DatabaseService.getInquiries();
  const requests = DatabaseService.getAccessRequests();
  const coupons = DatabaseService.getCoupons();
  const announcements = DatabaseService.getAnnouncements();
  const siteSettings = DatabaseService.getSettings();
  const logs = DatabaseService.getActivityLogs();

  // Settings form local state
  const [settingsForm, setSettingsForm] = useState<SiteSettings>(siteSettings);

  // Supabase test and configuration state
  const initialCreds = getEffectiveSupabaseCredentials();
  const [supabaseUrlInput, setSupabaseUrlInput] = useState(initialCreds.url);
  const [supabaseKeyInput, setSupabaseKeyInput] = useState(initialCreds.key);
  const [supabaseTesting, setSupabaseTesting] = useState(false);
  const [supabaseTestResult, setSupabaseTestResult] = useState<{ success: boolean; message: string } | null>(null);

  return (
    <div className="min-h-screen bg-slate-100 flex flex-col">
      {/* Toast */}
      {toastMessage && (
        <div className="fixed bottom-6 right-6 z-50 bg-slate-900 text-white px-4 py-2.5 rounded-lg shadow-xl text-xs flex items-center gap-2 border border-slate-700 animate-in fade-in slide-in-from-bottom-2">
          <CheckCircle className="w-4 h-4 text-teal-400" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Admin Header */}
      <div className="bg-slate-900 text-white border-b border-slate-800 px-4 sm:px-6 py-3 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <button
            onClick={onNavigateHome}
            className="text-xs font-semibold px-2.5 py-1 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded border border-slate-700 transition-colors"
          >
            ← ওয়েবসাইটে ফিরুন
          </button>
          <div className="h-4 w-px bg-slate-700 hidden sm:block"></div>
          <div>
            <span className="text-sm font-bold text-white">BCS Preparation Admin Console</span>
            <span className="text-xs text-teal-400 ml-2 hidden md:inline">Logged in as {currentUser.fullName}</span>
          </div>
        </div>

        <div className="flex items-center gap-3 text-xs">
          <span className="px-2 py-0.5 rounded bg-teal-500/10 text-teal-400 font-mono text-[11px] border border-teal-500/20">
            {stats.activeEnrollments} Active Enrollments
          </span>
          <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 font-mono text-[11px] border border-emerald-500/20">
            ৳{stats.totalVerifiedRevenueBdt.toLocaleString()} Revenue
          </span>
        </div>
      </div>

      <div className="flex-1 flex overflow-hidden">
        {/* Admin Left Sidebar */}
        <aside className="w-64 bg-slate-900 text-slate-300 border-r border-slate-800 flex flex-col shrink-0 overflow-y-auto">
          <div className="p-3">
            <p className="px-3 py-1 text-[10px] font-bold text-slate-500 uppercase tracking-wider">
              ম্যানেজমেন্ট ও কনফিগারেশন
            </p>
          </div>

          <nav className="flex-1 px-2 space-y-0.5 text-xs">
            <button
              onClick={() => setActiveTab('overview')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'overview' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <LayoutDashboard className="w-4 h-4 text-teal-400" />
              <span>১. ড্যাশবোর্ড ওভারভিউ</span>
            </button>

            <button
              onClick={() => setActiveTab('subjects')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'subjects' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <BookOpen className="w-4 h-4 text-blue-400" />
              <span>২. বিষয় সিলেবাস ({subjects.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('chapters')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'chapters' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Layers className="w-4 h-4 text-cyan-400" />
              <span>৩. অধ্যায় ও টপিক ({chapters.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('lectures')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'lectures' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Video className="w-4 h-4 text-rose-400" />
              <span>৪. ক্লাস ও লেকচার ({lectures.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('courses')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'courses' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <GraduationCap className="w-4 h-4 text-emerald-400" />
              <span>৫. কোর্স ও প্যাকেজ ({courses.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('batches')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'batches' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Users className="w-4 h-4 text-amber-400" />
              <span>৬. ব্যাচ ম্যানেজমেন্ট ({batches.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('students')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'students' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <UserCheck className="w-4 h-4 text-purple-400" />
              <span>৭. শিক্ষার্থী ও অ্যাকাউন্ট ({profiles.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('enrollments')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'enrollments' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Key className="w-4 h-4 text-teal-400" />
              <span>৮. ভর্তি ও এনরোলমেন্ট ({enrollments.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('access_control')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'access_control' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <ShieldAlert className="w-4 h-4 text-indigo-400" />
              <span>৯. অ্যাক্সেস কন্ট্রোল (পারমিশন)</span>
            </button>

            <button
              onClick={() => setActiveTab('payments')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'payments' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <CreditCard className="w-4 h-4 text-emerald-400" />
                <span>১০. পেমেন্ট ও TrxID</span>
              </div>
              {stats.pendingPayments > 0 && (
                <span className="px-1.5 py-0.5 rounded text-[10px] bg-rose-500 text-white font-bold">
                  {stats.pendingPayments}
                </span>
              )}
            </button>

            <button
              onClick={() => setActiveTab('inquiries')}
              className={`w-full flex items-center justify-between px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'inquiries' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <div className="flex items-center gap-2.5">
                <MessageCircle className="w-4 h-4 text-teal-300" />
                <span>১১. হোয়াটসঅ্যাপ ইনকোয়ারি</span>
              </div>
              <span className="text-[10px] font-mono text-slate-400">{inquiries.length}</span>
            </button>

            <button
              onClick={() => setActiveTab('coupons')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'coupons' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Tag className="w-4 h-4 text-yellow-400" />
              <span>১২. কুপন ও ডিসকাউন্ট ({coupons.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('announcements')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'announcements' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Bell className="w-4 h-4 text-orange-400" />
              <span>১৩. নোটিশ ও ঘোষণা ({announcements.length})</span>
            </button>

            <button
              onClick={() => setActiveTab('reports')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'reports' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <BarChart3 className="w-4 h-4 text-blue-400" />
              <span>১৪. অ্যানালিটিক্স ও রিপোর্টস</span>
            </button>

            <button
              onClick={() => setActiveTab('settings')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'settings' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Settings className="w-4 h-4 text-slate-400" />
              <span>১৫. ওয়েবসাইট ও সেটিংস</span>
            </button>

            <button
              onClick={() => setActiveTab('activity_logs')}
              className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-left transition-colors ${
                activeTab === 'activity_logs' ? 'bg-blue-800 text-white font-semibold' : 'hover:bg-slate-800 text-slate-300'
              }`}
            >
              <Clock className="w-4 h-4 text-slate-400" />
              <span>১৬. অ্যাক্টিভিটি ও সিকিউরিটি লগ</span>
            </button>
          </nav>
        </aside>

        {/* Main Content Area */}
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* TAB 1: OVERVIEW */}
          {activeTab === 'overview' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-slate-900">অ্যাডমিন ড্যাশবোর্ড ওভারভিউ</h2>
                <p className="text-xs text-slate-500">
                  বাস্তব ডাটাবেজভিত্তিক সার্বিক পরিসংখ্যান (কোনো কাল্পনিক পরিসংখ্যান নেই)
                </p>
              </div>

              {/* Statistics Grid */}
              <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-4">
                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-slate-500 text-xs font-medium">নিবন্ধিত শিক্ষার্থী</div>
                  <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
                    {stats.registeredStudents}
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-slate-500 text-xs font-medium">অ্যাক্টিভ কোর্স এনরোলমেন্ট</div>
                  <div className="text-2xl font-bold font-mono text-blue-900 mt-1 tabular-nums">
                    {stats.activeEnrollments}
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-slate-500 text-xs font-medium">যাচাইকৃত পেমেন্ট (রাজস্ব)</div>
                  <div className="text-2xl font-bold font-mono text-emerald-600 mt-1 tabular-nums">
                    ৳{stats.totalVerifiedRevenueBdt.toLocaleString()}
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-slate-500 text-xs font-medium">পেন্ডিং পেমেন্ট ভেরিফিকেশন</div>
                  <div className="text-2xl font-bold font-mono text-rose-600 mt-1 tabular-nums">
                    {stats.pendingPayments}
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-slate-500 text-xs font-medium">মোট কোর্স ও প্যাকেজ</div>
                  <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
                    {stats.totalCourses}
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-slate-500 text-xs font-medium">মোট প্রকাশিত লেকচার</div>
                  <div className="text-2xl font-bold font-mono text-teal-700 mt-1 tabular-nums">
                    {stats.publishedLectures} / {stats.totalLectures}
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-slate-500 text-xs font-medium">সিলেবাস বিষয় ও অধ্যায়</div>
                  <div className="text-2xl font-bold font-mono text-slate-900 mt-1 tabular-nums">
                    {stats.totalSubjects} বিষয় ({stats.totalChapters} অধ্যায়)
                  </div>
                </div>

                <div className="bg-white p-4 rounded-xl border border-slate-200">
                  <div className="text-slate-500 text-xs font-medium">হোয়াটসঅ্যাপ ইনকোয়ারি</div>
                  <div className="text-2xl font-bold font-mono text-teal-600 mt-1 tabular-nums">
                    {stats.courseInquiries}
                  </div>
                </div>
              </div>

              {/* Pending Action Alerts */}
              {(stats.pendingPayments > 0 || stats.pendingAccessRequests > 0) && (
                <div className="p-4 bg-amber-50 border border-amber-200 rounded-xl space-y-2">
                  <h3 className="text-xs font-bold text-amber-900 flex items-center gap-1.5">
                    <AlertTriangle className="w-4 h-4 text-amber-600" />
                    <span>প্রয়োজনীয় প্রশাসনিক পদক্ষেপ (Pending Actions):</span>
                  </h3>
                  <div className="flex flex-wrap gap-4 text-xs text-amber-800">
                    {stats.pendingPayments > 0 && (
                      <button
                        onClick={() => setActiveTab('payments')}
                        className="underline font-semibold hover:text-amber-950"
                      >
                        • {stats.pendingPayments}টি পেমেন্ট TrxID যাচাইয়ের অপেক্ষায় রয়েছে
                      </button>
                    )}
                    {stats.pendingAccessRequests > 0 && (
                      <button
                        onClick={() => setActiveTab('enrollments')}
                        className="underline font-semibold hover:text-amber-950"
                      >
                        • {stats.pendingAccessRequests}টি শিক্ষার্থী কোর্স অ্যাক্সেস রিকোয়েস্ট অনুমোদনের অপেক্ষায়
                      </button>
                    )}
                  </div>
                </div>
              )}

              {/* Quick Recent Activity */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
                <h3 className="text-sm font-bold text-slate-900">সাম্প্রতিক প্রশাসনিক কার্যক্রম (Recent Activity)</h3>
                <div className="divide-y divide-slate-100 text-xs">
                  {logs.slice(0, 5).map(l => (
                    <div key={l.id} className="py-2.5 flex items-center justify-between">
                      <div>
                        <span className="font-semibold text-slate-800 font-mono text-[11px] mr-2">[{l.action}]</span>
                        <span className="text-slate-600">{l.details}</span>
                      </div>
                      <span className="text-[11px] font-mono text-slate-400">
                        {new Date(l.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                      </span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: SUBJECTS */}
          {activeTab === 'subjects' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">বিসিএস বিষয়সমূহ (Subjects)</h2>
                  <p className="text-xs text-slate-500">বিপিএসসি সিলেবাস অনুযায়ী বিষয় ও কোড পরিচালনা করুন</p>
                </div>
                <button
                  onClick={() => setEditingSubject({
                    id: `sub_${Date.now()}`,
                    titleBn: '',
                    titleEn: '',
                    code: 'BCS-',
                    description: '',
                    examType: 'both',
                    orderIndex: subjects.length + 1,
                    isPublished: true
                  })}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5 transition-colors"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন বিষয় যুক্ত করুন</span>
                </button>
              </div>

              {/* Table */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="px-4 py-3">কোড</th>
                      <th className="px-4 py-3">বিষয়ের নাম (বাংলা ও ইংরেজি)</th>
                      <th className="px-4 py-3">পরীক্ষার ধরণ</th>
                      <th className="px-4 py-3">স্ট্যাটাস</th>
                      <th className="px-4 py-3 text-right">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {subjects.map(s => (
                      <tr key={s.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-3 font-mono font-bold text-blue-900">{s.code}</td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-900">{s.titleBn}</div>
                          <div className="text-[11px] text-slate-400">{s.titleEn}</div>
                        </td>
                        <td className="px-4 py-3 capitalize text-slate-600">{s.examType}</td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                            s.isPublished ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {s.isPublished ? 'Published' : 'Draft'}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right space-x-2">
                          <button
                            onClick={() => setEditingSubject(s)}
                            className="p-1 text-slate-500 hover:text-blue-900"
                          >
                            <Edit2 className="w-4 h-4" />
                          </button>
                          <button
                            onClick={() => {
                              if (confirm(`Are you sure you want to delete ${s.titleBn}?`)) {
                                DatabaseService.deleteSubject(s.id);
                                showToast('Subject deleted.');
                              }
                            }}
                            className="p-1 text-slate-500 hover:text-rose-600"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>

              {/* Subject Modal */}
              {editingSubject && (
                <div className="fixed inset-0 z-50 bg-slate-950/70 flex items-center justify-center p-4">
                  <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">
                      {editingSubject.id && subjects.some(s => s.id === editingSubject.id) ? 'বিষয় সম্পাদনা' : 'নতুন বিষয় তৈরি'}
                    </h3>

                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">বাংলা নাম</label>
                        <input
                          type="text"
                          value={editingSubject.titleBn || ''}
                          onChange={e => setEditingSubject({ ...editingSubject, titleBn: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">ইংরেজি নাম</label>
                        <input
                          type="text"
                          value={editingSubject.titleEn || ''}
                          onChange={e => setEditingSubject({ ...editingSubject, titleEn: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">বিষয় কোড</label>
                          <input
                            type="text"
                            value={editingSubject.code || ''}
                            onChange={e => setEditingSubject({ ...editingSubject, code: e.target.value })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">পরীক্ষার ধরণ</label>
                          <select
                            value={editingSubject.examType || 'both'}
                            onChange={e => setEditingSubject({ ...editingSubject, examType: e.target.value as ExamType })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded"
                          >
                            <option value="both">Both (প্রিলি + লিখিত)</option>
                            <option value="preliminary">Preliminary Only</option>
                            <option value="written">Written Only</option>
                          </select>
                        </div>
                      </div>
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">বিবরণ</label>
                        <textarea
                          rows={2}
                          value={editingSubject.description || ''}
                          onChange={e => setEditingSubject({ ...editingSubject, description: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button
                        onClick={() => setEditingSubject(null)}
                        className="px-3 py-1.5 bg-slate-100 text-slate-700 text-xs rounded hover:bg-slate-200"
                      >
                        বাতিল
                      </button>
                      <button
                        onClick={() => {
                          if (editingSubject.titleBn && editingSubject.id) {
                            DatabaseService.saveSubject(editingSubject as Subject);
                            setEditingSubject(null);
                            showToast('Subject saved successfully.');
                          }
                        }}
                        className="px-4 py-1.5 bg-blue-900 text-white text-xs font-semibold rounded hover:bg-blue-800"
                      >
                        সংরক্ষণ করুন
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 3: CHAPTERS & TOPICS */}
          {activeTab === 'chapters' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">অধ্যায় ও টপিক (Chapters & Topics)</h2>
                  <p className="text-xs text-slate-500">প্রতিটি বিষয়ের অধ্যায় তৈরি ও সাজান</p>
                </div>
                <button
                  onClick={() => setEditingChapter({
                    id: `ch_${Date.now()}`,
                    subjectId: subjects[0]?.id || '',
                    titleBn: '',
                    titleEn: '',
                    orderIndex: chapters.length + 1,
                    isPublished: true
                  })}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন অধ্যায় যুক্ত করুন</span>
                </button>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="px-4 py-3">অধ্যায়</th>
                      <th className="px-4 py-3">বিষয়</th>
                      <th className="px-4 py-3">লেকচার সংখ্যা</th>
                      <th className="px-4 py-3 text-right">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {chapters.map(ch => {
                      const parentSub = subjects.find(s => s.id === ch.subjectId);
                      const lecCount = lectures.filter(l => l.chapterId === ch.id).length;
                      return (
                        <tr key={ch.id} className="hover:bg-slate-50/70">
                          <td className="px-4 py-3">
                            <span className="font-semibold text-slate-900">{ch.titleBn}</span>
                            <span className="text-[11px] text-slate-400 block">{ch.titleEn}</span>
                          </td>
                          <td className="px-4 py-3 text-slate-600">{parentSub?.titleBn || ch.subjectId}</td>
                          <td className="px-4 py-3 font-mono">{lecCount}টি</td>
                          <td className="px-4 py-3 text-right space-x-2">
                            <button onClick={() => setEditingChapter(ch)} className="p-1 text-slate-500 hover:text-blue-900">
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm('Delete this chapter?')) {
                                  DatabaseService.deleteChapter(ch.id);
                                  showToast('Chapter deleted.');
                                }
                              }}
                              className="p-1 text-slate-500 hover:text-rose-600"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Chapter Modal */}
              {editingChapter && (
                <div className="fixed inset-0 z-50 bg-slate-950/70 flex items-center justify-center p-4">
                  <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">অধ্যায় সম্পাদনা</h3>
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">মূল বিষয় (Subject)</label>
                        <select
                          value={editingChapter.subjectId || ''}
                          onChange={e => setEditingChapter({ ...editingChapter, subjectId: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        >
                          {subjects.map(s => (
                            <option key={s.id} value={s.id}>{s.titleBn} ({s.code})</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">অধ্যায়ের নাম (বাংলা)</label>
                        <input
                          type="text"
                          value={editingChapter.titleBn || ''}
                          onChange={e => setEditingChapter({ ...editingChapter, titleBn: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">অধ্যায়ের নাম (ইংরেজি)</label>
                        <input
                          type="text"
                          value={editingChapter.titleEn || ''}
                          onChange={e => setEditingChapter({ ...editingChapter, titleEn: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <button onClick={() => setEditingChapter(null)} className="px-3 py-1.5 bg-slate-100 text-xs rounded">বাতিল</button>
                      <button
                        onClick={() => {
                          if (editingChapter.titleBn && editingChapter.id && editingChapter.subjectId) {
                            DatabaseService.saveChapter(editingChapter as Chapter);
                            setEditingChapter(null);
                            showToast('Chapter saved.');
                          }
                        }}
                        className="px-4 py-1.5 bg-blue-900 text-white text-xs font-semibold rounded"
                      >
                        সংরক্ষণ
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 4: LECTURES (The Master Form as specified in Section 7 of master prompt) */}
          {activeTab === 'lectures' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">লেকচার ম্যানেজমেন্ট সিস্টেম (Lectures)</h2>
                  <p className="text-xs text-slate-500">ইউটিউব ভিডিও ও গুগল ড্রাইভ ক্লাস নোট সহ লেকচার তৈরি ও নিয়ন্ত্রণ</p>
                </div>
                <button
                  onClick={() => setEditingLecture({
                    id: `lec_${Date.now()}`,
                    subjectId: subjects[0]?.id || '',
                    chapterId: chapters[0]?.id || '',
                    courseIds: courses.map(c => c.id),
                    titleBn: '',
                    titleEn: '',
                    examType: 'both',
                    description: '',
                    youtubeUrl: 'https://www.youtube.com/watch?v=dQw4w9WgXcQ',
                    driveNotesUrl: '',
                    teacherName: 'Abrar',
                    lectureNumber: lectures.length + 1,
                    durationMinutes: 45,
                    tags: ['BCS'],
                    isFreePreview: false,
                    publicationStatus: 'published',
                    accessType: 'enrolled_students',
                    orderIndex: lectures.length + 1,
                    createdAt: new Date().toISOString()
                  })}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন লেকচার তৈরি করুন</span>
                </button>
              </div>

              {/* Lectures List */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="px-4 py-3">লেকচার</th>
                      <th className="px-4 py-3">বিষয় ও শিক্ষক</th>
                      <th className="px-4 py-3">অ্যাক্সেস ধরণ</th>
                      <th className="px-4 py-3">ড্রাইভ নোটস</th>
                      <th className="px-4 py-3">স্ট্যাটাস</th>
                      <th className="px-4 py-3 text-right">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {lectures.map(lec => {
                      const sub = subjects.find(s => s.id === lec.subjectId);
                      return (
                        <tr key={lec.id} className="hover:bg-slate-50/70">
                          <td className="px-4 py-3">
                            <span className="font-semibold text-slate-900">{lec.titleBn}</span>
                            <span className="text-[11px] text-slate-400 block">{lec.durationMinutes} মিনিট · #{lec.lectureNumber}</span>
                          </td>
                          <td className="px-4 py-3">
                            <span className="text-slate-800 font-medium">{sub?.titleBn || lec.subjectId}</span>
                            <span className="text-[11px] text-slate-400 block">{lec.teacherName}</span>
                          </td>
                          <td className="px-4 py-3">
                            <span className="capitalize px-2 py-0.5 rounded text-[10px] bg-slate-100 text-slate-700">
                              {lec.accessType.replace('_', ' ')}
                            </span>
                            {lec.isFreePreview && (
                              <span className="ml-1 text-[10px] text-teal-700 font-bold">Free</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            {lec.driveNotesUrl ? (
                              <a href={lec.driveNotesUrl} target="_blank" rel="noreferrer" className="text-blue-700 hover:underline flex items-center gap-1 text-[11px]">
                                <ExternalLink className="w-3 h-3" />
                                <span>Drive Note</span>
                              </a>
                            ) : (
                              <span className="text-slate-300 text-[11px]">None</span>
                            )}
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-semibold ${
                              lec.publicationStatus === 'published' ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-600'
                            }`}>
                              {lec.publicationStatus}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right space-x-2">
                            <button onClick={() => setEditingLecture(lec)} className="p-1 text-slate-500 hover:text-blue-900">
                              <Edit2 className="w-4 h-4" />
                            </button>
                            <button
                              onClick={() => {
                                if (confirm(`Delete lecture "${lec.titleBn}"?`)) {
                                  DatabaseService.deleteLecture(lec.id);
                                  showToast('Lecture deleted.');
                                }
                              }}
                              className="p-1 text-slate-500 hover:text-rose-600"
                            >
                              <Trash2 className="w-4 h-4" />
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Lecture Master Form Modal */}
              {editingLecture && (
                <div className="fixed inset-0 z-50 bg-slate-950/70 flex items-center justify-center p-4 overflow-y-auto">
                  <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full p-6 space-y-4 my-8 max-h-[90vh] overflow-y-auto">
                    <div className="flex items-center justify-between border-b pb-3">
                      <h3 className="text-base font-bold text-slate-900">
                        লেকচার ফরম (Lecture Management Form)
                      </h3>
                      <button onClick={() => setEditingLecture(null)} className="p-1 text-slate-400 hover:text-slate-600">
                        <X className="w-5 h-5" />
                      </button>
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs">
                      <div className="sm:col-span-2">
                        <label className="block text-slate-700 font-medium mb-1">লেকচার শিরোনাম (বাংলা)</label>
                        <input
                          type="text"
                          required
                          value={editingLecture.titleBn || ''}
                          onChange={e => setEditingLecture({ ...editingLecture, titleBn: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                          placeholder="যেমন: বাংলাদেশের সংবিধান পরিচিতি ও মূলনীতিসমূহ"
                        />
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-slate-700 font-medium mb-1">লেকচার শিরোনাম (ইংরেজি)</label>
                        <input
                          type="text"
                          value={editingLecture.titleEn || ''}
                          onChange={e => setEditingLecture({ ...editingLecture, titleEn: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                          placeholder="Introduction to Bangladesh Constitution"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">বিষয় (Subject)</label>
                        <select
                          value={editingLecture.subjectId || ''}
                          onChange={e => setEditingLecture({ ...editingLecture, subjectId: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        >
                          {subjects.map(s => (
                            <option key={s.id} value={s.id}>{s.titleBn}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">অধ্যায় (Chapter)</label>
                        <select
                          value={editingLecture.chapterId || ''}
                          onChange={e => setEditingLecture({ ...editingLecture, chapterId: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        >
                          {chapters
                            .filter(c => !editingLecture.subjectId || c.subjectId === editingLecture.subjectId)
                            .map(c => (
                              <option key={c.id} value={c.id}>{c.titleBn}</option>
                            ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">ইউটিউব ভিডিও লিঙ্ক (YouTube URL)</label>
                        <input
                          type="text"
                          required
                          value={editingLecture.youtubeUrl || ''}
                          onChange={e => setEditingLecture({ ...editingLecture, youtubeUrl: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono text-[11px]"
                          placeholder="https://www.youtube.com/watch?v=..."
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">গুগল ড্রাইভ ক্লাস নোট লিঙ্ক (Drive URL)</label>
                        <input
                          type="text"
                          value={editingLecture.driveNotesUrl || ''}
                          onChange={e => setEditingLecture({ ...editingLecture, driveNotesUrl: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono text-[11px]"
                          placeholder="https://drive.google.com/file/d/.../view"
                        />
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">শিক্ষকের নাম</label>
                        <input
                          type="text"
                          value={editingLecture.teacherName || 'Abrar'}
                          onChange={e => setEditingLecture({ ...editingLecture, teacherName: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        />
                      </div>

                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">লেকচার নং</label>
                          <input
                            type="number"
                            value={editingLecture.lectureNumber || 1}
                            onChange={e => setEditingLecture({ ...editingLecture, lectureNumber: parseInt(e.target.value) || 1 })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">সময় (মিনিট)</label>
                          <input
                            type="number"
                            value={editingLecture.durationMinutes || 45}
                            onChange={e => setEditingLecture({ ...editingLecture, durationMinutes: parseInt(e.target.value) || 45 })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                          />
                        </div>
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">অ্যাক্সেস অনুমতির ধরণ (Access Type)</label>
                        <select
                          value={editingLecture.accessType || 'enrolled_students'}
                          onChange={e => setEditingLecture({ ...editingLecture, accessType: e.target.value as any })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded font-medium"
                        >
                          <option value="public">Public (সবার জন্য উন্মুক্ত)</option>
                          <option value="free_preview">Free Preview (ফ্রি ডেমো)</option>
                          <option value="enrolled_students">Enrolled Students (কোর্সে ভর্তি হওয়া শিক্ষার্থী)</option>
                          <option value="approved_students">Approved Students (এডমিন অনুমোদিত শিক্ষার্থী)</option>
                          <option value="specific_batch">Specific Batch (নির্দিষ্ট ব্যাচ)</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">প্রকাশনা স্ট্যাটাস</label>
                        <select
                          value={editingLecture.publicationStatus || 'published'}
                          onChange={e => setEditingLecture({ ...editingLecture, publicationStatus: e.target.value as any })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        >
                          <option value="published">Published (প্রকাশিত)</option>
                          <option value="draft">Draft (খসড়া)</option>
                          <option value="archived">Archived (আর্কাইভ)</option>
                        </select>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="flex items-center gap-2 cursor-pointer pt-1">
                          <input
                            type="checkbox"
                            checked={Boolean(editingLecture.isFreePreview)}
                            onChange={e => setEditingLecture({ ...editingLecture, isFreePreview: e.target.checked })}
                            className="rounded text-teal-600 focus:ring-teal-500"
                          />
                          <span className="text-slate-800 font-semibold">
                            এটি কি ফ্রি ডেমো লেকচার হিসেবে ওয়েবসাইটে প্রদর্শন করবেন? (Free Demo Toggle)
                          </span>
                        </label>
                      </div>

                      <div className="sm:col-span-2">
                        <label className="block text-slate-700 font-medium mb-1">লেকচারের বিবরণ</label>
                        <textarea
                          rows={3}
                          value={editingLecture.description || ''}
                          onChange={e => setEditingLecture({ ...editingLecture, description: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                          placeholder="এই ক্লাসে আলোচিত মূল অংশসমূহ..."
                        />
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-3 border-t">
                      <button onClick={() => setEditingLecture(null)} className="px-4 py-2 bg-slate-100 text-slate-700 text-xs rounded">
                        বাতিল
                      </button>
                      <button
                        onClick={() => {
                          if (editingLecture.titleBn && editingLecture.youtubeUrl && editingLecture.id) {
                            DatabaseService.saveLecture(editingLecture as Lecture);
                            setEditingLecture(null);
                            showToast('Lecture saved and published.');
                          } else {
                            alert('Please provide lecture title and YouTube link.');
                          }
                        }}
                        className="px-5 py-2 bg-blue-900 text-white text-xs font-semibold rounded hover:bg-blue-800"
                      >
                        সংরক্ষণ ও প্রকাশ করুন
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 5: COURSES & PACKAGES */}
          {activeTab === 'courses' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">কোর্স ও প্যাকেজ (Courses & Packages)</h2>
                  <p className="text-xs text-slate-500">কোর্সের ফি, অফার ও সিলেবাস সমন্বয়</p>
                </div>
                <button
                  onClick={() => setEditingCourse({
                    id: `crs_${Date.now()}`,
                    titleBn: '',
                    titleEn: '',
                    slug: `course-${Date.now()}`,
                    category: 'complete',
                    description: '',
                    thumbnailUrl: '/src/assets/images/bcs_hero_education_1791590008571.jpg',
                    subjectIds: subjects.map(s => s.id),
                    durationWeeks: 24,
                    regularPriceBdt: 4000,
                    promotionalPriceBdt: 3000,
                    enrollmentStatus: 'open',
                    features: ['লাইভ ও রেকর্ডেড ক্লাস', 'গুগল ড্রাইভ হ্যান্ডনোট'],
                    accessDays: 365,
                    isPublished: true,
                    isFeatured: false,
                    createdAt: new Date().toISOString()
                  })}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন কোর্স তৈরি করুন</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {courses.map(course => (
                  <div key={course.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
                    <div className="flex items-baseline justify-between text-xs">
                      <span className="font-mono text-teal-700 uppercase font-semibold">{course.category}</span>
                      <span className="font-bold text-blue-950 font-mono">
                        ৳{(course.promotionalPriceBdt || course.regularPriceBdt).toLocaleString()}
                      </span>
                    </div>
                    <h3 className="text-sm font-bold text-slate-900 line-clamp-2">{course.titleBn}</h3>
                    <p className="text-xs text-slate-500 line-clamp-2">{course.description}</p>
                    <div className="text-[11px] text-slate-400 font-mono">
                      মেয়াদ: {course.durationWeeks} সপ্তাহ · অ্যাক্সেস: {course.accessDays} দিন
                    </div>
                    <div className="flex items-center justify-end gap-2 pt-2 border-t border-slate-100">
                      <button onClick={() => setEditingCourse(course)} className="px-2.5 py-1 bg-slate-100 hover:bg-slate-200 rounded text-xs text-slate-700">
                        সম্পাদনা
                      </button>
                      <button
                        onClick={() => {
                          if (confirm(`Delete course "${course.titleBn}"?`)) {
                            DatabaseService.deleteCourse(course.id);
                            showToast('Course deleted.');
                          }
                        }}
                        className="p-1 text-slate-400 hover:text-rose-600"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Course Modal */}
              {editingCourse && (
                <div className="fixed inset-0 z-50 bg-slate-950/70 flex items-center justify-center p-4 overflow-y-auto">
                  <div className="bg-white rounded-xl shadow-xl max-w-xl w-full p-6 space-y-4 my-8">
                    <h3 className="text-base font-bold text-slate-900">কোর্স সেটিংস</h3>
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">কোর্স শিরোনাম (বাংলা)</label>
                        <input
                          type="text"
                          value={editingCourse.titleBn || ''}
                          onChange={e => setEditingCourse({ ...editingCourse, titleBn: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">রেগুলার ফি (BDT ৳)</label>
                          <input
                            type="number"
                            value={editingCourse.regularPriceBdt || 0}
                            onChange={e => setEditingCourse({ ...editingCourse, regularPriceBdt: parseInt(e.target.value) || 0 })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">অফার ফি (BDT ৳)</label>
                          <input
                            type="number"
                            value={editingCourse.promotionalPriceBdt || 0}
                            onChange={e => setEditingCourse({ ...editingCourse, promotionalPriceBdt: parseInt(e.target.value) || 0 })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">ক্যাটাগরি</label>
                          <select
                            value={editingCourse.category || 'complete'}
                            onChange={e => setEditingCourse({ ...editingCourse, category: e.target.value as any })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded"
                          >
                            <option value="complete">Complete (প্রিলি + লিখিত)</option>
                            <option value="preliminary">Preliminary</option>
                            <option value="written">Written</option>
                            <option value="subject_wise">Subject Wise</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">অ্যাক্সেস মেয়াদ (দিন)</label>
                          <input
                            type="number"
                            value={editingCourse.accessDays || 365}
                            onChange={e => setEditingCourse({ ...editingCourse, accessDays: parseInt(e.target.value) || 365 })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                          />
                        </div>
                      </div>
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">বিবরণ</label>
                        <textarea
                          rows={3}
                          value={editingCourse.description || ''}
                          onChange={e => setEditingCourse({ ...editingCourse, description: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <button onClick={() => setEditingCourse(null)} className="px-3 py-1.5 bg-slate-100 text-xs rounded">বাতিল</button>
                      <button
                        onClick={() => {
                          if (editingCourse.titleBn && editingCourse.id) {
                            DatabaseService.saveCourse(editingCourse as Course);
                            setEditingCourse(null);
                            showToast('Course saved.');
                          }
                        }}
                        className="px-4 py-1.5 bg-blue-900 text-white text-xs font-semibold rounded"
                      >
                        সংরক্ষণ
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 6: BATCHES */}
          {activeTab === 'batches' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">ব্যাচ ম্যানেজমেন্ট (Batches)</h2>
                  <p className="text-xs text-slate-500">বিসিএস প্রিলিমিনারি ও লিখিত ব্যাচ পরিচালনা</p>
                </div>
                <button
                  onClick={() => setEditingBatch({
                    id: `btc_${Date.now()}`,
                    courseId: courses[0]?.id || '',
                    name: 'BCS Preliminary Batch 02',
                    description: '',
                    startDate: '2026-04-01',
                    endDate: '2026-09-30',
                    maxStudents: 150,
                    enrolledStudentsCount: 0,
                    isActive: true,
                    createdAt: new Date().toISOString()
                  })}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন ব্যাচ তৈরি করুন</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {batches.map(batch => (
                  <div key={batch.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-2">
                    <span className="text-[10px] font-semibold uppercase px-2 py-0.5 rounded bg-blue-50 text-blue-800">
                      {batch.isActive ? 'Active Batch' : 'Inactive'}
                    </span>
                    <h3 className="text-sm font-bold text-slate-900">{batch.name}</h3>
                    <p className="text-xs text-slate-500">{batch.description || 'নিয়মিত ব্যাচ'}</p>
                    <div className="pt-2 text-xs font-mono text-slate-600">
                      ধারণক্ষমতা: {batch.enrolledStudentsCount} / {batch.maxStudents} শিক্ষার্থী
                    </div>
                    <div className="flex justify-end gap-2 pt-2 border-t">
                      <button
                        onClick={() => {
                          if (confirm('Delete this batch?')) {
                            DatabaseService.deleteBatch(batch.id);
                            showToast('Batch deleted.');
                          }
                        }}
                        className="text-xs text-rose-600 hover:underline"
                      >
                        ডিলিট
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* TAB 7: STUDENTS */}
          {activeTab === 'students' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">শিক্ষার্থী ও অ্যাকাউন্ট (Students)</h2>
                  <p className="text-xs text-slate-500">অনুমোদন ও রোল পরিবর্তন (Student, Content Manager, Super Admin)</p>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="px-4 py-3">শিক্ষার্থী</th>
                      <th className="px-4 py-3">ইমেইল ও ফোন</th>
                      <th className="px-4 py-3">রোল</th>
                      <th className="px-4 py-3">স্ট্যাটাস</th>
                      <th className="px-4 py-3 text-right">অনুমোদন অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {profiles.map(p => (
                      <tr key={p.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-3">
                          <span className="font-semibold text-slate-900">{p.fullName}</span>
                          <span className="text-[11px] text-slate-400 block">{p.targetBcsCadre || p.district}</span>
                        </td>
                        <td className="px-4 py-3 font-mono">
                          <div>{p.email}</div>
                          <div className="text-slate-400">{p.phone}</div>
                        </td>
                        <td className="px-4 py-3">
                          <select
                            value={p.role}
                            disabled={p.id === currentUser.id}
                            onChange={e => {
                              DatabaseService.updateProfileStatus(p.id, p.status, e.target.value as UserRole);
                              showToast(`Role updated to ${e.target.value}.`);
                            }}
                            className="text-xs px-2 py-1 border border-slate-300 rounded font-medium"
                          >
                            <option value="student">Student</option>
                            <option value="content_manager">Content Manager</option>
                            <option value="super_admin">Super Admin</option>
                          </select>
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                            p.status === 'approved' ? 'bg-emerald-50 text-emerald-700' : p.status === 'pending' ? 'bg-amber-50 text-amber-700' : 'bg-rose-50 text-rose-700'
                          }`}>
                            {p.status}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right space-x-1.5">
                          {p.status === 'pending' && (
                            <button
                              onClick={() => {
                                DatabaseService.updateProfileStatus(p.id, 'approved');
                                showToast(`${p.fullName} has been approved.`);
                              }}
                              className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-semibold"
                            >
                              অনুমোদন দিন (Approve)
                            </button>
                          )}
                          {p.status === 'approved' && p.role !== 'super_admin' && (
                            <button
                              onClick={() => {
                                DatabaseService.updateProfileStatus(p.id, 'suspended');
                                showToast(`${p.fullName} suspended.`);
                              }}
                              className="px-2 py-1 bg-slate-100 hover:bg-slate-200 text-slate-600 rounded text-[11px]"
                            >
                              স্থগিত (Suspend)
                            </button>
                          )}
                          {p.status === 'suspended' && (
                            <button
                              onClick={() => {
                                DatabaseService.updateProfileStatus(p.id, 'approved');
                                showToast('Activated.');
                              }}
                              className="px-2 py-1 bg-emerald-100 text-emerald-800 rounded text-[11px]"
                            >
                              পুনর্বহাল (Reactivate)
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 8: ENROLLMENTS */}
          {activeTab === 'enrollments' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">কোর্স এনরোলমেন্ট ও অনুমতি (Enrollments)</h2>
                  <p className="text-xs text-slate-500">ম্যানুয়াল কোর্স অ্যাক্সেস প্রদান ও প্রত্যাহার</p>
                </div>
                <button
                  onClick={() => setEnrollModal({ open: true, studentId: profiles[1]?.id || '', courseId: courses[0]?.id || '', days: 365 })}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>কোর্স অ্যাক্সেস দিন (Grant Access)</span>
                </button>
              </div>

              {/* Pending Access Requests review */}
              {requests.filter(r => r.status === 'pending').length > 0 && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 space-y-3">
                  <h3 className="text-xs font-bold text-amber-900">
                    পেন্ডিং শিক্ষার্থী অ্যাক্সেস রিকোয়েস্ট ({requests.filter(r => r.status === 'pending').length}টি)
                  </h3>
                  <div className="divide-y divide-amber-200/60 text-xs">
                    {requests.filter(r => r.status === 'pending').map(req => (
                      <div key={req.id} className="py-2.5 flex items-center justify-between">
                        <div>
                          <span className="font-semibold text-slate-900">{req.userName}</span>
                          <span className="text-slate-600 ml-2">কোর্স: <strong>{req.courseTitle}</strong></span>
                          <div className="text-[11px] text-slate-500 font-mono">ফোন: {req.userPhone} · {req.message}</div>
                        </div>
                        <div className="space-x-2">
                          <button
                            onClick={() => {
                              DatabaseService.updateAccessRequestStatus(req.id, 'approved');
                              showToast(`Approved access for ${req.userName}.`);
                            }}
                            className="px-3 py-1 bg-emerald-600 text-white font-semibold rounded"
                          >
                            অনুমোদন করুন (Approve)
                          </button>
                          <button
                            onClick={() => {
                              DatabaseService.updateAccessRequestStatus(req.id, 'rejected');
                              showToast('Request rejected.');
                            }}
                            className="px-2.5 py-1 bg-slate-200 text-slate-700 rounded"
                          >
                            বাতিল
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Active Enrollments Table */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="px-4 py-3">শিক্ষার্থী</th>
                      <th className="px-4 py-3">কোর্স</th>
                      <th className="px-4 py-3">শুরুর তারিখ</th>
                      <th className="px-4 py-3">মেয়াদ শেষ</th>
                      <th className="px-4 py-3">স্ট্যাটাস</th>
                      <th className="px-4 py-3 text-right">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {enrollments.map(enr => {
                      const user = profiles.find(p => p.id === enr.userId);
                      const course = courses.find(c => c.id === enr.courseId);
                      return (
                        <tr key={enr.id} className="hover:bg-slate-50/70">
                          <td className="px-4 py-3">
                            <span className="font-semibold text-slate-900">{user?.fullName || enr.userId}</span>
                            <span className="text-[11px] text-slate-400 font-mono block">{user?.email}</span>
                          </td>
                          <td className="px-4 py-3 font-medium text-slate-800">{course?.titleBn || enr.courseId}</td>
                          <td className="px-4 py-3 font-mono text-[11px] text-slate-500">
                            {new Date(enr.startDate).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3 font-mono text-[11px] text-slate-500">
                            {new Date(enr.expiresAt).toLocaleDateString()}
                          </td>
                          <td className="px-4 py-3">
                            <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                              enr.status === 'active' ? 'bg-emerald-50 text-emerald-700' : 'bg-rose-50 text-rose-700'
                            }`}>
                              {enr.status}
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right">
                            {enr.status === 'active' && (
                              <button
                                onClick={() => {
                                  if (confirm('Revoke access for this enrollment?')) {
                                    DatabaseService.revokeEnrollment(enr.id);
                                    showToast('Enrollment revoked.');
                                  }
                                }}
                                className="text-xs text-rose-600 hover:underline font-medium"
                              >
                                অ্যাক্সেস বাতিল (Revoke)
                              </button>
                            )}
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>

              {/* Grant Enrollment Modal */}
              {enrollModal.open && (
                <div className="fixed inset-0 z-50 bg-slate-950/70 flex items-center justify-center p-4">
                  <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">ম্যানুয়াল কোর্স ভর্তি ও অ্যাক্সেস প্রদান</h3>
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">শিক্ষার্থী নির্বাচন করুন</label>
                        <select
                          value={enrollModal.studentId}
                          onChange={e => setEnrollModal({ ...enrollModal, studentId: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        >
                          {profiles.filter(p => p.role === 'student').map(s => (
                            <option key={s.id} value={s.id}>{s.fullName} ({s.email})</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">কোর্স নির্বাচন করুন</label>
                        <select
                          value={enrollModal.courseId}
                          onChange={e => setEnrollModal({ ...enrollModal, courseId: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        >
                          {courses.map(c => (
                            <option key={c.id} value={c.id}>{c.titleBn}</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">অ্যাক্সেস মেয়াদ (দিন)</label>
                        <select
                          value={enrollModal.days}
                          onChange={e => setEnrollModal({ ...enrollModal, days: parseInt(e.target.value) || 365 })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                        >
                          <option value="30">30 Days</option>
                          <option value="90">90 Days</option>
                          <option value="180">180 Days</option>
                          <option value="365">365 Days (1 Year)</option>
                        </select>
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button onClick={() => setEnrollModal({ ...enrollModal, open: false })} className="px-3 py-1.5 bg-slate-100 text-xs rounded">
                        বাতিল
                      </button>
                      <button
                        onClick={() => {
                          DatabaseService.grantEnrollment({
                            userId: enrollModal.studentId,
                            courseId: enrollModal.courseId,
                            durationDays: enrollModal.days
                          });
                          setEnrollModal({ ...enrollModal, open: false });
                          showToast('Course access granted successfully.');
                        }}
                        className="px-4 py-1.5 bg-blue-900 text-white text-xs font-semibold rounded hover:bg-blue-800"
                      >
                        অ্যাক্সেস প্রদান করুন
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 9: ACCESS CONTROL (GRANULAR) */}
          {activeTab === 'access_control' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">গ্র্যানুলার অ্যাক্সেস কন্ট্রোল (Granular Permissions)</h2>
                  <p className="text-xs text-slate-500">
                    নির্দিষ্ট শিক্ষার্থীকে একক বিষয়, অধ্যায় বা নির্দিষ্ট লেকচারে বিশেষ পারমিশন দিন
                  </p>
                </div>
                <button
                  onClick={() => setPermModal({
                    open: true,
                    userId: profiles[1]?.id || '',
                    entityType: 'subject',
                    entityId: subjects[0]?.id || '',
                    isGranted: true
                  })}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>বিশেষ পারমিশন সেট করুন</span>
                </button>
              </div>

              {/* Permissions table */}
              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="px-4 py-3">শিক্ষার্থী</th>
                      <th className="px-4 py-3">লেভেল (Entity Type)</th>
                      <th className="px-4 py-3">আইডি / বিবরণ</th>
                      <th className="px-4 py-3">অনুমতি</th>
                      <th className="px-4 py-3 text-right">অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {permissions.map(perm => {
                      const user = profiles.find(p => p.id === perm.userId);
                      return (
                        <tr key={perm.id} className="hover:bg-slate-50/70">
                          <td className="px-4 py-3 font-semibold text-slate-900">{user?.fullName || perm.userId}</td>
                          <td className="px-4 py-3 uppercase font-mono text-blue-900">{perm.entityType}</td>
                          <td className="px-4 py-3 font-mono text-[11px] text-slate-600">{perm.entityId}</td>
                          <td className="px-4 py-3">
                            <span className="px-2 py-0.5 rounded bg-emerald-50 text-emerald-700 text-[10px] font-bold">
                              GRANTED
                            </span>
                          </td>
                          <td className="px-4 py-3 text-right">
                            <button
                              onClick={() => {
                                DatabaseService.setPermission(perm.userId, perm.entityType, perm.entityId, false);
                                showToast('Permission removed.');
                              }}
                              className="text-xs text-rose-600 hover:underline"
                            >
                              রিমুভ
                            </button>
                          </td>
                        </tr>
                      );
                    })}
                    {permissions.length === 0 && (
                      <tr>
                        <td colSpan={5} className="p-8 text-center text-slate-400 italic">
                          কোনো বিশেষ কাস্টম পারমিশন সেট করা নেই। শিক্ষার্থীরা কোর্স ভিত্তিক অ্যাক্সেস পাচ্ছে।
                        </td>
                      </tr>
                    )}
                  </tbody>
                </table>
              </div>

              {/* Perm Modal */}
              {permModal.open && (
                <div className="fixed inset-0 z-50 bg-slate-950/70 flex items-center justify-center p-4">
                  <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">বিশেষ পারমিশন কনফিগারেশন</h3>
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">শিক্ষার্থী</label>
                        <select
                          value={permModal.userId}
                          onChange={e => setPermModal({ ...permModal, userId: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        >
                          {profiles.filter(p => p.role === 'student').map(s => (
                            <option key={s.id} value={s.id}>{s.fullName} ({s.email})</option>
                          ))}
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">অ্যাক্সেস লেভেল</label>
                        <select
                          value={permModal.entityType}
                          onChange={e => setPermModal({ ...permModal, entityType: e.target.value as any })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        >
                          <option value="subject">Subject Level</option>
                          <option value="chapter">Chapter Level</option>
                          <option value="lecture">Lecture Level</option>
                        </select>
                      </div>

                      <div>
                        <label className="block text-slate-700 font-medium mb-1">টার্গেট নির্বাচন করুন</label>
                        {permModal.entityType === 'subject' && (
                          <select
                            value={permModal.entityId}
                            onChange={e => setPermModal({ ...permModal, entityId: e.target.value })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded"
                          >
                            {subjects.map(s => (
                              <option key={s.id} value={s.id}>{s.titleBn}</option>
                            ))}
                          </select>
                        )}
                        {permModal.entityType === 'chapter' && (
                          <select
                            value={permModal.entityId}
                            onChange={e => setPermModal({ ...permModal, entityId: e.target.value })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded"
                          >
                            {chapters.map(c => (
                              <option key={c.id} value={c.id}>{c.titleBn}</option>
                            ))}
                          </select>
                        )}
                        {permModal.entityType === 'lecture' && (
                          <select
                            value={permModal.entityId}
                            onChange={e => setPermModal({ ...permModal, entityId: e.target.value })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded"
                          >
                            {lectures.map(l => (
                              <option key={l.id} value={l.id}>{l.titleBn}</option>
                            ))}
                          </select>
                        )}
                      </div>
                    </div>

                    <div className="flex justify-end gap-2 pt-2">
                      <button onClick={() => setPermModal({ ...permModal, open: false })} className="px-3 py-1.5 bg-slate-100 text-xs rounded">
                        বাতিল
                      </button>
                      <button
                        onClick={() => {
                          DatabaseService.setPermission(permModal.userId, permModal.entityType, permModal.entityId, true);
                          setPermModal({ ...permModal, open: false });
                          showToast('Permission granted.');
                        }}
                        className="px-4 py-1.5 bg-blue-900 text-white text-xs font-semibold rounded hover:bg-blue-800"
                      >
                        অনুমতি দিন
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 10: PAYMENTS */}
          {activeTab === 'payments' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">পেমেন্ট ও ট্রানজেকশন (Payments)</h2>
                  <p className="text-xs text-slate-500">ম্যানুয়াল bKash, Nagad ও Bank পেমেন্ট ভেরিফিকেশন</p>
                </div>
                <button
                  onClick={() => {
                    const csvData = payments.map(p => ({
                      PaymentID: p.id,
                      StudentEmail: p.userEmail,
                      Course: p.courseTitle,
                      AmountBDT: p.amountBdt,
                      Method: p.paymentMethod,
                      TrxID: p.transactionRef,
                      Status: p.verificationStatus,
                      Date: p.createdAt
                    }));
                    DatabaseService.exportToCsv(csvData, 'BCS_Payments');
                  }}
                  className="px-3 py-1.5 bg-slate-800 text-white hover:bg-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>CSV ডাউনলোড</span>
                </button>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="px-4 py-3">পেমেন্ট আইডি / TrxID</th>
                      <th className="px-4 py-3">শিক্ষার্থী ও কোর্স</th>
                      <th className="px-4 py-3">পরিমাণ</th>
                      <th className="px-4 py-3">মাধ্যম</th>
                      <th className="px-4 py-3">স্ট্যাটাস</th>
                      <th className="px-4 py-3 text-right">ভেরিফিকেশন অ্যাকশন</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {payments.map(pay => (
                      <tr key={pay.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-3">
                          <span className="font-mono font-bold text-blue-900">{pay.transactionRef || 'N/A'}</span>
                          <span className="text-[11px] text-slate-400 font-mono block">Sender: {pay.senderPhone}</span>
                        </td>
                        <td className="px-4 py-3">
                          <div className="font-semibold text-slate-900">{pay.courseTitle}</div>
                          <div className="text-[11px] text-slate-500 font-mono">{pay.userEmail}</div>
                        </td>
                        <td className="px-4 py-3 font-mono font-bold text-slate-900">
                          ৳{pay.amountBdt.toLocaleString()}
                        </td>
                        <td className="px-4 py-3 uppercase text-slate-600 font-mono text-[11px]">
                          {pay.paymentMethod}
                        </td>
                        <td className="px-4 py-3">
                          <span className={`px-2 py-0.5 rounded text-[10px] font-semibold uppercase ${
                            pay.verificationStatus === 'verified' ? 'bg-emerald-50 text-emerald-700' : pay.verificationStatus === 'pending' ? 'bg-rose-50 text-rose-700' : 'bg-slate-100 text-slate-600'
                          }`}>
                            {pay.verificationStatus}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-right space-x-1.5">
                          {pay.verificationStatus === 'pending' && (
                            <>
                              <button
                                onClick={() => {
                                  DatabaseService.verifyPayment(pay.id, 'verified', 'Approved by Abrar in Admin Panel.');
                                  showToast('Payment verified & course access granted.');
                                }}
                                className="px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white font-semibold rounded text-[11px]"
                              >
                                ভেরিফাই করুন (Approve)
                              </button>
                              <button
                                onClick={() => {
                                  DatabaseService.verifyPayment(pay.id, 'rejected', 'Transaction ID mismatch.');
                                  showToast('Payment rejected.');
                                }}
                                className="px-2 py-1 bg-rose-100 text-rose-800 rounded text-[11px]"
                              >
                                রিজেক্ট
                              </button>
                            </>
                          )}
                          {pay.verificationStatus === 'verified' && (
                            <span className="text-[11px] text-emerald-700 font-medium">ভেরিফাইড ও অ্যাক্সেস সক্রিয়</span>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 11: WHATSAPP INQUIRIES */}
          {activeTab === 'inquiries' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">হোয়াটসঅ্যাপ ইনকোয়ারি লিড ট্র্যাকিং (WhatsApp Leads)</h2>
                  <p className="text-xs text-slate-500">ওয়েবসাইটের ক্লিক-টু-চ্যাট থেকে আসা কোর্সের অনুসন্ধান ও ফলো-আপ</p>
                </div>
                <button
                  onClick={() => {
                    const csvData = inquiries.map(inq => ({
                      InquiryID: inq.id,
                      Course: inq.courseTitle,
                      Name: inq.contactName,
                      Phone: inq.contactPhone,
                      Email: inq.userEmail,
                      Status: inq.status,
                      Date: inq.createdAt
                    }));
                    DatabaseService.exportToCsv(csvData, 'BCS_WhatsApp_Inquiries');
                  }}
                  className="px-3 py-1.5 bg-slate-800 text-white hover:bg-slate-700 text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  <span>CSV ডাউনলোড</span>
                </button>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="px-4 py-3">শিক্ষার্থী / যোগাযোগ</th>
                      <th className="px-4 py-3">আগ্রহের কোর্স</th>
                      <th className="px-4 py-3">মেসেজ</th>
                      <th className="px-4 py-3">ফলো-আপ স্ট্যাটাস</th>
                      <th className="px-4 py-3 text-right">হোয়াটসঅ্যাপ চ্যাট</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {inquiries.map(inq => (
                      <tr key={inq.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-3">
                          <span className="font-semibold text-slate-900">{inq.contactName}</span>
                          <span className="text-[11px] text-slate-500 font-mono block">{inq.contactPhone}</span>
                        </td>
                        <td className="px-4 py-3 font-medium text-slate-800">{inq.courseTitle}</td>
                        <td className="px-4 py-3 text-slate-600 max-w-xs truncate">{inq.message}</td>
                        <td className="px-4 py-3">
                          <select
                            value={inq.status}
                            onChange={e => {
                              DatabaseService.updateInquiryStatus(inq.id, e.target.value as InquiryStatus);
                              showToast(`Status updated to ${e.target.value}`);
                            }}
                            className="text-xs px-2 py-1 border border-slate-300 rounded font-medium"
                          >
                            <option value="new">New (নতুন)</option>
                            <option value="contacted">Contacted (যোগাযোগকৃত)</option>
                            <option value="awaiting_payment">Awaiting Payment (পেমেন্টের অপেক্ষায়)</option>
                            <option value="payment_confirmed">Payment Confirmed (পেমেন্ট নিশ্চিত)</option>
                            <option value="access_granted">Access Granted (অ্যাক্সেস দেওয়া হয়েছে)</option>
                            <option value="closed">Closed (সম্পন্ন)</option>
                          </select>
                        </td>
                        <td className="px-4 py-3 text-right">
                          <a
                            href={`https://wa.me/${inq.contactPhone.replace(/[^0-9]/g, '')}?text=${encodeURIComponent(
                              `Assalamu Alaikum ${inq.contactName}. Regarding your inquiry about BCS Preparation With Abrar:`
                            )}`}
                            target="_blank"
                            rel="noreferrer"
                            className="inline-flex items-center gap-1 px-2.5 py-1 bg-emerald-600 hover:bg-emerald-500 text-white rounded text-[11px] font-semibold"
                          >
                            <span>Open WhatsApp</span>
                            <ExternalLink className="w-3 h-3" />
                          </a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}

          {/* TAB 12: COUPONS */}
          {activeTab === 'coupons' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">কুপন ও ছাড় কোড (Coupons & Offers)</h2>
                  <p className="text-xs text-slate-500">অনলাইন ও হোয়াটসঅ্যাপ ভর্তির জন্য ছাড় কোড পরিচালনা</p>
                </div>
                <button
                  onClick={() => setEditingCoupon({
                    id: `cpn_${Date.now()}`,
                    code: 'BCS2026',
                    discountType: 'percentage',
                    discountValue: 10,
                    minSpendBdt: 1000,
                    validFrom: new Date().toISOString().split('T')[0],
                    validUntil: '2026-12-31',
                    usageLimit: 100,
                    timesUsed: 0,
                    isActive: true
                  })}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন কুপন কোড তৈরি করুন</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
                {coupons.map(coupon => (
                  <div key={coupon.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
                    <div className="flex items-center justify-between">
                      <span className="font-mono text-sm font-bold text-blue-900 bg-blue-50 px-2 py-0.5 rounded border border-blue-200">
                        {coupon.code}
                      </span>
                      <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                        coupon.isActive ? 'bg-emerald-50 text-emerald-700' : 'bg-slate-100 text-slate-500'
                      }`}>
                        {coupon.isActive ? 'Active' : 'Inactive'}
                      </span>
                    </div>

                    <div className="text-xs space-y-1 text-slate-600">
                      <p className="font-semibold text-slate-800">
                        ছাড়: {coupon.discountValue}{coupon.discountType === 'percentage' ? '%' : ' ৳ BDT'}
                      </p>
                      <p>ব্যবহার: {coupon.timesUsed} / {coupon.usageLimit} বার</p>
                      <p className="text-[11px] text-slate-400">মেয়াদ শেষ: {coupon.validUntil}</p>
                    </div>

                    <div className="flex justify-end gap-2 pt-2 border-t">
                      <button
                        onClick={() => {
                          if (confirm(`Delete coupon ${coupon.code}?`)) {
                            DatabaseService.deleteCoupon(coupon.id);
                            showToast('Coupon deleted.');
                          }
                        }}
                        className="text-xs text-rose-600 hover:underline"
                      >
                        ডিলিট
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Coupon Modal */}
              {editingCoupon && (
                <div className="fixed inset-0 z-50 bg-slate-950/70 flex items-center justify-center p-4">
                  <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">কুপন কোড তৈরি</h3>
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">কুপন কোড (যেমন: BCS2026)</label>
                        <input
                          type="text"
                          value={editingCoupon.code || ''}
                          onChange={e => setEditingCoupon({ ...editingCoupon, code: e.target.value.toUpperCase() })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono uppercase font-bold"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">ছাড়ের ধরণ</label>
                          <select
                            value={editingCoupon.discountType || 'percentage'}
                            onChange={e => setEditingCoupon({ ...editingCoupon, discountType: e.target.value as any })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded"
                          >
                            <option value="percentage">শতাংশ (%)</option>
                            <option value="fixed">নির্দিষ্ট টাকা (৳)</option>
                          </select>
                        </div>
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">ছাড়ের পরিমাণ</label>
                          <input
                            type="number"
                            value={editingCoupon.discountValue || 0}
                            onChange={e => setEditingCoupon({ ...editingCoupon, discountValue: parseInt(e.target.value) || 0 })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                          />
                        </div>
                      </div>
                      <div className="grid grid-cols-2 gap-2">
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">সর্বোচ্চ ব্যবহার</label>
                          <input
                            type="number"
                            value={editingCoupon.usageLimit || 100}
                            onChange={e => setEditingCoupon({ ...editingCoupon, usageLimit: parseInt(e.target.value) || 100 })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                          />
                        </div>
                        <div>
                          <label className="block text-slate-700 font-medium mb-1">মেয়াদ শেষ</label>
                          <input
                            type="date"
                            value={editingCoupon.validUntil || ''}
                            onChange={e => setEditingCoupon({ ...editingCoupon, validUntil: e.target.value })}
                            className="w-full px-3 py-1.5 border border-slate-300 rounded font-mono"
                          />
                        </div>
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <button onClick={() => setEditingCoupon(null)} className="px-3 py-1.5 bg-slate-100 text-xs rounded">বাতিল</button>
                      <button
                        onClick={() => {
                          if (editingCoupon.code && editingCoupon.id) {
                            DatabaseService.saveCoupon(editingCoupon as Coupon);
                            setEditingCoupon(null);
                            showToast('Coupon saved.');
                          }
                        }}
                        className="px-4 py-1.5 bg-blue-900 text-white text-xs font-semibold rounded"
                      >
                        সংরক্ষণ
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 13: ANNOUNCEMENTS */}
          {activeTab === 'announcements' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">নোটিশ ও ঘোষণা (Announcements)</h2>
                  <p className="text-xs text-slate-500">সকল শিক্ষার্থী বা নির্দিষ্ট কোর্সের জন্য নোটিশ প্রকাশ</p>
                </div>
                <button
                  onClick={() => setEditingAnnouncement({
                    id: `anc_${Date.now()}`,
                    title: '',
                    content: '',
                    targetAudience: 'all',
                    priority: 'normal',
                    isPublished: true,
                    createdAt: new Date().toISOString()
                  })}
                  className="px-3 py-1.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg flex items-center gap-1.5"
                >
                  <Plus className="w-3.5 h-3.5" />
                  <span>নতুন নোটিশ লিখুন</span>
                </button>
              </div>

              <div className="space-y-3">
                {announcements.map(ann => (
                  <div key={ann.id} className="bg-white rounded-xl border border-slate-200 p-5 space-y-2 flex items-start justify-between">
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          ann.priority === 'urgent' ? 'bg-rose-100 text-rose-800' : ann.priority === 'important' ? 'bg-amber-100 text-amber-800' : 'bg-slate-100 text-slate-700'
                        }`}>
                          {ann.priority}
                        </span>
                        <span className="text-[11px] text-slate-400 font-mono">
                          {new Date(ann.createdAt).toLocaleDateString()}
                        </span>
                      </div>
                      <h3 className="text-sm font-bold text-slate-900">{ann.title}</h3>
                      <p className="text-xs text-slate-600 whitespace-pre-line">{ann.content}</p>
                    </div>
                    <button
                      onClick={() => {
                        if (confirm('Delete this announcement?')) {
                          DatabaseService.deleteAnnouncement(ann.id);
                          showToast('Announcement deleted.');
                        }
                      }}
                      className="text-xs text-rose-600 hover:underline shrink-0 ml-4"
                    >
                      ডিলিট
                    </button>
                  </div>
                ))}
              </div>

              {/* Modal */}
              {editingAnnouncement && (
                <div className="fixed inset-0 z-50 bg-slate-950/70 flex items-center justify-center p-4">
                  <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6 space-y-4">
                    <h3 className="text-sm font-bold text-slate-900">নতুন নোটিশ তৈরি</h3>
                    <div className="space-y-3 text-xs">
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">শিরোনাম</label>
                        <input
                          type="text"
                          value={editingAnnouncement.title || ''}
                          onChange={e => setEditingAnnouncement({ ...editingAnnouncement, title: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded font-semibold"
                        />
                      </div>
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">গুরুত্ব (Priority)</label>
                        <select
                          value={editingAnnouncement.priority || 'normal'}
                          onChange={e => setEditingAnnouncement({ ...editingAnnouncement, priority: e.target.value as any })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        >
                          <option value="normal">Normal</option>
                          <option value="important">Important</option>
                          <option value="urgent">Urgent</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-slate-700 font-medium mb-1">বার্তা / নোটিশের বিবরণ</label>
                        <textarea
                          rows={4}
                          value={editingAnnouncement.content || ''}
                          onChange={e => setEditingAnnouncement({ ...editingAnnouncement, content: e.target.value })}
                          className="w-full px-3 py-1.5 border border-slate-300 rounded"
                        />
                      </div>
                    </div>
                    <div className="flex justify-end gap-2 pt-2">
                      <button onClick={() => setEditingAnnouncement(null)} className="px-3 py-1.5 bg-slate-100 text-xs rounded">বাতিল</button>
                      <button
                        onClick={() => {
                          if (editingAnnouncement.title && editingAnnouncement.content && editingAnnouncement.id) {
                            DatabaseService.saveAnnouncement(editingAnnouncement as Announcement);
                            setEditingAnnouncement(null);
                            showToast('Announcement published.');
                          }
                        }}
                        className="px-4 py-1.5 bg-blue-900 text-white text-xs font-semibold rounded"
                      >
                        প্রকাশ করুন
                      </button>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* TAB 14: REPORTS & ANALYTICS */}
          {activeTab === 'reports' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">অ্যানালিটিক্স ও ডাটাবেজ রিপোর্টস (Analytics)</h2>
                  <p className="text-xs text-slate-500">বাস্তব ডাটাবেজ রেকর্ড থেকে তথ্য রফতানি ও বিশ্লেষণ</p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
                  <h3 className="text-sm font-bold text-slate-900">শিক্ষার্থী ডাটা এক্সপোর্ট</h3>
                  <p className="text-xs text-slate-500">সকল নিবন্ধিত শিক্ষার্থী ও ক্যাডার টার্গেট তালিকা CSV ফরম্যাটে সংরক্ষণ করুন।</p>
                  <button
                    onClick={() => {
                      const data = profiles.map(p => ({
                        ID: p.id,
                        Name: p.fullName,
                        Email: p.email,
                        Phone: p.phone,
                        Role: p.role,
                        Status: p.status,
                        District: p.district || '',
                        TargetCadre: p.targetBcsCadre || ''
                      }));
                      DatabaseService.exportToCsv(data, 'BCS_Students_Export');
                    }}
                    className="w-full py-2 bg-blue-900 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>শিক্ষার্থী তালিকা CSV</span>
                  </button>
                </div>

                <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
                  <h3 className="text-sm font-bold text-slate-900">পেমেন্ট লেজার এক্সপোর্ট</h3>
                  <p className="text-xs text-slate-500">যাচাইকৃত ও পেন্ডিং সকল bKash, Nagad ও অনলাইন পেমেন্ট ট্রানজেকশন।</p>
                  <button
                    onClick={() => {
                      const data = payments.map(p => ({
                        PaymentID: p.id,
                        Email: p.userEmail,
                        Course: p.courseTitle,
                        AmountBDT: p.amountBdt,
                        Method: p.paymentMethod,
                        TrxID: p.transactionRef,
                        Status: p.verificationStatus,
                        Date: p.createdAt
                      }));
                      DatabaseService.exportToCsv(data, 'BCS_Payments_Ledger');
                    }}
                    className="w-full py-2 bg-emerald-600 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>পেমেন্ট লেজার CSV</span>
                  </button>
                </div>

                <div className="bg-white p-5 rounded-xl border border-slate-200 space-y-2">
                  <h3 className="text-sm font-bold text-slate-900">হোয়াটসঅ্যাপ ইনকোয়ারি লিড</h3>
                  <p className="text-xs text-slate-500">কোর্সের জন্য আগত সকল ক্লিক-টু-চ্যাট লিড ও বর্তমান ফলো-আপ অগ্রগতি।</p>
                  <button
                    onClick={() => {
                      const data = inquiries.map(i => ({
                        ID: i.id,
                        Name: i.contactName,
                        Phone: i.contactPhone,
                        Course: i.courseTitle,
                        Status: i.status,
                        Date: i.createdAt
                      }));
                      DatabaseService.exportToCsv(data, 'BCS_Inquiries_Export');
                    }}
                    className="w-full py-2 bg-teal-600 text-white rounded text-xs font-semibold flex items-center justify-center gap-1.5"
                  >
                    <Download className="w-3.5 h-3.5" />
                    <span>ইনকোয়ারি লিড CSV</span>
                  </button>
                </div>
              </div>

              {/* Supabase SQL Schema Generator Box */}
              <div className="bg-white rounded-xl border border-slate-200 p-5 space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-slate-900">
                    Supabase PostgreSQL মাইগ্রেশন ও RLS পলিসি স্ক্রিপ্ট
                  </h3>
                  <button
                    onClick={() => {
                      navigator.clipboard.writeText(DatabaseService.getSupabaseMigrationSql());
                      showToast('SQL schema copied to clipboard!');
                    }}
                    className="px-3 py-1 bg-slate-800 hover:bg-slate-700 text-white text-xs font-semibold rounded flex items-center gap-1"
                  >
                    <Copy className="w-3 h-3" />
                    <span>কপি করুন (Copy SQL)</span>
                  </button>
                </div>
                <p className="text-xs text-slate-500">
                  আপনার ক্লাউড সুপাবেজ (Supabase SQL Editor) প্রজেক্টে এই স্ক্রিপ্ট চালিয়ে সাথে সাথে সব টেবিল, RLS নিয়মাবলী ও ইন্ডেক্স প্রস্তুত করে নিতে পারেন।
                </p>
                <pre className="p-3 bg-slate-950 text-slate-300 rounded-lg text-[11px] font-mono max-h-48 overflow-y-auto">
                  {DatabaseService.getSupabaseMigrationSql()}
                </pre>
              </div>
            </div>
          )}

          {/* TAB 15: SETTINGS */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-3xl">
              <div>
                <h2 className="text-xl font-bold text-slate-900">ওয়েবসাইট ও ব্র্যান্ড সেটিংস (Settings)</h2>
                <p className="text-xs text-slate-500">হোয়াটসঅ্যাপ নম্বর, বিকাশ মার্চেন্ট নম্বর ও মেসেজ টেমপ্লেট পরিবর্তন</p>
              </div>

              {/* Supabase Cloud Database Integration Card */}
              <div className="bg-white rounded-xl border border-slate-200 p-6 space-y-4 text-xs">
                <div className="flex items-center justify-between pb-3 border-b border-slate-100">
                  <div>
                    <h3 className="text-sm font-bold text-slate-900 flex items-center gap-2">
                      <ShieldAlert className="w-4 h-4 text-teal-600" />
                      <span>Supabase PostgreSQL ক্লাউড ডাটাবেজ ইন্টিগ্রেশন</span>
                    </h3>
                    <p className="text-[11px] text-slate-500 mt-0.5">
                      আপনার লাইভ সুপাবেজ প্রজেক্টের সাথে ডাটাবেজ এবং অথেনটিকেশন যুক্ত করুন
                    </p>
                  </div>
                  <span className={`px-2.5 py-1 rounded text-[11px] font-semibold ${
                    getSupabaseStatus().isConfigured
                      ? 'bg-emerald-50 text-emerald-700 border border-emerald-200'
                      : 'bg-amber-50 text-amber-800 border border-amber-200'
                  }`}>
                    {getSupabaseStatus().isConfigured ? '✓ Supabase Connected' : 'Local Storage Mode'}
                  </span>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-slate-700 font-medium mb-1">
                      Project URL (Project Settings &rarr; API)
                    </label>
                    <input
                      type="text"
                      placeholder="https://your-project.supabase.co"
                      value={supabaseUrlInput}
                      onChange={e => setSupabaseUrlInput(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-[11px]"
                    />
                  </div>

                  <div>
                    <label className="block text-slate-700 font-medium mb-1">
                      Anon / Public API Key (Project Settings &rarr; API)
                    </label>
                    <input
                      type="password"
                      placeholder="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
                      value={supabaseKeyInput}
                      onChange={e => setSupabaseKeyInput(e.target.value)}
                      className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-[11px]"
                    />
                  </div>

                  {supabaseTestResult && (
                    <div className={`p-3 rounded-lg text-xs flex items-start gap-2 ${
                      supabaseTestResult.success ? 'bg-emerald-50 text-emerald-800 border border-emerald-200' : 'bg-rose-50 text-rose-800 border border-rose-200'
                    }`}>
                      {supabaseTestResult.success ? <CheckCircle className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" /> : <AlertTriangle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />}
                      <span>{supabaseTestResult.message}</span>
                    </div>
                  )}

                  <div className="flex flex-wrap items-center gap-2 pt-1">
                    <button
                      type="button"
                      disabled={supabaseTesting}
                      onClick={async () => {
                        setSupabaseTesting(true);
                        setSupabaseTestResult(null);
                        const res = await testSupabaseConnection(supabaseUrlInput, supabaseKeyInput);
                        setSupabaseTesting(false);
                        setSupabaseTestResult(res);
                      }}
                      className="px-4 py-2 bg-slate-800 hover:bg-slate-700 text-white rounded font-semibold text-xs flex items-center gap-1.5 transition-colors"
                    >
                      <RefreshCw className={`w-3.5 h-3.5 ${supabaseTesting ? 'animate-spin' : ''}`} />
                      <span>{supabaseTesting ? 'টেস্ট করা হচ্ছে...' : 'কানেকশন টেস্ট করুন (Test Connection)'}</span>
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        saveCustomSupabaseCredentials(supabaseUrlInput, supabaseKeyInput);
                        showToast('Supabase credentials saved successfully!');
                      }}
                      className="px-4 py-2 bg-teal-600 hover:bg-teal-500 text-white rounded font-semibold text-xs transition-colors"
                    >
                      ক্রেডেনশিয়াল সেভ করুন
                    </button>

                    <button
                      type="button"
                      onClick={() => {
                        navigator.clipboard.writeText(DatabaseService.getSupabaseMigrationSql());
                        showToast('SQL Migration copied! Paste into Supabase SQL Editor.');
                      }}
                      className="px-3 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded font-semibold text-xs flex items-center gap-1 transition-colors ml-auto"
                    >
                      <Copy className="w-3.5 h-3.5" />
                      <span>SQL স্ক্রিপ্ট কপি করুন</span>
                    </button>
                  </div>
                </div>
              </div>

              <form
                onSubmit={e => {
                  e.preventDefault();
                  DatabaseService.updateSettings(settingsForm);
                  showToast('Settings saved successfully!');
                }}
                className="bg-white rounded-xl border border-slate-200 p-6 space-y-4 text-xs"
              >
                <div>
                  <label className="block text-slate-700 font-medium mb-1">ওয়েবসাইট নাম</label>
                  <input
                    type="text"
                    value={settingsForm.siteTitle}
                    onChange={e => setSettingsForm({ ...settingsForm, siteTitle: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded font-bold"
                  />
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-medium mb-1">মালিক ও শিক্ষক</label>
                    <input
                      type="text"
                      value={settingsForm.ownerName}
                      onChange={e => setSettingsForm({ ...settingsForm, ownerName: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-medium mb-1">অফিসিয়াল ইমেইল</label>
                    <input
                      type="email"
                      value={settingsForm.emailContact}
                      onChange={e => setSettingsForm({ ...settingsForm, emailContact: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded"
                    />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-medium mb-1">হোয়াটসঅ্যাপ লোকাল নম্বর</label>
                    <input
                      type="text"
                      value={settingsForm.phoneLocal}
                      onChange={e => setSettingsForm({ ...settingsForm, phoneLocal: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded font-mono font-bold"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-medium mb-1">হোয়াটসঅ্যাপ আন্তর্জাতিক নম্বর (Country Code সহ)</label>
                    <input
                      type="text"
                      value={settingsForm.phoneIntl}
                      onChange={e => setSettingsForm({ ...settingsForm, phoneIntl: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded font-mono font-bold"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">হোয়াটসঅ্যাপ মেসেজ টেমপ্লেট</label>
                  <textarea
                    rows={3}
                    value={settingsForm.whatsappMessageTemplate}
                    onChange={e => setSettingsForm({ ...settingsForm, whatsappMessageTemplate: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded font-mono text-[11px]"
                  />
                  <p className="text-[10px] text-slate-400 mt-1">
                    প্যারামিটার: &#123;course_title&#125; এবং &#123;course_id&#125; স্বয়ংক্রিয়ভাবে পরিবর্তিত হবে।
                  </p>
                </div>

                <div className="grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-slate-700 font-medium mb-1">bKash নম্বর</label>
                    <input
                      type="text"
                      value={settingsForm.bkashMerchantNumber}
                      onChange={e => setSettingsForm({ ...settingsForm, bkashMerchantNumber: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-slate-700 font-medium mb-1">Nagad নম্বর</label>
                    <input
                      type="text"
                      value={settingsForm.nagadMerchantNumber}
                      onChange={e => setSettingsForm({ ...settingsForm, nagadMerchantNumber: e.target.value })}
                      className="w-full px-3 py-2 border border-slate-300 rounded font-mono"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-slate-700 font-medium mb-1">টপ নোটিশ বার টেক্সট</label>
                  <input
                    type="text"
                    value={settingsForm.announcementBarText}
                    onChange={e => setSettingsForm({ ...settingsForm, announcementBarText: e.target.value })}
                    className="w-full px-3 py-2 border border-slate-300 rounded"
                  />
                </div>

                <div className="pt-2">
                  <button
                    type="submit"
                    className="px-6 py-2.5 bg-blue-900 hover:bg-blue-800 text-white font-bold rounded-lg text-xs"
                  >
                    সেটিংস সেভ করুন
                  </button>
                </div>
              </form>
            </div>
          )}

          {/* TAB 16: ACTIVITY LOGS */}
          {activeTab === 'activity_logs' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-slate-900">প্রশাসনিক সিকিউরিটি ও অ্যাক্টিভিটি লগ (Audit Trail)</h2>
                  <p className="text-xs text-slate-500">সকল অ্যাডমিন ক্রিয়াকলাপের ক্রমানুসারে সংরক্ষিত রেকর্ড</p>
                </div>
              </div>

              <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-xs">
                <table className="w-full text-left text-xs">
                  <thead className="bg-slate-50 border-b border-slate-200 text-slate-600 uppercase font-semibold text-[10px]">
                    <tr>
                      <th className="px-4 py-3">টাইমস্ট্যাম্প</th>
                      <th className="px-4 py-3">ব্যবহারকারী</th>
                      <th className="px-4 py-3">অ্যাকশন</th>
                      <th className="px-4 py-3">বিবরণ</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100">
                    {logs.map(log => (
                      <tr key={log.id} className="hover:bg-slate-50/70">
                        <td className="px-4 py-3 font-mono text-[11px] text-slate-500 whitespace-nowrap">
                          {new Date(log.createdAt).toLocaleString()}
                        </td>
                        <td className="px-4 py-3 font-mono text-[11px] text-slate-700">
                          {log.userEmail}
                        </td>
                        <td className="px-4 py-3">
                          <span className="font-mono text-[10px] font-bold px-2 py-0.5 rounded bg-slate-100 text-slate-800">
                            {log.action}
                          </span>
                        </td>
                        <td className="px-4 py-3 text-slate-600">
                          {log.details}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
