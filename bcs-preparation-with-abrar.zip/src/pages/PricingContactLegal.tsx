import React, { useState } from 'react';
import { Phone, Mail, MapPin, Send, CheckCircle, ExternalLink, ShieldCheck, HelpCircle } from 'lucide-react';
import { DatabaseService } from '../services/db';
import { Course } from '../types';

interface PricingPageProps {
  onOpenCheckout: (course: Course) => void;
  onOpenWhatsAppModal: (course: Course) => void;
  onNavigate: (view: string, id?: string) => void;
}

export const PricingPage: React.FC<PricingPageProps> = ({
  onOpenCheckout,
  onOpenWhatsAppModal,
  onNavigate
}) => {
  const courses = DatabaseService.getCourses();
  const settings = DatabaseService.getSettings();

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-12">
      <div className="text-center max-w-3xl mx-auto space-y-3">
        <div className="text-xs font-semibold text-teal-700 uppercase tracking-wider">
          স্বচ্ছ ও সাশ্রয়ী কোর্স ফি
        </div>
        <h1 className="text-2xl sm:text-4xl font-extrabold text-slate-900">
          বিসিএস কোর্সের ফি ও ভর্তি পদ্ধতি
        </h1>
        <p className="text-xs sm:text-sm text-slate-600 leading-relaxed">
          কোনো লুকায়িত চার্জ নেই। একবার কোর্স ফি পরিশোধ করে সম্পূর্ণ মেয়াদ জুড়ে সকল ভিডিও ক্লাস, ড্রাইভ নোট এবং মেন্টরিং সাপোর্ট উপভোগ করুন।
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
        {courses.map(course => {
          const price = course.promotionalPriceBdt || course.regularPriceBdt;
          return (
            <div
              key={course.id}
              className={`bg-white rounded-2xl border p-6 flex flex-col justify-between shadow-xs transition-shadow ${
                course.isFeatured ? 'border-teal-500 ring-2 ring-teal-500/20' : 'border-slate-200'
              }`}
            >
              <div className="space-y-4">
                {course.isFeatured && (
                  <span className="text-[10px] font-bold uppercase tracking-wider text-teal-700">
                    ★ সর্বাধিক জনপ্রিয়
                  </span>
                )}
                <h3 className="text-base font-bold text-slate-900 leading-snug">
                  {course.titleBn}
                </h3>
                <div className="flex items-baseline gap-2">
                  <span className="text-3xl font-extrabold font-mono text-blue-950 tabular-nums">
                    ৳{price.toLocaleString()}
                  </span>
                  {course.promotionalPriceBdt && (
                    <span className="text-xs text-slate-400 line-through font-mono tabular-nums">
                      ৳{course.regularPriceBdt.toLocaleString()}
                    </span>
                  )}
                  <span className="text-xs text-slate-500 font-mono">BDT</span>
                </div>
                <p className="text-xs text-slate-500">মেয়াদ: {course.accessDays} দিন (সকল ক্লাস ও ড্রাইভ নোট)</p>

                <ul className="space-y-2 text-xs text-slate-600 pt-2 border-t border-slate-100">
                  {course.features.map((feat, i) => (
                    <li key={i} className="flex items-start gap-1.5">
                      <span className="text-teal-600 font-bold">✓</span>
                      <span>{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              <div className="pt-6 mt-6 border-t border-slate-100 space-y-2">
                <button
                  onClick={() => onOpenWhatsAppModal(course)}
                  className="w-full py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-1.5"
                >
                  <span>হোয়াটসঅ্যাপ ও bKash এ ভর্তি হোন</span>
                </button>
                <button
                  onClick={() => onNavigate('course-detail', course.id)}
                  className="w-full py-2 bg-slate-100 hover:bg-slate-200 text-slate-800 text-xs font-semibold rounded-lg transition-colors"
                >
                  সিলেবাস ও বিস্তারিত দেখুন
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
};

export const ContactPage: React.FC = () => {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [sent, setSent] = useState(false);

  const settings = DatabaseService.getSettings();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    DatabaseService.createInquiry({
      courseId: 'general_contact',
      courseTitle: 'General Contact / Inquiry',
      contactName: name.trim(),
      contactPhone: phone.trim(),
      userEmail: email.trim() || undefined,
      message: message.trim()
    });
    setSent(true);
  };

  return (
    <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10 space-y-10">
      <div className="text-center max-w-2xl mx-auto space-y-2">
        <h1 className="text-2xl sm:text-3xl font-extrabold text-slate-900">যোগাযোগ ও সহায়তা</h1>
        <p className="text-xs sm:text-sm text-slate-600">
          কোর্স ভর্তি, পেমেন্ট অথবা ক্লাস সম্পর্কিত যেকোনো তথ্যের জন্য সরাসরি আমাদের সাথে যোগাযোগ করুন।
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Contact Info Card */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6 space-y-6">
          <h3 className="text-base font-bold text-slate-900">অফিসিয়াল যোগাযোগ চ্যানেল</h3>

          <div className="space-y-4 text-xs text-slate-700">
            <div className="flex items-start gap-3">
              <Phone className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-slate-900">হোয়াটসঅ্যাপ ও মোবাইল নম্বর:</p>
                <p className="font-mono text-slate-600 font-semibold">{settings.phoneLocal}</p>
                <p className="text-[11px] text-slate-400">সকাল ৯টা থেকে রাত ১০টা পর্যন্ত সক্রিয়</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <Mail className="w-4 h-4 text-teal-600 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-slate-900">ইমেইল ঠিকানা:</p>
                <p className="font-mono text-slate-600">{settings.emailContact}</p>
              </div>
            </div>

            <div className="flex items-start gap-3">
              <MapPin className="w-4 h-4 text-blue-900 shrink-0 mt-0.5" />
              <div>
                <p className="font-bold text-slate-900">অবস্থান:</p>
                <p className="text-slate-600">ঢাকা, বাংলাদেশ</p>
                <p className="text-[11px] text-slate-400">সকল ক্লাস অনলাইনে এবং লাইভ পরিচালিত হয়</p>
              </div>
            </div>
          </div>

          <div className="pt-4 border-t border-slate-100">
            <a
              href={`https://wa.me/${settings.phoneIntl}?text=${encodeURIComponent('Assalamu Alaikum Abrar Sir. I would like to make an inquiry.')}`}
              target="_blank"
              rel="noreferrer"
              className="w-full py-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-bold rounded-xl flex items-center justify-center gap-2 shadow-xs transition-colors"
            >
              <span>সরাসরি হোয়াটসঅ্যাপে কথা বলুন</span>
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
        </div>

        {/* Message Form */}
        <div className="bg-white rounded-2xl border border-slate-200 p-6">
          <h3 className="text-base font-bold text-slate-900 mb-4">বার্তা পাঠান</h3>

          {sent ? (
            <div className="p-6 text-center space-y-2 bg-emerald-50 rounded-xl border border-emerald-200">
              <CheckCircle className="w-8 h-8 text-emerald-600 mx-auto" />
              <p className="text-xs font-bold text-emerald-900">বার্তা সফলভাবে পাঠানো হয়েছে!</p>
              <p className="text-[11px] text-emerald-700">আমরা শীঘ্রই আপনার দেওয়া নম্বরে যোগাযোগ করব।</p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-3.5">
              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">আপনার নাম</label>
                <input
                  type="text"
                  required
                  value={name}
                  onChange={e => setName(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">মোবাইল নম্বর (হোয়াটসঅ্যাপ)</label>
                <input
                  type="text"
                  required
                  placeholder="017XXXXXXXX"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900 font-mono"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">ইমেইল (ঐচ্ছিক)</label>
                <input
                  type="email"
                  value={email}
                  onChange={e => setEmail(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">বার্তা বা জিজ্ঞাসা</label>
                <textarea
                  rows={3}
                  required
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  placeholder="আপনার জিজ্ঞাসা লিখুন..."
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded-lg focus:ring-1 focus:ring-blue-900"
                />
              </div>

              <button
                type="submit"
                className="w-full py-2.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-bold rounded-lg transition-colors flex items-center justify-center gap-2"
              >
                <Send className="w-3.5 h-3.5" />
                <span>বার্তা জমা দিন</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};

export const TermsPage: React.FC = () => (
  <div className="max-w-4xl mx-auto px-4 py-12 space-y-6 text-xs text-slate-700 leading-relaxed">
    <h1 className="text-2xl font-bold text-slate-900">ব্যবহারের শর্তাবলী (Terms and Conditions)</h1>
    <div className="space-y-4 bg-white p-6 rounded-xl border border-slate-200">
      <h3 className="font-bold text-slate-900 text-sm">১. সেবার আওতা ও অ্যাক্সেস</h3>
      <p>
        BCS Preparation With Abrar প্ল্যাটফর্মে নিবন্ধিত কোর্সসমূহ শিক্ষার্থীদের একক ব্যক্তিগত অধ্যয়নের জন্য প্রস্তুতকৃত। কোর্সের লেকচার, ভিডিও এবং গুগল ড্রাইভ হ্যান্ডনোট বাণিজ্যিকভাবে পুনঃবিক্রয় বা অননুমোদিতভাবে শেয়ার করা আইনত দণ্ডনীয়।
      </p>

      <h3 className="font-bold text-slate-900 text-sm">২. ক্লাস নোট ও বৌদ্ধিক সম্পত্তি</h3>
      <p>
        সকল লেকচার শিট, হ্যান্ডনোট ও প্রশ্ন সংকলন শিক্ষক আবরারের মেধা সম্পত্তি। কোনো শিক্ষার্থী অ্যাকাউন্ট ভাগাভাগি করলে পূর্ব নোটিশ ছাড়াই তার অ্যাক্সেস সাময়িকভাবে স্থগিত বা বাতিল করা হতে পারে।
      </p>

      <h3 className="font-bold text-slate-900 text-sm">৩. পেমেন্ট ও রিফান্ড নীতি</h3>
      <p>
        ম্যানুয়াল bKash/Nagad পেমেন্ট নিশ্চিতকরণ সাপেক্ষে অনুমোদন দেওয়া হয়। কোর্স শুরু হওয়ার পর ক্লাস সামগ্রী অ্যাক্সেস করার কারণে প্রচলিত ডিজিটাল কনটেন্ট নীতিমালা অনুযায়ী ফি অফেরতযোগ্য।
      </p>
    </div>
  </div>
);

export const PrivacyPage: React.FC = () => (
  <div className="max-w-4xl mx-auto px-4 py-12 space-y-6 text-xs text-slate-700 leading-relaxed">
    <h1 className="text-2xl font-bold text-slate-900">গোপনীয়তা নীতি (Privacy Policy)</h1>
    <div className="space-y-4 bg-white p-6 rounded-xl border border-slate-200">
      <h3 className="font-bold text-slate-900 text-sm">১. তথ্যের গোপনীয়তা</h3>
      <p>
        শিক্ষার্থীদের প্রদত্ত নাম, মোবাইল নম্বর, ইমেইল এবং পেমেন্ট ট্রানজেকশন রেফারেন্স অত্যন্ত সতর্কতার সাথে সংরক্ষিত থাকে। আমরা কোনো তৃতীয় পক্ষের সাথে শিক্ষার্থীদের ব্যক্তিগত তথ্য শেয়ার করি না।
      </p>

      <h3 className="font-bold text-slate-900 text-sm">২. হোয়াটসঅ্যাপ যোগাযোগ</h3>
      <p>
        শিক্ষার্থী নিজের সম্মতিতে হোয়াটসঅ্যাপে যোগাযোগ করলে সেই যোগাযোগের তথ্য কেবলমাত্র কোর্স নোটিশ ও একাডেমিক সহায়তায় ব্যবহৃত হয়।
      </p>
    </div>
  </div>
);
