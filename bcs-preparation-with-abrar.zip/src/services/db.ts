import { 
  Subject, 
  Chapter, 
  Topic, 
  Lecture, 
  Course, 
  Batch, 
  UserProfile, 
  Enrollment, 
  StudentPermission, 
  StudentProgress, 
  Bookmark, 
  AccessRequest, 
  CourseInquiry, 
  Payment, 
  Coupon, 
  Announcement, 
  SiteSettings, 
  ActivityLog,
  PaymentStatus,
  InquiryStatus,
  RequestStatus,
  UserRole
} from '../types';

import { 
  INITIAL_SITE_SETTINGS,
  INITIAL_PROFILES,
  INITIAL_SUBJECTS,
  INITIAL_CHAPTERS,
  INITIAL_TOPICS,
  INITIAL_COURSES,
  INITIAL_LECTURES,
  INITIAL_BATCHES,
  INITIAL_ENROLLMENTS,
  INITIAL_PAYMENTS,
  INITIAL_INQUIRIES,
  INITIAL_ACCESS_REQUESTS,
  INITIAL_COUPONS,
  INITIAL_ANNOUNCEMENTS,
  INITIAL_ACTIVITY_LOGS
} from '../data/initialData';

const STORAGE_KEYS = {
  SETTINGS: 'bcs_settings_v1',
  PROFILES: 'bcs_profiles_v1',
  SUBJECTS: 'bcs_subjects_v1',
  CHAPTERS: 'bcs_chapters_v1',
  TOPICS: 'bcs_topics_v1',
  COURSES: 'bcs_courses_v1',
  LECTURES: 'bcs_lectures_v1',
  BATCHES: 'bcs_batches_v1',
  ENROLLMENTS: 'bcs_enrollments_v1',
  PERMISSIONS: 'bcs_permissions_v1',
  PROGRESS: 'bcs_progress_v1',
  BOOKMARKS: 'bcs_bookmarks_v1',
  REQUESTS: 'bcs_access_requests_v1',
  INQUIRIES: 'bcs_course_inquiries_v1',
  PAYMENTS: 'bcs_payments_v1',
  COUPONS: 'bcs_coupons_v1',
  ANNOUNCEMENTS: 'bcs_announcements_v1',
  LOGS: 'bcs_activity_logs_v1',
  CURRENT_USER_ID: 'bcs_active_user_id_v1',
  LANGUAGE: 'bcs_app_language_v1'
};

function getStoredItem<T>(key: string, defaultValue: T): T {
  try {
    const item = localStorage.getItem(key);
    if (!item) return defaultValue;
    return JSON.parse(item);
  } catch (err) {
    console.error(`Error reading ${key} from storage:`, err);
    return defaultValue;
  }
}

function setStoredItem<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error(`Error saving ${key} to storage:`, err);
  }
}

type Listener = () => void;
const listeners = new Set<Listener>();

export function subscribeToDatabase(listener: Listener): () => void {
  listeners.add(listener);
  return () => {
    listeners.delete(listener);
  };
}

function notifySubscribers() {
  listeners.forEach(fn => fn());
}

export class DatabaseService {
  // Activity Log
  static logActivity(action: string, entityType: string, entityId: string, details: string, userEmail = 'admin@bcsprepabrar.com', userId = 'usr_admin_abrar') {
    const logs = this.getActivityLogs();
    const newLog: ActivityLog = {
      id: `log_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      userId,
      userEmail,
      action,
      entityType,
      entityId,
      details,
      createdAt: new Date().toISOString()
    };
    setStoredItem(STORAGE_KEYS.LOGS, [newLog, ...logs]);
    notifySubscribers();
  }

  static getActivityLogs(): ActivityLog[] {
    return getStoredItem<ActivityLog[]>(STORAGE_KEYS.LOGS, INITIAL_ACTIVITY_LOGS);
  }

  // Site Settings
  static getSettings(): SiteSettings {
    return getStoredItem<SiteSettings>(STORAGE_KEYS.SETTINGS, INITIAL_SITE_SETTINGS);
  }

  static updateSettings(settings: Partial<SiteSettings>): SiteSettings {
    const current = this.getSettings();
    const updated = { ...current, ...settings };
    setStoredItem(STORAGE_KEYS.SETTINGS, updated);
    this.logActivity('UPDATE_SETTINGS', 'site_settings', 'global', 'Updated website settings and contact numbers.');
    notifySubscribers();
    return updated;
  }

  // Language
  static getLanguage(): 'bn' | 'en' {
    return getStoredItem<'bn' | 'en'>(STORAGE_KEYS.LANGUAGE, 'bn');
  }

  static setLanguage(lang: 'bn' | 'en'): void {
    setStoredItem(STORAGE_KEYS.LANGUAGE, lang);
    notifySubscribers();
  }

  // Profiles & Auth
  static getProfiles(): UserProfile[] {
    return getStoredItem<UserProfile[]>(STORAGE_KEYS.PROFILES, INITIAL_PROFILES);
  }

  static getProfileById(id: string): UserProfile | undefined {
    return this.getProfiles().find(p => p.id === id);
  }

  static getCurrentUser(): UserProfile {
    const currentId = getStoredItem<string>(STORAGE_KEYS.CURRENT_USER_ID, 'usr_admin_abrar');
    const profile = this.getProfileById(currentId);
    if (profile) return profile;
    return INITIAL_PROFILES[0]; // Super Admin fallback
  }

  static setCurrentUser(userId: string): void {
    setStoredItem(STORAGE_KEYS.CURRENT_USER_ID, userId);
    notifySubscribers();
  }

  static registerStudent(data: { fullName: string; email: string; phone: string; district?: string; targetBcsCadre?: string }): UserProfile {
    const profiles = this.getProfiles();
    const existing = profiles.find(p => p.email.toLowerCase() === data.email.toLowerCase());
    if (existing) {
      throw new Error("This email is already registered. Please log in.");
    }
    const newProfile: UserProfile = {
      id: `usr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      email: data.email,
      fullName: data.fullName,
      phone: data.phone,
      role: 'student',
      status: 'pending', // Account status requires admin approval or is pending
      district: data.district,
      targetBcsCadre: data.targetBcsCadre,
      createdAt: new Date().toISOString()
    };
    setStoredItem(STORAGE_KEYS.PROFILES, [...profiles, newProfile]);
    this.logActivity('REGISTER_STUDENT', 'user', newProfile.id, `New student registered: ${data.fullName} (${data.email})`, data.email, newProfile.id);
    notifySubscribers();
    return newProfile;
  }

  static updateProfileStatus(userId: string, status: UserProfile['status'], role?: UserRole): void {
    const profiles = this.getProfiles().map(p => {
      if (p.id === userId) {
        return { 
          ...p, 
          status, 
          ...(role ? { role } : {}) 
        };
      }
      return p;
    });
    setStoredItem(STORAGE_KEYS.PROFILES, profiles);
    this.logActivity('UPDATE_USER_STATUS', 'user', userId, `Updated account status to ${status}${role ? ` and role to ${role}` : ''}`);
    notifySubscribers();
  }

  // Subjects
  static getSubjects(): Subject[] {
    return getStoredItem<Subject[]>(STORAGE_KEYS.SUBJECTS, INITIAL_SUBJECTS);
  }

  static getSubjectById(id: string): Subject | undefined {
    return this.getSubjects().find(s => s.id === id);
  }

  static saveSubject(subject: Subject): void {
    const subjects = this.getSubjects();
    const index = subjects.findIndex(s => s.id === subject.id);
    let updated: Subject[];
    if (index >= 0) {
      updated = [...subjects];
      updated[index] = subject;
      this.logActivity('UPDATE_SUBJECT', 'subject', subject.id, `Updated subject: ${subject.titleBn}`);
    } else {
      updated = [...subjects, subject];
      this.logActivity('CREATE_SUBJECT', 'subject', subject.id, `Created subject: ${subject.titleBn}`);
    }
    setStoredItem(STORAGE_KEYS.SUBJECTS, updated);
    notifySubscribers();
  }

  static deleteSubject(id: string): void {
    const subject = this.getSubjectById(id);
    const updated = this.getSubjects().filter(s => s.id !== id);
    setStoredItem(STORAGE_KEYS.SUBJECTS, updated);
    this.logActivity('DELETE_SUBJECT', 'subject', id, `Deleted subject: ${subject?.titleBn || id}`);
    notifySubscribers();
  }

  // Chapters
  static getChapters(subjectId?: string): Chapter[] {
    const chapters = getStoredItem<Chapter[]>(STORAGE_KEYS.CHAPTERS, INITIAL_CHAPTERS);
    if (!subjectId) return chapters;
    return chapters.filter(c => c.subjectId === subjectId);
  }

  static saveChapter(chapter: Chapter): void {
    const chapters = this.getChapters();
    const index = chapters.findIndex(c => c.id === chapter.id);
    let updated: Chapter[];
    if (index >= 0) {
      updated = [...chapters];
      updated[index] = chapter;
      this.logActivity('UPDATE_CHAPTER', 'chapter', chapter.id, `Updated chapter: ${chapter.titleBn}`);
    } else {
      updated = [...chapters, chapter];
      this.logActivity('CREATE_CHAPTER', 'chapter', chapter.id, `Created chapter: ${chapter.titleBn}`);
    }
    setStoredItem(STORAGE_KEYS.CHAPTERS, updated);
    notifySubscribers();
  }

  static deleteChapter(id: string): void {
    const updated = this.getChapters().filter(c => c.id !== id);
    setStoredItem(STORAGE_KEYS.CHAPTERS, updated);
    this.logActivity('DELETE_CHAPTER', 'chapter', id, `Deleted chapter ${id}`);
    notifySubscribers();
  }

  // Topics
  static getTopics(chapterId?: string): Topic[] {
    const topics = getStoredItem<Topic[]>(STORAGE_KEYS.TOPICS, INITIAL_TOPICS);
    if (!chapterId) return topics;
    return topics.filter(t => t.chapterId === chapterId);
  }

  static saveTopic(topic: Topic): void {
    const topics = this.getTopics();
    const index = topics.findIndex(t => t.id === topic.id);
    let updated: Topic[];
    if (index >= 0) {
      updated = [...topics];
      updated[index] = topic;
    } else {
      updated = [...topics, topic];
    }
    setStoredItem(STORAGE_KEYS.TOPICS, updated);
    notifySubscribers();
  }

  // Lectures
  static getLectures(): Lecture[] {
    return getStoredItem<Lecture[]>(STORAGE_KEYS.LECTURES, INITIAL_LECTURES);
  }

  static getLectureById(id: string): Lecture | undefined {
    return this.getLectures().find(l => l.id === id);
  }

  static saveLecture(lecture: Lecture): void {
    const lectures = this.getLectures();
    const index = lectures.findIndex(l => l.id === lecture.id);
    let updated: Lecture[];
    if (index >= 0) {
      updated = [...lectures];
      updated[index] = lecture;
      this.logActivity('UPDATE_LECTURE', 'lecture', lecture.id, `Updated lecture: ${lecture.titleBn}`);
    } else {
      updated = [...lectures, lecture];
      this.logActivity('CREATE_LECTURE', 'lecture', lecture.id, `Created lecture: ${lecture.titleBn}`);
    }
    setStoredItem(STORAGE_KEYS.LECTURES, updated);
    notifySubscribers();
  }

  static deleteLecture(id: string): void {
    const lecture = this.getLectureById(id);
    const updated = this.getLectures().filter(l => l.id !== id);
    setStoredItem(STORAGE_KEYS.LECTURES, updated);
    this.logActivity('DELETE_LECTURE', 'lecture', id, `Deleted lecture: ${lecture?.titleBn || id}`);
    notifySubscribers();
  }

  // Courses
  static getCourses(): Course[] {
    return getStoredItem<Course[]>(STORAGE_KEYS.COURSES, INITIAL_COURSES);
  }

  static getCourseById(id: string): Course | undefined {
    return this.getCourses().find(c => c.id === id);
  }

  static saveCourse(course: Course): void {
    const courses = this.getCourses();
    const index = courses.findIndex(c => c.id === course.id);
    let updated: Course[];
    if (index >= 0) {
      updated = [...courses];
      updated[index] = course;
      this.logActivity('UPDATE_COURSE', 'course', course.id, `Updated course: ${course.titleBn}`);
    } else {
      updated = [...courses, course];
      this.logActivity('CREATE_COURSE', 'course', course.id, `Created course: ${course.titleBn}`);
    }
    setStoredItem(STORAGE_KEYS.COURSES, updated);
    notifySubscribers();
  }

  static deleteCourse(id: string): void {
    const course = this.getCourseById(id);
    const updated = this.getCourses().filter(c => c.id !== id);
    setStoredItem(STORAGE_KEYS.COURSES, updated);
    this.logActivity('DELETE_COURSE', 'course', id, `Deleted course: ${course?.titleBn || id}`);
    notifySubscribers();
  }

  // Batches
  static getBatches(courseId?: string): Batch[] {
    const batches = getStoredItem<Batch[]>(STORAGE_KEYS.BATCHES, INITIAL_BATCHES);
    if (!courseId) return batches;
    return batches.filter(b => b.courseId === courseId);
  }

  static saveBatch(batch: Batch): void {
    const batches = this.getBatches();
    const index = batches.findIndex(b => b.id === batch.id);
    let updated: Batch[];
    if (index >= 0) {
      updated = [...batches];
      updated[index] = batch;
      this.logActivity('UPDATE_BATCH', 'batch', batch.id, `Updated batch: ${batch.name}`);
    } else {
      updated = [...batches, batch];
      this.logActivity('CREATE_BATCH', 'batch', batch.id, `Created batch: ${batch.name}`);
    }
    setStoredItem(STORAGE_KEYS.BATCHES, updated);
    notifySubscribers();
  }

  static deleteBatch(id: string): void {
    const updated = this.getBatches().filter(b => b.id !== id);
    setStoredItem(STORAGE_KEYS.BATCHES, updated);
    this.logActivity('DELETE_BATCH', 'batch', id, `Deleted batch ${id}`);
    notifySubscribers();
  }

  // Enrollments
  static getEnrollments(userId?: string): Enrollment[] {
    const enrollments = getStoredItem<Enrollment[]>(STORAGE_KEYS.ENROLLMENTS, INITIAL_ENROLLMENTS);
    if (!userId) return enrollments;
    return enrollments.filter(e => e.userId === userId && e.status === 'active');
  }

  static grantEnrollment(data: { userId: string; courseId: string; batchId?: string; durationDays?: number; paymentId?: string }): Enrollment {
    const enrollments = getStoredItem<Enrollment[]>(STORAGE_KEYS.ENROLLMENTS, INITIAL_ENROLLMENTS);
    const days = data.durationDays || 365;
    const startDate = new Date().toISOString();
    const expiresAt = new Date(Date.now() + days * 24 * 60 * 60 * 1000).toISOString();

    const newEnrollment: Enrollment = {
      id: `enr_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: data.userId,
      courseId: data.courseId,
      batchId: data.batchId,
      status: 'active',
      startDate,
      expiresAt,
      grantedBy: 'usr_admin_abrar',
      paymentId: data.paymentId,
      createdAt: startDate
    };

    setStoredItem(STORAGE_KEYS.ENROLLMENTS, [...enrollments, newEnrollment]);
    this.logActivity('GRANT_ENROLLMENT', 'enrollment', newEnrollment.id, `Granted course ${data.courseId} access to user ${data.userId}`);
    notifySubscribers();
    return newEnrollment;
  }

  static revokeEnrollment(enrollmentId: string): void {
    const enrollments = getStoredItem<Enrollment[]>(STORAGE_KEYS.ENROLLMENTS, INITIAL_ENROLLMENTS).map(e => {
      if (e.id === enrollmentId) {
        return { ...e, status: 'revoked' as const };
      }
      return e;
    });
    setStoredItem(STORAGE_KEYS.ENROLLMENTS, enrollments);
    this.logActivity('REVOKE_ENROLLMENT', 'enrollment', enrollmentId, `Revoked enrollment ${enrollmentId}`);
    notifySubscribers();
  }

  // Student Permissions (Granular: Course, Subject, Chapter, Lecture)
  static getPermissions(userId?: string): StudentPermission[] {
    const perms = getStoredItem<StudentPermission[]>(STORAGE_KEYS.PERMISSIONS, []);
    if (!userId) return perms;
    return perms.filter(p => p.userId === userId && p.isGranted);
  }

  static setPermission(userId: string, entityType: StudentPermission['entityType'], entityId: string, isGranted: boolean): void {
    const perms = getStoredItem<StudentPermission[]>(STORAGE_KEYS.PERMISSIONS, []);
    const filtered = perms.filter(p => !(p.userId === userId && p.entityType === entityType && p.entityId === entityId));
    if (isGranted) {
      filtered.push({
        id: `perm_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
        userId,
        entityType,
        entityId,
        isGranted: true,
        grantedBy: 'usr_admin_abrar',
        createdAt: new Date().toISOString()
      });
    }
    setStoredItem(STORAGE_KEYS.PERMISSIONS, filtered);
    this.logActivity('UPDATE_PERMISSION', entityType, entityId, `${isGranted ? 'Granted' : 'Revoked'} ${entityType} permission for user ${userId}`);
    notifySubscribers();
  }

  // Access Verification Logic
  static canUserAccessLecture(lecture: Lecture, user: UserProfile): { allowed: boolean; reason?: string } {
    if (user.role === 'super_admin' || user.role === 'content_manager') {
      return { allowed: true };
    }
    if (lecture.isFreePreview || lecture.accessType === 'public' || lecture.accessType === 'free_preview') {
      return { allowed: true };
    }
    if (user.role === 'guest') {
      return { allowed: false, reason: "Please register or log in to view this lecture." };
    }
    if (user.status !== 'approved') {
      return { allowed: false, reason: "Your account is pending administrator approval." };
    }
    if (lecture.accessType === 'approved_students') {
      return { allowed: true };
    }

    // Check direct granular lecture permission
    const perms = this.getPermissions(user.id);
    const hasLecturePerm = perms.some(p => p.entityType === 'lecture' && p.entityId === lecture.id && p.isGranted);
    if (hasLecturePerm) return { allowed: true };

    const hasChapterPerm = perms.some(p => p.entityType === 'chapter' && p.entityId === lecture.chapterId && p.isGranted);
    if (hasChapterPerm) return { allowed: true };

    const hasSubjectPerm = perms.some(p => p.entityType === 'subject' && p.entityId === lecture.subjectId && p.isGranted);
    if (hasSubjectPerm) return { allowed: true };

    // Check active course enrollments
    const activeEnrollments = this.getEnrollments(user.id);
    const isEnrolledInAssociatedCourse = activeEnrollments.some(e => {
      const notExpired = new Date(e.expiresAt).getTime() > Date.now();
      return notExpired && lecture.courseIds.includes(e.courseId);
    });

    if (isEnrolledInAssociatedCourse) {
      return { allowed: true };
    }

    return { 
      allowed: false, 
      reason: "এই লেকচারটি প্রিমিয়াম বিসিএস কোর্সের অন্তর্ভুক্ত। ভর্তির জন্য সরাসরি আবরার স্যারের সাথে হোয়াটসঅ্যাপে যোগাযোগ করুন অথবা ফি পাঠিয়ে TrxID সাবমিট করুন।" 
    };
  }

  // Student Progress
  static getProgress(userId: string): StudentProgress[] {
    return getStoredItem<StudentProgress[]>(STORAGE_KEYS.PROGRESS, []).filter(p => p.userId === userId);
  }

  static toggleLectureCompleted(userId: string, lectureId: string): boolean {
    const all = getStoredItem<StudentProgress[]>(STORAGE_KEYS.PROGRESS, []);
    const existing = all.find(p => p.userId === userId && p.lectureId === lectureId);
    let newStatus = true;

    let updated: StudentProgress[];
    if (existing) {
      newStatus = !existing.isCompleted;
      updated = all.map(p => {
        if (p.userId === userId && p.lectureId === lectureId) {
          return {
            ...p,
            isCompleted: newStatus,
            completedAt: newStatus ? new Date().toISOString() : undefined,
            lastOpenedAt: new Date().toISOString()
          };
        }
        return p;
      });
    } else {
      updated = [
        ...all,
        {
          id: `prog_${Date.now()}`,
          userId,
          lectureId,
          isCompleted: true,
          completedAt: new Date().toISOString(),
          lastOpenedAt: new Date().toISOString()
        }
      ];
    }
    setStoredItem(STORAGE_KEYS.PROGRESS, updated);
    notifySubscribers();
    return newStatus;
  }

  static recordLectureOpened(userId: string, lectureId: string): void {
    const all = getStoredItem<StudentProgress[]>(STORAGE_KEYS.PROGRESS, []);
    const existingIndex = all.findIndex(p => p.userId === userId && p.lectureId === lectureId);
    let updated: StudentProgress[];
    if (existingIndex >= 0) {
      updated = [...all];
      updated[existingIndex] = {
        ...updated[existingIndex],
        lastOpenedAt: new Date().toISOString()
      };
    } else {
      updated = [
        ...all,
        {
          id: `prog_${Date.now()}`,
          userId,
          lectureId,
          isCompleted: false,
          lastOpenedAt: new Date().toISOString()
        }
      ];
    }
    setStoredItem(STORAGE_KEYS.PROGRESS, updated);
    notifySubscribers();
  }

  // Bookmarks
  static getBookmarks(userId: string): Bookmark[] {
    return getStoredItem<Bookmark[]>(STORAGE_KEYS.BOOKMARKS, []).filter(b => b.userId === userId);
  }

  static toggleBookmark(userId: string, lectureId: string, note?: string): boolean {
    const all = getStoredItem<Bookmark[]>(STORAGE_KEYS.BOOKMARKS, []);
    const exists = all.some(b => b.userId === userId && b.lectureId === lectureId);
    let updated: Bookmark[];
    let bookmarked = false;
    if (exists) {
      updated = all.filter(b => !(b.userId === userId && b.lectureId === lectureId));
      bookmarked = false;
    } else {
      updated = [
        ...all,
        {
          id: `bmk_${Date.now()}`,
          userId,
          lectureId,
          note,
          createdAt: new Date().toISOString()
        }
      ];
      bookmarked = true;
    }
    setStoredItem(STORAGE_KEYS.BOOKMARKS, updated);
    notifySubscribers();
    return bookmarked;
  }

  // Course Inquiries (WhatsApp Click-to-Chat Tracking)
  static getInquiries(): CourseInquiry[] {
    return getStoredItem<CourseInquiry[]>(STORAGE_KEYS.INQUIRIES, INITIAL_INQUIRIES);
  }

  static createInquiry(data: { courseId: string; courseTitle: string; contactName: string; contactPhone: string; userEmail?: string; message: string; userId?: string }): CourseInquiry {
    const inquiries = this.getInquiries();
    const newInquiry: CourseInquiry = {
      id: `inq_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      courseId: data.courseId,
      courseTitle: data.courseTitle,
      userId: data.userId,
      contactName: data.contactName,
      contactPhone: data.contactPhone,
      userEmail: data.userEmail,
      message: data.message,
      status: 'new',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };
    setStoredItem(STORAGE_KEYS.INQUIRIES, [newInquiry, ...inquiries]);
    this.logActivity('RECORD_WHATSAPP_INQUIRY', 'inquiry', newInquiry.id, `New inquiry for ${data.courseTitle} from ${data.contactPhone}`);
    notifySubscribers();
    return newInquiry;
  }

  static updateInquiryStatus(inquiryId: string, status: InquiryStatus, adminNotes?: string): void {
    const inquiries = this.getInquiries().map(inq => {
      if (inq.id === inquiryId) {
        return {
          ...inq,
          status,
          adminNotes: adminNotes !== undefined ? adminNotes : inq.adminNotes,
          updatedAt: new Date().toISOString()
        };
      }
      return inq;
    });
    setStoredItem(STORAGE_KEYS.INQUIRIES, inquiries);
    this.logActivity('UPDATE_INQUIRY_STATUS', 'inquiry', inquiryId, `Updated inquiry status to ${status}`);
    notifySubscribers();
  }

  // Access Requests
  static getAccessRequests(): AccessRequest[] {
    return getStoredItem<AccessRequest[]>(STORAGE_KEYS.REQUESTS, INITIAL_ACCESS_REQUESTS);
  }

  static createAccessRequest(data: { userId: string; userEmail: string; userName: string; userPhone: string; courseId: string; courseTitle: string; message?: string }): AccessRequest {
    const requests = this.getAccessRequests();
    const newReq: AccessRequest = {
      id: `req_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      userId: data.userId,
      userEmail: data.userEmail,
      userName: data.userName,
      userPhone: data.userPhone,
      courseId: data.courseId,
      courseTitle: data.courseTitle,
      message: data.message,
      status: 'pending',
      createdAt: new Date().toISOString()
    };
    setStoredItem(STORAGE_KEYS.REQUESTS, [newReq, ...requests]);
    this.logActivity('CREATE_ACCESS_REQUEST', 'access_request', newReq.id, `Student ${data.userName} requested access to ${data.courseTitle}`);
    notifySubscribers();
    return newReq;
  }

  static updateAccessRequestStatus(requestId: string, status: RequestStatus): void {
    const requests = this.getAccessRequests().map(r => {
      if (r.id === requestId) {
        return {
          ...r,
          status,
          reviewedBy: 'usr_admin_abrar',
          reviewedAt: new Date().toISOString()
        };
      }
      return r;
    });
    setStoredItem(STORAGE_KEYS.REQUESTS, requests);

    // If approved, automatically create active enrollment
    if (status === 'approved') {
      const target = requests.find(r => r.id === requestId);
      if (target) {
        this.grantEnrollment({
          userId: target.userId,
          courseId: target.courseId,
          durationDays: 365
        });
      }
    }

    this.logActivity('REVIEW_ACCESS_REQUEST', 'access_request', requestId, `Status changed to ${status}`);
    notifySubscribers();
  }

  // Payments
  static getPayments(): Payment[] {
    return getStoredItem<Payment[]>(STORAGE_KEYS.PAYMENTS, INITIAL_PAYMENTS);
  }

  static recordPayment(payment: Omit<Payment, 'id' | 'createdAt' | 'currency'>): Payment {
    const payments = this.getPayments();
    // Duplicate check on transactionRef if provided
    if (payment.transactionRef && payments.some(p => p.transactionRef.toLowerCase() === payment.transactionRef.toLowerCase())) {
      throw new Error(`Transaction reference ${payment.transactionRef} has already been registered.`);
    }

    const newPayment: Payment = {
      ...payment,
      id: `pay_${Date.now()}_${Math.random().toString(36).substring(2, 6)}`,
      currency: 'BDT',
      createdAt: new Date().toISOString()
    };

    setStoredItem(STORAGE_KEYS.PAYMENTS, [newPayment, ...payments]);
    this.logActivity('RECORD_PAYMENT', 'payment', newPayment.id, `Recorded payment ৳${newPayment.amountBdt} (${newPayment.paymentMethod}) for ${newPayment.courseTitle}`);

    // If online verified payment, automatically grant course access
    if (newPayment.verificationStatus === 'verified') {
      this.grantEnrollment({
        userId: newPayment.userId,
        courseId: newPayment.courseId,
        paymentId: newPayment.id
      });
    }

    notifySubscribers();
    return newPayment;
  }

  static verifyPayment(paymentId: string, status: PaymentStatus, adminNotes?: string): void {
    const payments = this.getPayments();
    const target = payments.find(p => p.id === paymentId);
    if (!target) return;

    const updated = payments.map(p => {
      if (p.id === paymentId) {
        return {
          ...p,
          verificationStatus: status,
          adminNotes: adminNotes || p.adminNotes,
          verifiedBy: 'usr_admin_abrar',
          verifiedAt: new Date().toISOString()
        };
      }
      return p;
    });

    setStoredItem(STORAGE_KEYS.PAYMENTS, updated);

    // If verified, grant course enrollment idempotently
    if (status === 'verified') {
      const existingEnrollments = this.getEnrollments(target.userId);
      const alreadyActive = existingEnrollments.some(e => e.courseId === target.courseId && e.status === 'active');
      if (!alreadyActive) {
        this.grantEnrollment({
          userId: target.userId,
          courseId: target.courseId,
          paymentId
        });
      }
    }

    this.logActivity('VERIFY_PAYMENT', 'payment', paymentId, `Payment marked as ${status}. Amount: ৳${target.amountBdt}`);
    notifySubscribers();
  }

  // Coupons
  static getCoupons(): Coupon[] {
    return getStoredItem<Coupon[]>(STORAGE_KEYS.COUPONS, INITIAL_COUPONS);
  }

  static validateCoupon(code: string, courseId: string, coursePrice: number): { valid: boolean; discountAmount: number; finalPrice: number; message: string } {
    const coupons = this.getCoupons();
    const coupon = coupons.find(c => c.code.toUpperCase() === code.trim().toUpperCase());

    if (!coupon) {
      return { valid: false, discountAmount: 0, finalPrice: coursePrice, message: "Invalid coupon code." };
    }
    if (!coupon.isActive) {
      return { valid: false, discountAmount: 0, finalPrice: coursePrice, message: "This coupon is currently inactive." };
    }
    if (new Date(coupon.validUntil).getTime() < Date.now()) {
      return { valid: false, discountAmount: 0, finalPrice: coursePrice, message: "This coupon has expired." };
    }
    if (coupon.timesUsed >= coupon.usageLimit) {
      return { valid: false, discountAmount: 0, finalPrice: coursePrice, message: "Coupon usage limit reached." };
    }
    if (coupon.eligibleCourseIds && coupon.eligibleCourseIds.length > 0 && !coupon.eligibleCourseIds.includes(courseId)) {
      return { valid: false, discountAmount: 0, finalPrice: coursePrice, message: "This coupon is not valid for this course." };
    }
    if (coursePrice < coupon.minSpendBdt) {
      return { valid: false, discountAmount: 0, finalPrice: coursePrice, message: `Minimum course fee for this coupon is ৳${coupon.minSpendBdt}.` };
    }

    let discount = 0;
    if (coupon.discountType === 'percentage') {
      discount = Math.round((coursePrice * coupon.discountValue) / 100);
      if (coupon.maxDiscountBdt && discount > coupon.maxDiscountBdt) {
        discount = coupon.maxDiscountBdt;
      }
    } else {
      discount = coupon.discountValue;
    }

    const finalPrice = Math.max(0, coursePrice - discount);
    return {
      valid: true,
      discountAmount: discount,
      finalPrice,
      message: `Coupon ${coupon.code} applied! Saved ৳${discount}.`
    };
  }

  static saveCoupon(coupon: Coupon): void {
    const coupons = this.getCoupons();
    const index = coupons.findIndex(c => c.id === coupon.id);
    let updated: Coupon[];
    if (index >= 0) {
      updated = [...coupons];
      updated[index] = coupon;
      this.logActivity('UPDATE_COUPON', 'coupon', coupon.id, `Updated coupon: ${coupon.code}`);
    } else {
      updated = [...coupons, coupon];
      this.logActivity('CREATE_COUPON', 'coupon', coupon.id, `Created coupon: ${coupon.code}`);
    }
    setStoredItem(STORAGE_KEYS.COUPONS, updated);
    notifySubscribers();
  }

  static deleteCoupon(id: string): void {
    const updated = this.getCoupons().filter(c => c.id !== id);
    setStoredItem(STORAGE_KEYS.COUPONS, updated);
    this.logActivity('DELETE_COUPON', 'coupon', id, `Deleted coupon ${id}`);
    notifySubscribers();
  }

  // Announcements
  static getAnnouncements(): Announcement[] {
    return getStoredItem<Announcement[]>(STORAGE_KEYS.ANNOUNCEMENTS, INITIAL_ANNOUNCEMENTS);
  }

  static saveAnnouncement(announcement: Announcement): void {
    const list = this.getAnnouncements();
    const index = list.findIndex(a => a.id === announcement.id);
    let updated: Announcement[];
    if (index >= 0) {
      updated = [...list];
      updated[index] = announcement;
      this.logActivity('UPDATE_ANNOUNCEMENT', 'announcement', announcement.id, `Updated announcement: ${announcement.title}`);
    } else {
      updated = [announcement, ...list];
      this.logActivity('CREATE_ANNOUNCEMENT', 'announcement', announcement.id, `Created announcement: ${announcement.title}`);
    }
    setStoredItem(STORAGE_KEYS.ANNOUNCEMENTS, updated);
    notifySubscribers();
  }

  static deleteAnnouncement(id: string): void {
    const updated = this.getAnnouncements().filter(a => a.id !== id);
    setStoredItem(STORAGE_KEYS.ANNOUNCEMENTS, updated);
    this.logActivity('DELETE_ANNOUNCEMENT', 'announcement', id, `Deleted announcement ${id}`);
    notifySubscribers();
  }

  // Real Database Statistics (NO fake numbers)
  static getDashboardStats() {
    const subjects = this.getSubjects();
    const chapters = this.getChapters();
    const lectures = this.getLectures();
    const publishedLectures = lectures.filter(l => l.publicationStatus === 'published');
    const courses = this.getCourses();
    const profiles = this.getProfiles();
    const registeredStudents = profiles.filter(p => p.role === 'student');
    const enrollments = getStoredItem<Enrollment[]>(STORAGE_KEYS.ENROLLMENTS, INITIAL_ENROLLMENTS);
    const activeEnrollments = enrollments.filter(e => e.status === 'active');
    const requests = this.getAccessRequests();
    const pendingRequests = requests.filter(r => r.status === 'pending');
    const payments = this.getPayments();
    const pendingPayments = payments.filter(p => p.verificationStatus === 'pending');
    const verifiedPayments = payments.filter(p => p.verificationStatus === 'verified');
    const totalVerifiedRevenue = verifiedPayments.reduce((acc, curr) => acc + curr.amountBdt, 0);
    const inquiries = this.getInquiries();

    return {
      totalSubjects: subjects.length,
      totalChapters: chapters.length,
      totalLectures: lectures.length,
      publishedLectures: publishedLectures.length,
      totalCourses: courses.length,
      registeredStudents: registeredStudents.length,
      activeEnrollments: activeEnrollments.length,
      pendingAccessRequests: pendingRequests.length,
      pendingPayments: pendingPayments.length,
      verifiedPayments: verifiedPayments.length,
      totalVerifiedRevenueBdt: totalVerifiedRevenue,
      courseInquiries: inquiries.length
    };
  }

  // Export to CSV helper
  static exportToCsv(data: Record<string, unknown>[], filename: string): void {
    if (data.length === 0) return;
    const headers = Object.keys(data[0]);
    const csvRows = [
      headers.join(','),
      ...data.map(row => 
        headers.map(field => {
          const val = row[field];
          const str = typeof val === 'object' ? JSON.stringify(val) : String(val ?? '');
          return `"${str.replace(/"/g, '""')}"`;
        }).join(',')
      )
    ];
    const blob = new Blob([csvRows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', `${filename}_${Date.now()}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  // Generate Supabase Migration SQL Schema
  static getSupabaseMigrationSql(): string {
    return `-- ========================================================
-- BCS PREPARATION WITH ABRAR - SUPABASE SCHEMA & RLS RULES
-- ========================================================

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('super_admin', 'content_manager', 'student', 'guest')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'suspended', 'rejected')),
  district TEXT,
  target_bcs_cadre TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Subjects table
CREATE TABLE IF NOT EXISTS public.subjects (
  id TEXT PRIMARY KEY,
  title_bn TEXT NOT NULL,
  title_en TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  description TEXT,
  exam_type TEXT NOT NULL CHECK (exam_type IN ('preliminary', 'written', 'both')),
  order_index INTEGER DEFAULT 0,
  is_published BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Chapters table
CREATE TABLE IF NOT EXISTS public.chapters (
  id TEXT PRIMARY KEY,
  subject_id TEXT REFERENCES public.subjects(id) ON DELETE CASCADE,
  title_bn TEXT NOT NULL,
  title_en TEXT NOT NULL,
  order_index INTEGER DEFAULT 0,
  is_published BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Lectures table
CREATE TABLE IF NOT EXISTS public.lectures (
  id TEXT PRIMARY KEY,
  subject_id TEXT REFERENCES public.subjects(id) ON DELETE CASCADE,
  chapter_id TEXT REFERENCES public.chapters(id) ON DELETE CASCADE,
  title_bn TEXT NOT NULL,
  title_en TEXT NOT NULL,
  exam_type TEXT NOT NULL CHECK (exam_type IN ('preliminary', 'written', 'both')),
  description TEXT,
  youtube_url TEXT NOT NULL,
  drive_notes_url TEXT,
  teacher_name TEXT DEFAULT 'Abrar',
  lecture_number INTEGER NOT NULL,
  duration_minutes INTEGER DEFAULT 45,
  is_free_preview BOOLEAN DEFAULT false,
  publication_status TEXT DEFAULT 'published' CHECK (publication_status IN ('published', 'draft', 'archived')),
  access_type TEXT DEFAULT 'enrolled_students' CHECK (access_type IN ('public', 'free_preview', 'approved_students', 'enrolled_students', 'selected_students', 'specific_batch', 'specific_course')),
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Courses table
CREATE TABLE IF NOT EXISTS public.courses (
  id TEXT PRIMARY KEY,
  title_bn TEXT NOT NULL,
  title_en TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL CHECK (category IN ('complete', 'preliminary', 'written', 'subject_wise')),
  description TEXT,
  thumbnail_url TEXT,
  duration_weeks INTEGER DEFAULT 16,
  regular_price_bdt NUMERIC NOT NULL,
  promotional_price_bdt NUMERIC,
  enrollment_status TEXT DEFAULT 'open' CHECK (enrollment_status IN ('open', 'closed', 'upcoming')),
  features JSONB DEFAULT '[]'::jsonb,
  access_days INTEGER DEFAULT 365,
  is_published BOOLEAN DEFAULT true,
  is_featured BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Enrollments table
CREATE TABLE IF NOT EXISTS public.enrollments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  course_id TEXT REFERENCES public.courses(id) ON DELETE CASCADE,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'expired', 'revoked', 'pending')),
  start_date TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()),
  expires_at TIMESTAMPTZ NOT NULL,
  granted_by UUID REFERENCES public.profiles(id),
  payment_id TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Payments table
CREATE TABLE IF NOT EXISTS public.payments (
  id TEXT PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  user_email TEXT NOT NULL,
  course_id TEXT REFERENCES public.courses(id) ON DELETE SET NULL,
  course_title TEXT NOT NULL,
  amount_bdt NUMERIC NOT NULL,
  currency TEXT DEFAULT 'BDT',
  payment_method TEXT NOT NULL,
  transaction_ref TEXT UNIQUE,
  sender_phone TEXT,
  verification_status TEXT DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected', 'refunded')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()),
  verified_at TIMESTAMPTZ
);

-- WhatsApp inquiries table
CREATE TABLE IF NOT EXISTS public.course_inquiries (
  id TEXT PRIMARY KEY,
  course_id TEXT,
  course_title TEXT NOT NULL,
  contact_name TEXT NOT NULL,
  contact_phone TEXT NOT NULL,
  user_email TEXT,
  message TEXT NOT NULL,
  status TEXT DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'awaiting_payment', 'payment_confirmed', 'access_granted', 'closed')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Enable Row Level Security (RLS)
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lectures ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_inquiries ENABLE ROW LEVEL SECURITY;

-- Profiles: Users can view their own profile; Super Admin can view/edit all
CREATE POLICY "Users view own profile" ON public.profiles FOR SELECT USING (auth.uid() = id);
CREATE POLICY "Super Admin full control profiles" ON public.profiles USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'super_admin')
);

-- Courses & Subjects: Public read for published
CREATE POLICY "Public view published subjects" ON public.subjects FOR SELECT USING (is_published = true);
CREATE POLICY "Public view published courses" ON public.courses FOR SELECT USING (is_published = true);

-- Enrollments: Users view own enrollments
CREATE POLICY "Users view own enrollments" ON public.enrollments FOR SELECT USING (auth.uid() = user_id);

-- Super admin access
CREATE POLICY "Super admin manage all" ON public.courses USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'super_admin')
);
`;
  }
}
