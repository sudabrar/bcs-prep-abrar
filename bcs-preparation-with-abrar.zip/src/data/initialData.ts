import { 
  Subject, 
  Chapter, 
  Topic, 
  Lecture, 
  Course, 
  Batch, 
  UserProfile, 
  Enrollment, 
  AccessRequest, 
  CourseInquiry, 
  Payment, 
  Coupon, 
  Announcement, 
  SiteSettings, 
  ActivityLog 
} from '../types';

export const INITIAL_SITE_SETTINGS: SiteSettings = {
  siteTitle: "BCS Preparation With Abrar",
  ownerName: "Abrar",
  phoneLocal: "01758898767",
  phoneIntl: "8801758898767",
  whatsappMessageTemplate: "Assalamu Alaikum. I am interested in purchasing the {course_title} (ID: {course_id}) course from BCS Preparation With Abrar. Please share the current price, enrollment process, and payment details.",
  emailContact: "support@bcsprepabrar.com",
  bkashMerchantNumber: "01758898767",
  nagadMerchantNumber: "01758898767",
  bankAccountDetails: "Bank: City Bank PLC | Account Name: BCS Preparation With Abrar | A/C No: 1502489201001 | Branch: Dhanmondi, Dhaka",
  announcementBarText: "🎉 ৪৭তম ও ৪৮তম বিসিএস প্রিলিমিনারি ও লিখিত নতুন ব্যাচে ভর্তি চলছে! সরাসরি হোয়াটসঅ্যাপে যোগাযোগ করুন: ০১৭৫৮৮৯৮৭৬৭",
  isRegistrationOpen: true,
  demoVideoUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
  heroHeadlineBn: "বিসিএস প্রস্তুতির বিশ্বস্ত প্ল্যাটফর্ম",
  heroHeadlineEn: "BCS Preparation With Abrar",
  heroSubtitleBn: "সুশৃঙ্খল ভিডিও লেকচার, তথ্যবহুল ক্লাস নোট ও অভিজ্ঞ নির্দেশনায় ৪৭তম ও ৪৮তম বিসিএস প্রিলিমিনারি ও লিখিত পরীক্ষার শতভাগ প্রস্তুতি নিন।",
  heroSubtitleEn: "Prepare for BCS with organized lectures, comprehensive class notes, subject-wise courses, and a structured learning experience."
};

export const INITIAL_PROFILES: UserProfile[] = [
  {
    id: "usr_admin_abrar",
    email: "abrar@bcsprepabrar.com",
    fullName: "Abrar (Instructor & Super Admin)",
    phone: "01758898767",
    role: "super_admin",
    status: "approved",
    district: "Dhaka",
    targetBcsCadre: "BCS Administration",
    createdAt: "2026-01-01T00:00:00Z"
  },
  {
    id: "usr_student_rahim",
    email: "rahim.hassan@example.com",
    fullName: "Rahim Hassan",
    phone: "01812345678",
    role: "student",
    status: "approved",
    district: "Chattogram",
    targetBcsCadre: "BCS Foreign Affairs",
    createdAt: "2026-01-15T10:30:00Z"
  },
  {
    id: "usr_student_fatima",
    email: "fatima.zahan@example.com",
    fullName: "Fatima Zahan",
    phone: "01998765432",
    role: "student",
    status: "approved",
    district: "Rajshahi",
    targetBcsCadre: "BCS Police",
    createdAt: "2026-02-01T14:15:00Z"
  },
  {
    id: "usr_pending_student",
    email: "tanvir.ahmed@example.com",
    fullName: "Tanvir Ahmed",
    phone: "01671122334",
    role: "student",
    status: "pending",
    district: "Sylhet",
    targetBcsCadre: "BCS General Education",
    createdAt: "2026-03-01T08:00:00Z"
  }
];

export const INITIAL_SUBJECTS: Subject[] = [
  {
    id: "sub_bangla_lang",
    titleBn: "বাংলা ভাষা ও ব্যাকরণ",
    titleEn: "Bangla Language and Grammar",
    code: "BCS-01",
    description: "ধ্বনি, বর্ণ, শব্দ, পদ, সন্ধি, সমাস, কারক, বিভক্তি ও বাক্য শুদ্ধিকরণ।",
    examType: "both",
    orderIndex: 1,
    isPublished: true,
    totalChapters: 8,
    totalLectures: 24
  },
  {
    id: "sub_bangla_lit",
    titleBn: "বাংলা সাহিত্য",
    titleEn: "Bangla Literature",
    code: "BCS-02",
    description: "প্রাচীন ও মধ্যযুগ (চর্যাপদ, মঙ্গলকাব্য), আধুনিক যুগ, বিখ্যাত কবি ও সাহিত্যিক।",
    examType: "both",
    orderIndex: 2,
    isPublished: true,
    totalChapters: 6,
    totalLectures: 20
  },
  {
    id: "sub_eng_lang",
    titleBn: "ইংরেজি ভাষা ও ব্যাকরণ",
    titleEn: "English Language",
    code: "BCS-03",
    description: "Parts of Speech, Grammar Rules, Vocabulary, Preposition & Sentence Correction.",
    examType: "both",
    orderIndex: 3,
    isPublished: true,
    totalChapters: 10,
    totalLectures: 32
  },
  {
    id: "sub_eng_lit",
    titleBn: "ইংরেজি সাহিত্য",
    titleEn: "English Literature",
    code: "BCS-04",
    description: "Renaissance, Romantic, Victorian, Modern Periods, Major authors & Quotations.",
    examType: "preliminary",
    orderIndex: 4,
    isPublished: true,
    totalChapters: 7,
    totalLectures: 18
  },
  {
    id: "sub_math_mental",
    titleBn: "গাণিতিক যুক্তি ও মানসিক দক্ষতা",
    titleEn: "Mathematics and Mental Ability",
    code: "BCS-05",
    description: "পাটিগণিত, বীজগণিত, জ্যামিতি, বিন্যাস-সমাবেশ, সম্ভাবনা এবং মানসিক দক্ষতা।",
    examType: "both",
    orderIndex: 5,
    isPublished: true,
    totalChapters: 9,
    totalLectures: 28
  },
  {
    id: "sub_bd_affairs",
    titleBn: "বাংলাদেশ বিষয়াবলী",
    titleEn: "Bangladesh Affairs",
    code: "BCS-06",
    description: "ইতিহাস, মুক্তিযুদ্ধ, সংবিধান, অর্থনীতি, কৃষি ও জাতীয় অর্জন।",
    examType: "both",
    orderIndex: 6,
    isPublished: true,
    totalChapters: 8,
    totalLectures: 26
  },
  {
    id: "sub_intl_affairs",
    titleBn: "আন্তর্জাতিক বিষয়াবলী",
    titleEn: "International Affairs",
    code: "BCS-07",
    description: "বৈশ্বিক ইতিহাস, ভূ-রাজনীতি, আন্তর্জাতিক সংস্থা, চুক্তি ও চলমান বিশ্ব পরিস্থিতি।",
    examType: "both",
    orderIndex: 7,
    isPublished: true,
    totalChapters: 6,
    totalLectures: 18
  },
  {
    id: "sub_general_sci",
    titleBn: "সাধারণ বিজ্ঞান",
    titleEn: "General Science",
    code: "BCS-08",
    description: "ভৌত বিজ্ঞান, জীববিজ্ঞান, মানবদেহ, আধুনিক প্রযুক্তি ও চিকিৎসাবিজ্ঞান।",
    examType: "both",
    orderIndex: 8,
    isPublished: true,
    totalChapters: 6,
    totalLectures: 16
  },
  {
    id: "sub_ict",
    titleBn: "কম্পিউটার ও তথ্যপ্রযুক্তি",
    titleEn: "Computer and Information Technology",
    code: "BCS-09",
    description: "কম্পিউটার সিস্টেম, নেটওয়ার্কিং, সাইবার সিকিউরিটি, ইন্টারনেট ও ক্লাউড প্রযুক্তি।",
    examType: "both",
    orderIndex: 9,
    isPublished: true,
    totalChapters: 5,
    totalLectures: 14
  },
  {
    id: "sub_ethics",
    titleBn: "নৈতিকতা, মূল্যবোধ ও সুশাসন",
    titleEn: "Ethics, Values and Good Governance",
    code: "BCS-10",
    description: "মূল্যবোধের ধারণা, নাগরিক দায়িত্ব, সুশাসনের উপাদান ও সরকারি চার্টার।",
    examType: "preliminary",
    orderIndex: 10,
    isPublished: true,
    totalChapters: 4,
    totalLectures: 10
  },
  {
    id: "sub_geography",
    titleBn: "ভূগোল, পরিবেশ ও দুর্যোগ ব্যবস্থাপনা",
    titleEn: "Geography, Environment & Disaster Management",
    code: "BCS-11",
    description: "বাংলাদেশ ও বৈশ্বিক ভূগোল, আবহাওয়া ও জলবায়ু পরিবর্তন, প্রাকৃতিক দুর্যোগ।",
    examType: "both",
    orderIndex: 11,
    isPublished: true,
    totalChapters: 5,
    totalLectures: 12
  }
];

export const INITIAL_CHAPTERS: Chapter[] = [
  // Bangla Language Chapters
  { id: "ch_bl_01", subjectId: "sub_bangla_lang", titleBn: "বাংলা ব্যাকরণ পরিচিতি ও ধ্বনিতত্ত্ব", titleEn: "Bangla Grammar Intro & Phonetics", orderIndex: 1, isPublished: true, topicsCount: 4 },
  { id: "ch_bl_02", subjectId: "sub_bangla_lang", titleBn: "সন্ধি ও সমাস", titleEn: "Sandhi & Samas", orderIndex: 2, isPublished: true, topicsCount: 5 },
  { id: "ch_bl_03", subjectId: "sub_bangla_lang", titleBn: "কারক ও বিভক্তি", titleEn: "Karak & Bibhakti", orderIndex: 3, isPublished: true, topicsCount: 3 },
  { id: "ch_bl_04", subjectId: "sub_bangla_lang", titleBn: "প্রত্যয় ও উপসর্গ", titleEn: "Suffix & Prefix", orderIndex: 4, isPublished: true, topicsCount: 4 },
  
  // Bangla Literature Chapters
  { id: "ch_blit_01", subjectId: "sub_bangla_lit", titleBn: "প্রাচীন ও মধ্যযুগ (চর্যাপদ ও মঙ্গলকাব্য)", titleEn: "Ancient & Medieval Literature", orderIndex: 1, isPublished: true, topicsCount: 3 },
  { id: "ch_blit_02", subjectId: "sub_bangla_lit", titleBn: "আধুনিক যুগ ও পঞ্চপাণ্ডব", titleEn: "Modern Era & Five Pandavas", orderIndex: 2, isPublished: true, topicsCount: 5 },

  // English Language Chapters
  { id: "ch_el_01", subjectId: "sub_eng_lang", titleBn: "Parts of Speech & Classification", titleEn: "Parts of Speech & Classification", orderIndex: 1, isPublished: true, topicsCount: 6 },
  { id: "ch_el_02", subjectId: "sub_eng_lang", titleBn: "Subject-Verb Agreement & Conditionals", titleEn: "Subject-Verb Agreement & Conditionals", orderIndex: 2, isPublished: true, topicsCount: 4 },
  { id: "ch_el_03", subjectId: "sub_eng_lang", titleBn: "Prepositions & Idiomatic Phrasals", titleEn: "Prepositions & Phrasals", orderIndex: 3, isPublished: true, topicsCount: 5 },

  // English Literature Chapters
  { id: "ch_elit_01", subjectId: "sub_eng_lit", titleBn: "The Renaissance & Elizabethan Age", titleEn: "The Renaissance & Elizabethan Age", orderIndex: 1, isPublished: true, topicsCount: 4 },
  { id: "ch_elit_02", subjectId: "sub_eng_lit", titleBn: "Romantic & Victorian Periods", titleEn: "Romantic & Victorian Periods", orderIndex: 2, isPublished: true, topicsCount: 5 },

  // Math Chapters
  { id: "ch_m_01", subjectId: "sub_math_mental", titleBn: "বাস্তব সংখ্যা ও ল.সা.গু/গ.সা.গু", titleEn: "Real Numbers, LCM & HCF", orderIndex: 1, isPublished: true, topicsCount: 3 },
  { id: "ch_m_02", subjectId: "sub_math_mental", titleBn: "শতকরা ও লাভ-ক্ষতি", titleEn: "Percentage, Profit & Loss", orderIndex: 2, isPublished: true, topicsCount: 4 },
  { id: "ch_m_03", subjectId: "sub_math_mental", titleBn: "বীজগণিতীয় সূত্রাবলী ও সমীকরণ", titleEn: "Algebraic Formulas & Equations", orderIndex: 3, isPublished: true, topicsCount: 4 },

  // Bangladesh Affairs Chapters
  { id: "ch_bd_01", subjectId: "sub_bd_affairs", titleBn: "বাংলাদেশের সংবিধান ও মূলনীতি", titleEn: "Constitution of Bangladesh", orderIndex: 1, isPublished: true, topicsCount: 5 },
  { id: "ch_bd_02", subjectId: "sub_bd_affairs", titleBn: "মুক্তিযুদ্ধ ও স্বাধীনতার ইতিহাস", titleEn: "Liberation War History", orderIndex: 2, isPublished: true, topicsCount: 4 },

  // International Affairs
  { id: "ch_ia_01", subjectId: "sub_intl_affairs", titleBn: "আন্তর্জাতিক সংস্থা (জাতিসংঘ ও আঞ্চলিক)", titleEn: "International Organizations", orderIndex: 1, isPublished: true, topicsCount: 4 },

  // ICT
  { id: "ch_ict_01", subjectId: "sub_ict", titleBn: "কম্পিউটার সংগঠন ও মেমরি সিস্টেম", titleEn: "Computer System & Memory", orderIndex: 1, isPublished: true, topicsCount: 3 }
];

export const INITIAL_TOPICS: Topic[] = [
  { id: "top_01", chapterId: "ch_bl_01", titleBn: "ধ্বনি ও বর্ণের উচ্চারণ স্থান", titleEn: "Pronunciation points of sounds", orderIndex: 1 },
  { id: "top_02", chapterId: "ch_bl_02", titleBn: "স্বরসন্ধি ও ব্যঞ্জনসন্ধির সহজ নিয়ম", titleEn: "Rules of Sandhi", orderIndex: 1 },
  { id: "top_03", chapterId: "ch_bl_02", titleBn: "তৎপুরুষ, বহুব্রীহি ও দ্বন্দ্ব সমাস", titleEn: "Samas classifications", orderIndex: 2 },
  { id: "top_04", chapterId: "ch_el_01", titleBn: "Identification of Noun, Gerund & Participle", titleEn: "Noun, Gerund & Participle", orderIndex: 1 },
  { id: "top_05", chapterId: "ch_el_02", titleBn: "Special rules of Subject-Verb Inversion", titleEn: "Subject-Verb Inversion", orderIndex: 1 },
  { id: "top_06", chapterId: "ch_bd_01", titleBn: "সংবিধানের প্রস্তাবনা ও মৌলিক অধিকারসমূহ", titleEn: "Preamble & Fundamental Rights", orderIndex: 1 },
  { id: "top_07", chapterId: "ch_m_02", titleBn: "ধারাবাহিক লাভ-ক্ষতি ও শর্টকাট টেকনিক", titleEn: "Successive Profit & Loss Techniques", orderIndex: 1 }
];

export const INITIAL_COURSES: Course[] = [
  {
    id: "crs_bcs_complete",
    titleBn: "৪৭তম ও ৪৮তম বিসিএস ফুল প্রিপারেশন কোর্স (প্রিলি + লিখিত)",
    titleEn: "BCS Complete Preparation Mastercourse (Prelim + Written)",
    slug: "bcs-complete-mastercourse",
    category: "complete",
    description: "বিসিএস প্রিলিমিনারি ২০০ মার্কস এবং লিখিত ৯০০ মার্কসের সম্পূর্ণ সিলেবাসভিত্তিক মাস্টারকোর্স। নিয়মিত লাইভ ক্লাস, রেকর্ডেড ব্যাকআপ, প্রতি লেকচারের গুগল ড্রাইভ হ্যান্ডনোট এবং সার্বক্ষণিক মেন্টরশিপ।",
    thumbnailUrl: "/src/assets/images/bcs_hero_education_1791590008571.jpg",
    subjectIds: ["sub_bangla_lang", "sub_bangla_lit", "sub_eng_lang", "sub_eng_lit", "sub_math_mental", "sub_bd_affairs", "sub_intl_affairs", "sub_general_sci", "sub_ict", "sub_ethics", "sub_geography"],
    durationWeeks: 36,
    regularPriceBdt: 8500,
    promotionalPriceBdt: 5900,
    startDate: "2026-03-01",
    endDate: "2026-11-30",
    enrollmentStatus: "open",
    features: [
      "২০০+ এইচডি রেকর্ডেড ক্লাস ও নিয়মিত লাইভ সেশন",
      "প্রতিটি ক্লাসের সমৃদ্ধ গুগল ড্রাইভ হ্যান্ডনোট (PDF)",
      "সাবজেক্ট-ওয়াইজ বিগত বছরের বিসিএস প্রশ্ন সমাধান",
      "হোয়াটসঅ্যাপে সরাসরি আবরার স্যারের সাথে ডাউট সলভ",
      "লিখিত পরীক্ষার জন্য বিশেষ মানচিত্র ও ডেটা অ্যানালাইসিস শিট"
    ],
    accessDays: 365,
    isPublished: true,
    isFeatured: true,
    createdAt: "2026-01-10T00:00:00Z"
  },
  {
    id: "crs_bcs_prelim",
    titleBn: "বিসিএস প্রিলিমিনারি স্পেশাল ফাউন্ডেশন কোর্স",
    titleEn: "BCS Preliminary Special Foundation Course",
    slug: "bcs-preliminary-foundation",
    category: "preliminary",
    description: "বিসিএস প্রিলিমিনারি পরীক্ষায় নিশ্চিত কাট-মার্কস অর্জনের লক্ষ্যে ১০টি বিষয়ের সুবিন্যস্ত লেকচার ও প্র্যাকটিস নোট সিরিজ।",
    thumbnailUrl: "/src/assets/images/bcs_study_materials_1791590036299.jpg",
    subjectIds: ["sub_bangla_lang", "sub_bangla_lit", "sub_eng_lang", "sub_eng_lit", "sub_math_mental", "sub_bd_affairs", "sub_intl_affairs", "sub_general_sci", "sub_ict", "sub_ethics", "sub_geography"],
    durationWeeks: 20,
    regularPriceBdt: 5000,
    promotionalPriceBdt: 3500,
    startDate: "2026-03-15",
    endDate: "2026-08-15",
    enrollmentStatus: "open",
    features: [
      "১৩০+ প্রিলিমিনারি ফোকাসড লেকচার",
      "টপিকভিত্তিক প্রিন্ট-রেডি ক্লাস নোটস",
      "শর্টকাট ট্রিকস ও মেমোরি টেকনিক",
      "হোয়াটসঅ্যাপ ডিসকাশন গ্রুপে লাইভ সাপোর্ট"
    ],
    accessDays: 240,
    isPublished: true,
    isFeatured: true,
    createdAt: "2026-01-15T00:00:00Z"
  },
  {
    id: "crs_bcs_english",
    titleBn: "বিসিএস ইংলিশ মাস্টারক্লাস (Grammar + Literature)",
    titleEn: "BCS English Masterclass (Language & Literature)",
    slug: "bcs-english-masterclass",
    category: "subject_wise",
    description: "ইংলিশে ৩৫ মার্কসের সর্বোচ্চ প্রস্তুতি! Parts of speech, vocabulary, tense থেকে শুরু করে Elizabethan ও Romantic period এর জটিল সাহিত্যকে সহজ করার অনন্য কোর্স।",
    thumbnailUrl: "/src/assets/images/instructor_abrar_portrait_1791590021132.jpg",
    subjectIds: ["sub_eng_lang", "sub_eng_lit"],
    durationWeeks: 12,
    regularPriceBdt: 2500,
    promotionalPriceBdt: 1800,
    startDate: "2026-04-01",
    endDate: "2026-06-30",
    enrollmentStatus: "open",
    features: [
      "৫০+ কনসেপ্টচুয়াল ইংলিশ লেকচার",
      "সাহিত্যিকদের কোটেশন ও টাইমলাইন চার্ট",
      "ডেইলি ভোকাবুলারি রিভিশন মেটিরিয়ালস",
      "বিসিএস লিখিত অংশের ফ্রি-হ্যান্ড রাইটিং গাইডলাইন"
    ],
    accessDays: 180,
    isPublished: true,
    isFeatured: true,
    createdAt: "2026-01-20T00:00:00Z"
  },
  {
    id: "crs_bcs_bd_affairs",
    titleBn: "বাংলাদেশ বিষয়াবলী ও সংবিধান ক্র্যাশ কোর্স",
    titleEn: "Bangladesh Affairs & Constitution Crash Course",
    slug: "bcs-bangladesh-affairs-constitution",
    category: "subject_wise",
    description: "মুক্তিযুদ্ধ, বাংলাদেশের সংবিধানের জটিল অনুচ্ছেদ এবং অর্থনৈতিক সমীক্ষার সাম্প্রতিক ডেটা নিয়ে সাজানো সমৃদ্ধ কোর্স।",
    thumbnailUrl: "/src/assets/images/bcs_hero_education_1791590008571.jpg",
    subjectIds: ["sub_bd_affairs"],
    durationWeeks: 10,
    regularPriceBdt: 2000,
    promotionalPriceBdt: 1400,
    startDate: "2026-04-10",
    endDate: "2026-06-20",
    enrollmentStatus: "open",
    features: [
      "সংবিধানের গুরুত্বপূর্ণ ৫০টি অনুচ্ছেদের সহজ ব্যাখ্যা",
      "ঐতিহাসিক চার্ট ও ফ্লো-ডায়াগ্রাম",
      "লিখিত পরীক্ষার প্রাসঙ্গিক কোটেশন ও তথ্যসূত্র"
    ],
    accessDays: 180,
    isPublished: true,
    isFeatured: false,
    createdAt: "2026-02-01T00:00:00Z"
  }
];

export const INITIAL_LECTURES: Lecture[] = [
  {
    id: "lec_demo_01",
    subjectId: "sub_bd_affairs",
    chapterId: "ch_bd_01",
    topicId: "top_06",
    courseIds: ["crs_bcs_complete", "crs_bcs_prelim", "crs_bcs_bd_affairs"],
    titleBn: "বাংলাদেশের সংবিধান পরিচিতি ও মূলনীতিসমূহ (ফ্রি ডেমো ক্লাস)",
    titleEn: "Introduction to Bangladesh Constitution & Fundamental Principles (Free Demo)",
    examType: "both",
    description: "সংবিধানের প্রস্তাবনা, ঐতিহাসিক পটভূমি এবং ৭, ১১, ১৯, ২৭, ২৮ নম্বর গুরুত্বপূর্ণ অনুচ্ছেদের সহজ বিশ্লেষণ। এই ক্লাসটি দেখে যেকোনো শিক্ষার্থী বিসিএস সংবিধান অংশের ভীতি দূর করতে পারবে।",
    youtubeUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    driveNotesUrl: "https://drive.google.com/file/d/1DemoDriveNotesBcsConstitutionAbrar/view",
    teacherName: "Abrar",
    lectureNumber: 1,
    durationMinutes: 48,
    tags: ["Constitution", "Bangladesh Affairs", "Prelim & Written", "Free Demo"],
    isFreePreview: true,
    publicationStatus: "published",
    accessType: "public",
    orderIndex: 1,
    createdAt: "2026-01-12T00:00:00Z"
  },
  {
    id: "lec_demo_02",
    subjectId: "sub_eng_lang",
    chapterId: "ch_el_01",
    topicId: "top_04",
    courseIds: ["crs_bcs_complete", "crs_bcs_prelim", "crs_bcs_english"],
    titleBn: "Parts of Speech Identification & Gerund vs Participle (ফ্রি ডেমো)",
    titleEn: "Parts of Speech Identification & Gerund vs Participle (Free Demo)",
    examType: "preliminary",
    description: "বিসিএস প্রিলিমিনারিতে প্রতি বছর আসা Gerund এবং Present Participle চেনার ম্যাজিক টেকনিক ও ১০টি বিগত বছরের ট্রিকি প্রশ্নের সমাধান।",
    youtubeUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    driveNotesUrl: "https://drive.google.com/file/d/1DemoDriveNotesEnglishGrammarAbrar/view",
    teacherName: "Abrar",
    lectureNumber: 2,
    durationMinutes: 42,
    tags: ["English Grammar", "Parts of Speech", "Gerund", "Participle"],
    isFreePreview: true,
    publicationStatus: "published",
    accessType: "public",
    orderIndex: 2,
    createdAt: "2026-01-14T00:00:00Z"
  },
  {
    id: "lec_03_bangla_sandhi",
    subjectId: "sub_bangla_lang",
    chapterId: "ch_bl_02",
    topicId: "top_02",
    courseIds: ["crs_bcs_complete", "crs_bcs_prelim"],
    titleBn: "সন্ধি নির্ণয়ের অভিনব কৌশল ও বিশেষ নিপাতনে সিদ্ধ সন্ধি",
    titleEn: "Innovative Sandhi Techniques & Irregular Sandhi Rules",
    examType: "preliminary",
    description: "স্বরসন্ধি ও ব্যঞ্জনসন্ধি মনে রাখার নিয়মাবলী এবং বিসিএস ও পিএসসি পরীক্ষায় বারবার আসা ১০০টি গুরুত্বপূর্ণ সন্ধি বিচ্ছেদ।",
    youtubeUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    driveNotesUrl: "https://drive.google.com/file/d/1DemoDriveNotesBanglaSandhiAbrar/view",
    teacherName: "Abrar",
    lectureNumber: 3,
    durationMinutes: 52,
    tags: ["Bangla Grammar", "Sandhi", "Preliminary"],
    isFreePreview: false,
    publicationStatus: "published",
    accessType: "enrolled_students",
    orderIndex: 3,
    createdAt: "2026-01-16T00:00:00Z"
  },
  {
    id: "lec_04_eng_lit_periods",
    subjectId: "sub_eng_lit",
    chapterId: "ch_elit_01",
    courseIds: ["crs_bcs_complete", "crs_bcs_prelim", "crs_bcs_english"],
    titleBn: "The Elizabethan Age & William Shakespeare Special Lecture",
    titleEn: "The Elizabethan Age & William Shakespeare Special Lecture",
    examType: "preliminary",
    description: "শেক্সপিয়রের বিখ্যাত ট্র্যাজেডি ও কমেডি, অমর কোটেশন, সনেট এবং এলিজাবেথান যুগের সমসাময়িক লেখকদের তুলনামূলক স্টাডি।",
    youtubeUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    driveNotesUrl: "https://drive.google.com/file/d/1DemoDriveNotesShakespeareAbrar/view",
    teacherName: "Abrar",
    lectureNumber: 4,
    durationMinutes: 55,
    tags: ["English Literature", "Shakespeare", "Elizabethan Age"],
    isFreePreview: false,
    publicationStatus: "published",
    accessType: "enrolled_students",
    orderIndex: 4,
    createdAt: "2026-01-20T00:00:00Z"
  },
  {
    id: "lec_05_math_profit",
    subjectId: "sub_math_mental",
    chapterId: "ch_m_02",
    topicId: "top_07",
    courseIds: ["crs_bcs_complete", "crs_bcs_prelim"],
    titleBn: "লাভ-ক্ষতি ও সরল সুদের শর্টকাট সমীকরণ ও লিখিত সমাধান",
    titleEn: "Profit, Loss & Simple Interest Shortcut Formulas & Written Solves",
    examType: "both",
    description: "প্রিলিমিনারির জন্য ৩০ সেকেন্ডে উত্তর বের করার টেকনিক এবং লিখিত পরীক্ষার জন্য ধাপে ধাপে ব্যাখ্যামূলক অংক উপস্থাপনা।",
    youtubeUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    driveNotesUrl: "https://drive.google.com/file/d/1DemoDriveNotesMathProfitLossAbrar/view",
    teacherName: "Abrar",
    lectureNumber: 5,
    durationMinutes: 60,
    tags: ["Math", "Profit & Loss", "Written Math", "Prelim Math"],
    isFreePreview: false,
    publicationStatus: "published",
    accessType: "enrolled_students",
    orderIndex: 5,
    createdAt: "2026-01-25T00:00:00Z"
  },
  {
    id: "lec_06_ict_memory",
    subjectId: "sub_ict",
    chapterId: "ch_ict_01",
    courseIds: ["crs_bcs_complete", "crs_bcs_prelim"],
    titleBn: "কম্পিউটার মেমোরি, প্রসেসর ও ক্যাশ মেমোরির কার্যপ্রণালী",
    titleEn: "Computer Memory Hierarchy, Cache & Processor Architecture",
    examType: "both",
    description: "RAM, ROM, Register, Cache Memory, Virtual Memory এর তুলনামূলক বিশ্লেষণ এবং বিগত বিসিএস পরীক্ষার প্রশ্নব্যাংক অ্যানালাইসিস।",
    youtubeUrl: "https://www.youtube.com/watch?v=dQw4w9WgXcQ",
    driveNotesUrl: "https://drive.google.com/file/d/1DemoDriveNotesComputerMemoryAbrar/view",
    teacherName: "Abrar",
    lectureNumber: 6,
    durationMinutes: 38,
    tags: ["ICT", "Computer Memory", "Preliminary", "Written"],
    isFreePreview: false,
    publicationStatus: "published",
    accessType: "enrolled_students",
    orderIndex: 6,
    createdAt: "2026-02-01T00:00:00Z"
  }
];

export const INITIAL_BATCHES: Batch[] = [
  {
    id: "btc_prelim_01",
    courseId: "crs_bcs_prelim",
    name: "BCS Preliminary Batch 01 (Special)",
    description: "৪৭তম ও ৪৮তম বিসিএস প্রিলিমিনারি প্রস্তুতি বিশেষ ব্যাচ।",
    startDate: "2026-03-01",
    endDate: "2026-08-30",
    maxStudents: 150,
    enrolledStudentsCount: 42,
    isActive: true,
    createdAt: "2026-01-05T00:00:00Z"
  },
  {
    id: "btc_written_01",
    courseId: "crs_bcs_complete",
    name: "BCS Written & Master Batch 01",
    description: "বিসিএস প্রিলিমিনারি ও লিখিত পূর্ণাঙ্গ সমন্বিত ব্যাচ।",
    startDate: "2026-03-15",
    endDate: "2026-11-30",
    maxStudents: 100,
    enrolledStudentsCount: 28,
    isActive: true,
    createdAt: "2026-01-08T00:00:00Z"
  },
  {
    id: "btc_english_01",
    courseId: "crs_bcs_english",
    name: "English Foundation Batch 01",
    description: "ইংরেজি ভাষা ও সাহিত্যের বিশেষ স্পিড ব্যাচ।",
    startDate: "2026-04-01",
    endDate: "2026-06-30",
    maxStudents: 120,
    enrolledStudentsCount: 35,
    isActive: true,
    createdAt: "2026-01-12T00:00:00Z"
  }
];

export const INITIAL_ENROLLMENTS: Enrollment[] = [
  {
    id: "enr_01",
    userId: "usr_student_rahim",
    courseId: "crs_bcs_complete",
    batchId: "btc_written_01",
    status: "active",
    startDate: "2026-01-15T11:00:00Z",
    expiresAt: "2027-01-15T11:00:00Z",
    grantedBy: "usr_admin_abrar",
    paymentId: "pay_01_verified",
    createdAt: "2026-01-15T11:00:00Z"
  },
  {
    id: "enr_02",
    userId: "usr_student_fatima",
    courseId: "crs_bcs_english",
    batchId: "btc_english_01",
    status: "active",
    startDate: "2026-02-01T15:00:00Z",
    expiresAt: "2026-08-01T15:00:00Z",
    grantedBy: "usr_admin_abrar",
    paymentId: "pay_02_verified",
    createdAt: "2026-02-01T15:00:00Z"
  }
];

export const INITIAL_PAYMENTS: Payment[] = [
  {
    id: "pay_01_verified",
    userId: "usr_student_rahim",
    userEmail: "rahim.hassan@example.com",
    courseId: "crs_bcs_complete",
    courseTitle: "৪৭তম ও ৪৮তম বিসিএস ফুল প্রিপারেশন কোর্স (প্রিলি + লিখিত)",
    amountBdt: 5900,
    currency: "BDT",
    paymentMethod: "bkash",
    transactionRef: "9B7K2X44Q1",
    senderPhone: "01812345678",
    verificationStatus: "verified",
    verifiedBy: "usr_admin_abrar",
    adminNotes: "Received via bKash merchant. Verified and course access granted.",
    createdAt: "2026-01-15T10:45:00Z",
    verifiedAt: "2026-01-15T11:00:00Z"
  },
  {
    id: "pay_02_verified",
    userId: "usr_student_fatima",
    userEmail: "fatima.zahan@example.com",
    courseId: "crs_bcs_english",
    courseTitle: "বিসিএস ইংলিশ মাস্টারক্লাস (Grammar + Literature)",
    amountBdt: 1800,
    currency: "BDT",
    paymentMethod: "nagad",
    transactionRef: "8NM4P9982L",
    senderPhone: "01998765432",
    verificationStatus: "verified",
    verifiedBy: "usr_admin_abrar",
    adminNotes: "Paid via Nagad. Verified.",
    createdAt: "2026-02-01T14:30:00Z",
    verifiedAt: "2026-02-01T15:00:00Z"
  },
  {
    id: "pay_03_pending",
    userId: "usr_pending_student",
    userEmail: "tanvir.ahmed@example.com",
    courseId: "crs_bcs_prelim",
    courseTitle: "বিসিএস প্রিলিমিনারি স্পেশাল ফাউন্ডেশন কোর্স",
    amountBdt: 3500,
    currency: "BDT",
    paymentMethod: "whatsapp_manual",
    transactionRef: "TRX-77491209",
    senderPhone: "01671122334",
    verificationStatus: "pending",
    adminNotes: "Student provided TrxID via WhatsApp. Pending bank statement check.",
    createdAt: "2026-03-01T08:10:00Z"
  }
];

export const INITIAL_INQUIRIES: CourseInquiry[] = [
  {
    id: "inq_01",
    courseId: "crs_bcs_complete",
    courseTitle: "৪৭তম ও ৪৮তম বিসিএস ফুল প্রিপারেশন কোর্স (প্রিলি + লিখিত)",
    userId: "usr_student_rahim",
    contactName: "Rahim Hassan",
    contactPhone: "01812345678",
    userEmail: "rahim.hassan@example.com",
    message: "Assalamu Alaikum. I am interested in purchasing the BCS Complete Preparation Mastercourse. Please share the payment process.",
    status: "access_granted",
    adminNotes: "Paid through bKash and enrolled in Batch 01.",
    createdAt: "2026-01-15T10:00:00Z",
    updatedAt: "2026-01-15T11:00:00Z"
  },
  {
    id: "inq_02",
    courseId: "crs_bcs_english",
    courseTitle: "বিসিএস ইংলিশ মাস্টারক্লাস (Grammar + Literature)",
    contactName: "Sadia Sultana",
    contactPhone: "01711002233",
    userEmail: "sadia.bcs@gmail.com",
    message: "Assalamu Alaikum. How long will the English Masterclass take, and can I get the printed lecture notes delivered?",
    status: "contacted",
    adminNotes: "Replied via WhatsApp explaining Google Drive PDF notes and class timings.",
    createdAt: "2026-02-10T16:20:00Z",
    updatedAt: "2026-02-10T17:00:00Z"
  },
  {
    id: "inq_03",
    courseId: "crs_bcs_prelim",
    courseTitle: "বিসিএস প্রিলিমিনারি স্পেশাল ফাউন্ডেশন কোর্স",
    contactName: "Mahmudul Hasan",
    contactPhone: "01955667788",
    userEmail: "mahmudul.bcs@yahoo.com",
    message: "Interested in preliminary batch starting date and available discount coupon.",
    status: "new",
    adminNotes: "New inquiry from website WhatsApp button.",
    createdAt: "2026-03-02T11:45:00Z",
    updatedAt: "2026-03-02T11:45:00Z"
  }
];

export const INITIAL_ACCESS_REQUESTS: AccessRequest[] = [
  {
    id: "req_01",
    userId: "usr_pending_student",
    userEmail: "tanvir.ahmed@example.com",
    userName: "Tanvir Ahmed",
    userPhone: "01671122334",
    courseId: "crs_bcs_prelim",
    courseTitle: "বিসিএস প্রিলিমিনারি স্পেশাল ফাউন্ডেশন কোর্স",
    message: "Sir, I have submitted the course fee via bKash TrxID TRX-77491209. Kindly grant access.",
    status: "pending",
    createdAt: "2026-03-01T08:15:00Z"
  }
];

export const INITIAL_COUPONS: Coupon[] = [
  {
    id: "cpn_bcs2026",
    code: "BCS2026",
    discountType: "percentage",
    discountValue: 15,
    minSpendBdt: 2000,
    maxDiscountBdt: 1000,
    validFrom: "2026-01-01",
    validUntil: "2026-12-31",
    usageLimit: 500,
    timesUsed: 46,
    isActive: true,
    eligibleCourseIds: ["crs_bcs_complete", "crs_bcs_prelim", "crs_bcs_english", "crs_bcs_bd_affairs"]
  },
  {
    id: "cpn_special500",
    code: "ABRAR500",
    discountType: "fixed",
    discountValue: 500,
    minSpendBdt: 3000,
    validFrom: "2026-01-01",
    validUntil: "2026-06-30",
    usageLimit: 200,
    timesUsed: 18,
    isActive: true,
    eligibleCourseIds: ["crs_bcs_complete", "crs_bcs_prelim"]
  }
];

export const INITIAL_ANNOUNCEMENTS: Announcement[] = [
  {
    id: "anc_01",
    title: "৪৭তম ও ৪৮তম বিসিএস ফুল কোর্স স্পেশাল ওরিয়েন্টেশন ক্লাস",
    content: "সকল ভর্তি হওয়া শিক্ষার্থীদের জানানো যাচ্ছে যে আগামী ১৫ মার্চ রাত ৯টায় অনলাইন ওরিয়েন্টেশন ক্লাস অনুষ্ঠিত হবে। গুগল মিট লিংক ছাত্র ড্যাশবোর্ডে প্রদান করা হবে।",
    targetAudience: "all",
    priority: "important",
    isPublished: true,
    createdAt: "2026-02-20T10:00:00Z"
  },
  {
    id: "anc_02",
    title: "ইংরেজি সাহিত্য অংশের নতুন ক্লাস নোট ড্রাইভ ফোল্ডারে যুক্ত হয়েছে",
    content: "Elizabethan Age এবং Romantic Period এর ৩টি নতুন হ্যান্ডনোট ও টাইমলাইন শিট গুগল ড্রাইভ ফোল্ডারে আপলোড করা হয়েছে। শিক্ষার্থীরা লেকচার পেজ থেকে ডাউনলোড করতে পারবেন।",
    targetAudience: "specific_course",
    targetId: "crs_bcs_english",
    priority: "normal",
    isPublished: true,
    createdAt: "2026-02-28T14:30:00Z"
  }
];

export const INITIAL_ACTIVITY_LOGS: ActivityLog[] = [
  {
    id: "log_01",
    userId: "usr_admin_abrar",
    userEmail: "abrar@bcsprepabrar.com",
    action: "VERIFY_PAYMENT",
    entityType: "payment",
    entityId: "pay_01_verified",
    details: "Approved bKash payment ৳5,900 for Rahim Hassan and enrolled in BCS Complete Mastercourse.",
    createdAt: "2026-01-15T11:00:00Z"
  },
  {
    id: "log_02",
    userId: "usr_admin_abrar",
    userEmail: "abrar@bcsprepabrar.com",
    action: "PUBLISH_LECTURE",
    entityType: "lecture",
    entityId: "lec_06_ict_memory",
    details: "Published new lecture: Computer Memory Hierarchy & Cache Memory.",
    createdAt: "2026-02-01T00:00:00Z"
  },
  {
    id: "log_03",
    userId: "usr_admin_abrar",
    userEmail: "abrar@bcsprepabrar.com",
    action: "CREATE_BATCH",
    entityType: "batch",
    entityId: "btc_english_01",
    details: "Created English Foundation Batch 01 with max 120 student capacity.",
    createdAt: "2026-01-12T00:00:00Z"
  }
];
