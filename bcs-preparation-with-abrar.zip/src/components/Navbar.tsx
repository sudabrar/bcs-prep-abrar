import React from 'react';
import { BookOpen, User, Shield, Phone, Globe, LogOut, ChevronDown } from 'lucide-react';
import { DatabaseService } from '../services/db';
import { UserProfile } from '../types';

interface NavbarProps {
  currentView: string;
  onNavigate: (view: string, id?: string) => void;
  currentUser: UserProfile;
  language: 'bn' | 'en';
  onLanguageChange: (lang: 'bn' | 'en') => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  onNavigate,
  currentUser,
  language,
  onLanguageChange
}) => {
  const [userMenuOpen, setUserMenuOpen] = React.useState(false);
  const profiles = DatabaseService.getProfiles();
  const settings = DatabaseService.getSettings();

  const isBn = language === 'bn';

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200">
      {/* Top Announcement Kicker */}
      {settings.announcementBarText && (
        <div className="bg-slate-900 text-slate-100 text-xs px-4 py-1.5 flex items-center justify-between">
          <div className="max-w-7xl mx-auto w-full flex items-center justify-between">
            <span className="truncate text-slate-200 font-medium">
              {settings.announcementBarText}
            </span>
            <div className="hidden sm:flex items-center gap-4 text-slate-300 text-xs shrink-0 pl-4">
              <span className="flex items-center gap-1.5">
                <Phone className="w-3.5 h-3.5 text-teal-400" />
                <span className="font-mono tabular-nums">{settings.phoneLocal}</span>
              </span>
              <span className="text-slate-500">·</span>
              <span className="text-emerald-400 font-medium">হোয়াটসঅ্যাপে সার্বক্ষণিক সহায়তা</span>
            </div>
          </div>
        </div>
      )}

      {/* Main Top Bar Contract: 3 zones separated by gap-8 */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single text element wordmark */}
        <button
          onClick={() => onNavigate('home')}
          className="flex items-center gap-2.5 text-left group shrink-0 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-blue-600 rounded-md"
        >
          <div className="w-9 h-9 rounded-lg bg-blue-900 text-white flex items-center justify-center font-bold text-lg shadow-sm group-hover:bg-blue-800 transition-colors">
            B
          </div>
          <span className="text-lg font-bold tracking-tight text-blue-950 whitespace-nowrap">
            BCS Preparation <span className="text-teal-600 font-semibold">With Abrar</span>
          </span>
        </button>

        {/* Zone 2: 4-5 concise single-line text navigation links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => onNavigate('courses')}
            className={`whitespace-nowrap shrink-0 hover:text-blue-900 transition-colors ${
              currentView === 'courses' ? 'text-blue-900 font-semibold' : ''
            }`}
          >
            {isBn ? 'কোর্সসমূহ' : 'All Courses'}
          </button>
          <button
            onClick={() => onNavigate('subjects')}
            className={`whitespace-nowrap shrink-0 hover:text-blue-900 transition-colors ${
              currentView === 'subjects' ? 'text-blue-900 font-semibold' : ''
            }`}
          >
            {isBn ? 'সিলেবাস ও বিষয়' : 'Subjects'}
          </button>
          <button
            onClick={() => onNavigate('free-demo')}
            className={`whitespace-nowrap shrink-0 hover:text-blue-900 transition-colors ${
              currentView === 'free-demo' ? 'text-blue-900 font-semibold' : ''
            }`}
          >
            {isBn ? 'ফ্রি ডেমো ক্লাস' : 'Free Demo'}
          </button>
          <button
            onClick={() => onNavigate('pricing')}
            className={`whitespace-nowrap shrink-0 hover:text-blue-900 transition-colors ${
              currentView === 'pricing' ? 'text-blue-900 font-semibold' : ''
            }`}
          >
            {isBn ? 'কোর্স ফি' : 'Pricing'}
          </button>
          <button
            onClick={() => onNavigate('contact')}
            className={`whitespace-nowrap shrink-0 hover:text-blue-900 transition-colors ${
              currentView === 'contact' ? 'text-blue-900 font-semibold' : ''
            }`}
          >
            {isBn ? 'যোগাযোগ' : 'Contact'}
          </button>
        </nav>

        {/* Zone 3: Primary Action & User Switching */}
        <div className="flex items-center gap-3 shrink-0">
          {/* Language Switcher */}
          <button
            onClick={() => onLanguageChange(isBn ? 'en' : 'bn')}
            className="flex items-center gap-1.5 px-2.5 py-1 text-xs font-medium text-slate-600 hover:text-blue-950 rounded border border-slate-200 hover:border-slate-300 transition-colors whitespace-nowrap shrink-0"
            title="Switch Language"
          >
            <Globe className="w-3.5 h-3.5" />
            <span>{isBn ? 'EN' : 'বাং'}</span>
          </button>

          {/* User Profile / Portal / Admin Button */}
          {currentUser.role === 'super_admin' ? (
            <button
              onClick={() => onNavigate(currentView === 'admin' ? 'home' : 'admin')}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-blue-900 hover:bg-blue-800 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0"
            >
              <Shield className="w-3.5 h-3.5" />
              <span>{currentView === 'admin' ? (isBn ? 'ওয়েবসাইটে ফিরুন' : 'View Site') : (isBn ? 'অ্যাডমিন প্যানেল' : 'Admin Panel')}</span>
            </button>
          ) : (
            <button
              onClick={() => onNavigate(currentUser.role === 'guest' ? 'login' : 'dashboard')}
              className="flex items-center gap-1.5 px-3.5 py-2 text-xs font-semibold text-white bg-teal-600 hover:bg-teal-700 rounded-lg shadow-sm transition-colors whitespace-nowrap shrink-0"
            >
              <User className="w-3.5 h-3.5" />
              <span>{currentUser.role === 'guest' ? (isBn ? 'লগইন / ভর্তি' : 'Login / Register') : (isBn ? 'আমার ড্যাশবোর্ড' : 'Dashboard')}</span>
            </button>
          )}

          {/* Role Switcher Dropdown (for testing all 4 roles as required) */}
          <div className="relative">
            <button
              onClick={() => setUserMenuOpen(!userMenuOpen)}
              className="p-1.5 text-slate-500 hover:text-slate-800 hover:bg-slate-100 rounded-lg transition-colors flex items-center gap-1"
              title="Switch user role or test accounts"
            >
              <span className="text-[11px] font-mono text-slate-500 hidden lg:inline max-w-[90px] truncate">
                {currentUser.fullName.split(' ')[0]}
              </span>
              <ChevronDown className="w-3.5 h-3.5" />
            </button>

            {userMenuOpen && (
              <div className="absolute right-0 mt-2 w-64 bg-white rounded-lg shadow-lg border border-slate-200 py-2 z-50 text-xs">
                <div className="px-3 py-1.5 border-b border-slate-100">
                  <p className="font-semibold text-slate-800">{currentUser.fullName}</p>
                  <p className="text-[11px] text-slate-500 truncate">{currentUser.email}</p>
                  <div className="mt-1 flex items-center gap-1.5">
                    <span className="inline-block px-1.5 py-0.5 rounded text-[10px] font-semibold uppercase bg-slate-100 text-slate-700">
                      Role: {currentUser.role}
                    </span>
                    <span className="inline-block px-1.5 py-0.5 rounded text-[10px] bg-emerald-50 text-emerald-700">
                      {currentUser.status}
                    </span>
                  </div>
                </div>

                <div className="py-1">
                  <p className="px-3 py-1 text-[10px] font-semibold text-slate-400 uppercase tracking-wider">
                    {isBn ? 'টেস্ট রোল পরিবর্তন করুন:' : 'Switch Active Profile:'}
                  </p>
                  {profiles.map(p => (
                    <button
                      key={p.id}
                      onClick={() => {
                        DatabaseService.setCurrentUser(p.id);
                        setUserMenuOpen(false);
                      }}
                      className={`w-full text-left px-3 py-1.5 hover:bg-slate-50 flex items-center justify-between ${
                        p.id === currentUser.id ? 'bg-blue-50/70 text-blue-900 font-medium' : 'text-slate-700'
                      }`}
                    >
                      <div className="truncate pr-2">
                        <div className="truncate">{p.fullName}</div>
                        <div className="text-[10px] text-slate-400 capitalize">{p.role.replace('_', ' ')}</div>
                      </div>
                      {p.id === currentUser.id && (
                        <span className="text-[10px] text-blue-700 font-semibold">Active</span>
                      )}
                    </button>
                  ))}

                  {/* Guest mode */}
                  <button
                    onClick={() => {
                      DatabaseService.setCurrentUser('guest_user');
                      setUserMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 hover:bg-slate-50 text-slate-600 flex items-center gap-2"
                  >
                    <span>Browse as Guest (লগআউট)</span>
                  </button>
                </div>

                <div className="border-t border-slate-100 pt-1 mt-1">
                  <button
                    onClick={() => {
                      onNavigate('admin');
                      setUserMenuOpen(false);
                    }}
                    className="w-full text-left px-3 py-1.5 text-blue-800 hover:bg-blue-50 font-medium flex items-center gap-1.5"
                  >
                    <Shield className="w-3.5 h-3.5" />
                    <span>Open Admin Panel</span>
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};
