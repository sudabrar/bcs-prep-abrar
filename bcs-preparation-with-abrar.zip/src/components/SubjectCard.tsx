import React from 'react';
import { BookMarked, ChevronRight, Layers } from 'lucide-react';
import { Subject } from '../types';

interface SubjectCardProps {
  subject: Subject;
  onClick: (subjectId: string) => void;
}

export const SubjectCard: React.FC<SubjectCardProps> = ({ subject, onClick }) => {
  return (
    <div
      onClick={() => onClick(subject.id)}
      className="bg-white rounded-xl border border-slate-200 p-5 hover:border-blue-900/40 hover:shadow-md transition-all cursor-pointer flex flex-col justify-between group"
    >
      <div>
        {/* Unboxed Metadata line with clean separators */}
        <div className="flex items-center gap-2 text-xs text-slate-500 mb-2">
          <span className="font-mono font-medium text-blue-900">{subject.code}</span>
          <span aria-hidden="true">·</span>
          <span className="capitalize">{subject.examType === 'both' ? 'প্রিলি ও লিখিত' : subject.examType}</span>
          <span aria-hidden="true">·</span>
          <span className="font-mono tabular-nums">{subject.totalLectures || 0} লেকচার</span>
        </div>

        <h3 className="text-base font-bold text-slate-900 group-hover:text-blue-900 transition-colors mb-1.5">
          {subject.titleBn}
        </h3>
        <p className="text-xs text-slate-500 font-medium mb-2">
          {subject.titleEn}
        </p>

        <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
          {subject.description}
        </p>
      </div>

      <div className="pt-4 mt-4 border-t border-slate-100 flex items-center justify-between text-xs font-semibold text-blue-900 group-hover:text-teal-700 transition-colors">
        <span className="flex items-center gap-1.5">
          <Layers className="w-3.5 h-3.5 text-teal-600" />
          <span>অধ্যায় ও টপিক দেখুন</span>
        </span>
        <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
      </div>
    </div>
  );
};
