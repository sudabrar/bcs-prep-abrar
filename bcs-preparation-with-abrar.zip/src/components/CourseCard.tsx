import React from 'react';
import { BookOpen, Check, MessageCircle, ArrowRight } from 'lucide-react';
import { Course } from '../types';

interface CourseCardProps {
  course: Course;
  onViewDetails: (courseId: string) => void;
  onWhatsAppBuy: (course: Course) => void;
  isEnrolled?: boolean;
}

export const CourseCard: React.FC<CourseCardProps> = ({
  course,
  onViewDetails,
  onWhatsAppBuy,
  isEnrolled
}) => {
  const currentPrice = course.promotionalPriceBdt || course.regularPriceBdt;
  const hasDiscount = Boolean(course.promotionalPriceBdt && course.promotionalPriceBdt < course.regularPriceBdt);

  return (
    <div className="bg-white rounded-xl border border-slate-200 shadow-xs hover:shadow-md transition-shadow duration-200 flex flex-col overflow-hidden group">
      {/* Thumbnail */}
      <div 
        onClick={() => onViewDetails(course.id)}
        className="relative aspect-16/9 overflow-hidden bg-slate-100 cursor-pointer"
      >
        <img
          src={course.thumbnailUrl}
          alt={course.titleBn}
          referrerPolicy="no-referrer"
          className="w-full h-full object-cover group-hover:scale-102 transition-transform duration-300"
          onError={(e) => {
            (e.target as HTMLElement).style.display = 'none';
          }}
        />
        <div className="absolute top-3 left-3 bg-slate-900/85 backdrop-blur-xs text-white text-[11px] font-medium px-2.5 py-1 rounded">
          {course.category === 'complete' ? 'প্রিলি + লিখিত পূর্ণাঙ্গ' : course.category === 'preliminary' ? 'প্রিলিমিনারি স্পেশাল' : 'বিষয়ভিত্তিক কোর্স'}
        </div>
      </div>

      {/* Content */}
      <div className="p-5 flex-1 flex flex-col justify-between">
        <div className="space-y-2.5">
          <div className="flex items-center gap-2 text-xs text-slate-500">
            <span className="capitalize">{course.category.replace('_', ' ')}</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{course.durationWeeks} সপ্তাহ মেয়াদ</span>
            <span aria-hidden="true">·</span>
            <span className="font-mono tabular-nums">{course.accessDays} দিন অ্যাক্সেস</span>
          </div>

          <h3 
            onClick={() => onViewDetails(course.id)}
            className="text-base font-bold text-slate-900 group-hover:text-blue-900 transition-colors cursor-pointer line-clamp-2 leading-snug"
          >
            {course.titleBn}
          </h3>

          <p className="text-xs text-slate-600 line-clamp-2 leading-relaxed">
            {course.description}
          </p>

          {course.features && course.features.length > 0 && (
            <ul className="space-y-1.5 pt-1 text-xs text-slate-600">
              {course.features.slice(0, 3).map((f, i) => (
                <li key={i} className="flex items-start gap-1.5">
                  <Check className="w-3.5 h-3.5 text-teal-600 shrink-0 mt-0.5" />
                  <span className="truncate">{f}</span>
                </li>
              ))}
            </ul>
          )}
        </div>

        {/* Pricing & CTA */}
        <div className="pt-5 mt-4 border-t border-slate-100 space-y-3">
          <div className="flex items-baseline justify-between">
            <span className="text-xs text-slate-500 font-medium">কোর্স ফি:</span>
            <div className="flex items-baseline gap-2">
              {hasDiscount && (
                <span className="text-xs text-slate-400 line-through font-mono tabular-nums">
                  ৳{course.regularPriceBdt.toLocaleString()}
                </span>
              )}
              <span className="text-xl font-bold text-blue-950 font-mono tabular-nums">
                ৳{currentPrice.toLocaleString()}
              </span>
            </div>
          </div>

          {isEnrolled ? (
            <button
              onClick={() => onViewDetails(course.id)}
              className="w-full py-2.5 px-4 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap"
            >
              <BookOpen className="w-4 h-4" />
              <span>ক্লাস শুরু করুন (ভর্তি সম্পন্ন)</span>
            </button>
          ) : (
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={() => onWhatsAppBuy(course)}
                className="py-2.5 px-3 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap shadow-xs"
                title="Enroll via WhatsApp"
              >
                <MessageCircle className="w-3.5 h-3.5" />
                <span>হোয়াটসঅ্যাপে কিনুন</span>
              </button>

              <button
                onClick={() => onViewDetails(course.id)}
                className="py-2.5 px-3 bg-slate-900 hover:bg-slate-800 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-1.5 transition-colors whitespace-nowrap shadow-xs"
                title="View Course Details"
              >
                <span>বিস্তারিত দেখুন</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
