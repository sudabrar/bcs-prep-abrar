import React from 'react';
import { Phone, Mail, MapPin, ExternalLink, ShieldCheck, HelpCircle } from 'lucide-react';
import { DatabaseService } from '../services/db';

interface FooterProps {
  onNavigate: (view: string) => void;
  language: 'bn' | 'en';
}

export const Footer: React.FC<FooterProps> = ({ onNavigate, language }) => {
  const settings = DatabaseService.getSettings();
  const isBn = language === 'bn';

  return (
    <footer className="bg-slate-900 text-slate-300 pt-16 pb-12 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10 pb-12 border-b border-slate-800">
          {/* Brand & Mission */}
          <div className="space-y-4">
            <div className="flex items-center gap-2.5">
              <div className="w-8 h-8 rounded-lg bg-teal-500 text-slate-950 flex items-center justify-center font-bold text-base">
                B
              </div>
              <span className="text-lg font-bold tracking-tight text-white">
                BCS Preparation <span className="text-teal-400">With Abrar</span>
              </span>
            </div>
            <p className="text-xs text-slate-400 leading-relaxed">
              {isBn
                ? '৪৭তম ও ৪৮তম বিসিএস প্রিলিমিনারি ও লিখিত পরীক্ষার সুশৃঙ্খল পাঠদান, সমৃদ্ধ ক্লাস নোট এবং অভিজ্ঞ শিক্ষক আবরারের সরাসরি দিকনির্দেশনা।'
                : 'Structured lecture delivery, comprehensive class notes, and expert guidance by Abrar for Bangladesh Civil Service preliminary and written examinations.'}
            </p>
            <div className="pt-2 text-xs text-slate-400 flex items-center gap-2">
              <span className="text-teal-400 font-semibold">মালিক ও শিক্ষক:</span>
              <span>আবরার (Abrar)</span>
            </div>
          </div>

          {/* Quick Links */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
              {isBn ? 'গুরুত্বপূর্ণ লিংক' : 'Quick Navigation'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('courses')} className="hover:text-teal-300 transition-colors">
                  {isBn ? 'সকল বিসিএস কোর্স' : 'All Courses'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('subjects')} className="hover:text-teal-300 transition-colors">
                  {isBn ? 'বিষয়ভিত্তিক সিলেবাস' : 'Subject Syllabus'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('free-demo')} className="hover:text-teal-300 transition-colors">
                  {isBn ? 'ফ্রি ডেমো লেকচার' : 'Free Demo Lectures'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('pricing')} className="hover:text-teal-300 transition-colors">
                  {isBn ? 'ফি ও ভর্তির নিয়ম' : 'Course Fees & Enrollment'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('contact')} className="hover:text-teal-300 transition-colors">
                  {isBn ? 'যোগাযোগ ও সাপোর্ট' : 'Contact & Support'}
                </button>
              </li>
            </ul>
          </div>

          {/* Verification & Legal */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
              {isBn ? 'নীতিমালা ও শর্তাবলী' : 'Policies & Terms'}
            </h4>
            <ul className="space-y-2 text-xs">
              <li>
                <button onClick={() => onNavigate('terms')} className="hover:text-teal-300 transition-colors">
                  {isBn ? 'ব্যবহারের শর্তাবলী' : 'Terms & Conditions'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('privacy')} className="hover:text-teal-300 transition-colors">
                  {isBn ? 'গোপনীয়তা নীতি' : 'Privacy Policy'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('login')} className="hover:text-teal-300 transition-colors">
                  {isBn ? 'শিক্ষার্থী লগইন' : 'Student Login'}
                </button>
              </li>
              <li>
                <button onClick={() => onNavigate('admin')} className="text-slate-400 hover:text-white transition-colors flex items-center gap-1">
                  <ShieldCheck className="w-3.5 h-3.5 text-teal-400" />
                  <span>{isBn ? 'অ্যাডমিন পোর্টাল' : 'Admin Portal'}</span>
                </button>
              </li>
            </ul>
          </div>

          {/* Official Contact & WhatsApp */}
          <div className="space-y-3">
            <h4 className="text-xs font-semibold text-white uppercase tracking-wider">
              {isBn ? 'অফিসিয়াল যোগাযোগ' : 'Official Contact'}
            </h4>
            <div className="space-y-2.5 text-xs text-slate-300">
              <a 
                href={`https://wa.me/${settings.phoneIntl}`} 
                target="_blank" 
                rel="noreferrer"
                className="flex items-center gap-2 hover:text-teal-300 transition-colors"
              >
                <Phone className="w-4 h-4 text-emerald-400 shrink-0" />
                <span>
                  হোয়াটসঅ্যাপ: <span className="font-mono font-semibold text-white">{settings.phoneLocal}</span>
                </span>
              </a>
              <div className="flex items-center gap-2">
                <Mail className="w-4 h-4 text-teal-400 shrink-0" />
                <span className="truncate">{settings.emailContact}</span>
              </div>
              <div className="flex items-start gap-2">
                <MapPin className="w-4 h-4 text-teal-400 shrink-0 mt-0.5" />
                <span>ঢাকা, বাংলাদেশ (অনলাইন ক্লাস ও মেন্টরিং)</span>
              </div>
            </div>

            <div className="pt-2">
              <a
                href={`https://wa.me/${settings.phoneIntl}?text=${encodeURIComponent('Assalamu Alaikum Abrar Sir. I would like to know about BCS course admission.')}`}
                target="_blank"
                rel="noreferrer"
                className="inline-flex items-center gap-2 px-3.5 py-2 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold transition-colors shadow-sm"
              >
                <span>হোয়াটসঅ্যাপে সরাসরি চ্যাট করুন</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>
          </div>
        </div>

        {/* Disclaimer & Copyright */}
        <div className="pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-xs text-slate-500">
          <p className="text-center md:text-left">
            © {new Date().getFullYear()} BCS Preparation With Abrar. সর্বস্বত্ব সংরক্ষিত। 
            <span className="block sm:inline sm:ml-2 text-slate-400">
              বাংলাদেশ সরকারি কর্ম কমিশন (BPSC) এর নির্ধারিত সিলেবাস অনুযায়ী একাডেমিক সহায়তা প্রদান করা হয়।
            </span>
          </p>
          <div className="flex items-center gap-4 text-slate-400">
            <span className="font-mono">BDT (৳) Currency</span>
            <span>·</span>
            <span>bKash / Nagad / Bank</span>
          </div>
        </div>
      </div>
    </footer>
  );
};
