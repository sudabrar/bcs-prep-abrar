import React, { useState } from 'react';
import { X, Send, CheckCircle, AlertCircle } from 'lucide-react';
import { Course, UserProfile } from '../types';
import { DatabaseService } from '../services/db';

interface AccessRequestModalProps {
  course: Course;
  currentUser: UserProfile;
  isOpen: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export const AccessRequestModal: React.FC<AccessRequestModalProps> = ({
  course,
  currentUser,
  isOpen,
  onClose,
  onSuccess
}) => {
  const [phone, setPhone] = useState(currentUser.phone || '');
  const [message, setMessage] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState('');

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (!phone.trim()) {
      setError('Please provide a valid phone number.');
      return;
    }

    setIsSubmitting(true);
    try {
      DatabaseService.createAccessRequest({
        userId: currentUser.id,
        userEmail: currentUser.email,
        userName: currentUser.fullName,
        userPhone: phone.trim(),
        courseId: course.id,
        courseTitle: course.titleBn,
        message: message.trim() || undefined
      });

      setIsSubmitting(false);
      setSubmitted(true);
      setTimeout(() => {
        onSuccess();
        onClose();
      }, 2000);
    } catch (err: unknown) {
      setIsSubmitting(false);
      setError((err as Error).message || 'Failed to submit access request.');
    }
  };

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden border border-slate-200">
        <div className="px-5 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <h3 className="text-sm font-bold">কোর্স অ্যাক্সেস রিকোয়েস্ট</h3>
            <p className="text-xs text-slate-300 truncate">{course.titleBn}</p>
          </div>
          <button onClick={onClose} className="p-1 text-slate-400 hover:text-white">
            <X className="w-4 h-4" />
          </button>
        </div>

        <div className="p-5">
          {submitted ? (
            <div className="text-center py-6 space-y-2">
              <CheckCircle className="w-10 h-10 text-emerald-600 mx-auto" />
              <h4 className="text-sm font-bold text-slate-900">রিকোয়েস্ট জমা হয়েছে</h4>
              <p className="text-xs text-slate-600">
                এডমিন প্যানেলে আপনার আবেদনটি পর্যালোচনায় রয়েছে। অনুমোদন পাওয়ার সাথে সাথে ড্যাশবোর্ডে কোর্সটি দেখতে পাবেন।
              </p>
            </div>
          ) : (
            <form onSubmit={handleSubmit} className="space-y-4">
              <p className="text-xs text-slate-600">
                আপনি যদি ইতিমধ্যে অফলাইন বা ভিন্ন কোনো মাধ্যমে কোর্স ফি পরিশোধ করে থাকেন অথবা বিশেষ স্কলারশিপের আওতায় ভর্তি হতে চান, তবে তথ্য দিন:
              </p>

              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">শিক্ষার্থীর নাম</label>
                <input
                  type="text"
                  value={currentUser.fullName}
                  disabled
                  className="w-full text-xs px-3 py-2 bg-slate-100 border border-slate-200 rounded text-slate-600"
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">যোগাযোগের মোবাইল নম্বর</label>
                <input
                  type="text"
                  placeholder="017XXXXXXXX"
                  value={phone}
                  onChange={e => setPhone(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-blue-600 font-mono"
                  required
                />
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">আবেদনের কারণ বা বার্তা (ঐচ্ছিক)</label>
                <textarea
                  rows={3}
                  placeholder="যেমন: আমি ব্যাংকের মাধ্যমে টাকা পাঠিয়েছি / আমার রেফারেন্স নম্বর..."
                  value={message}
                  onChange={e => setMessage(e.target.value)}
                  className="w-full text-xs px-3 py-2 border border-slate-300 rounded focus:ring-1 focus:ring-blue-600"
                />
              </div>

              {error && (
                <div className="flex items-center gap-1.5 text-xs text-rose-600">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{error}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 bg-blue-900 hover:bg-blue-800 disabled:bg-slate-400 text-white text-xs font-semibold rounded-lg flex items-center justify-center gap-2 transition-colors"
              >
                <Send className="w-3.5 h-3.5" />
                <span>{isSubmitting ? 'জমা হচ্ছে...' : 'রিকোয়েস্ট সাবমিট করুন'}</span>
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
