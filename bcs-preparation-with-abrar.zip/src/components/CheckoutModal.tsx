import React, { useState } from 'react';
import { X, CheckCircle, ExternalLink, Phone, MessageCircle, AlertCircle } from 'lucide-react';
import { Course, UserProfile } from '../types';
import { DatabaseService } from '../services/db';

interface CheckoutModalProps {
  course: Course;
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onSuccess: () => void;
}

export const CheckoutModal: React.FC<CheckoutModalProps> = ({
  course,
  isOpen,
  onClose,
  currentUser,
  onSuccess
}) => {
  const [couponCode, setCouponCode] = useState('');
  const [couponResult, setCouponResult] = useState<{ discount: number; finalPrice: number; message?: string } | null>(null);
  
  // Manual payment submission state
  const [senderPhone, setSenderPhone] = useState(currentUser.phone || '');
  const [transactionRef, setTransactionRef] = useState('');
  const [manualMethod, setManualMethod] = useState<'bkash' | 'nagad' | 'rocket' | 'whatsapp_manual'>('bkash');
  const [manualSubmitted, setManualSubmitted] = useState(false);
  const [manualError, setManualError] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const settings = DatabaseService.getSettings();
  const currentPrice = course.promotionalPriceBdt || course.regularPriceBdt;
  const effectivePrice = couponResult ? couponResult.finalPrice : currentPrice;

  if (!isOpen) return null;

  const handleApplyCoupon = (e: React.FormEvent) => {
    e.preventDefault();
    if (!couponCode.trim()) return;
    const res = DatabaseService.validateCoupon(couponCode, course.id, currentPrice);
    if (res.valid) {
      setCouponResult({ discount: res.discountAmount, finalPrice: res.finalPrice, message: res.message });
    } else {
      setCouponResult({ discount: 0, finalPrice: currentPrice, message: res.message });
    }
  };

  // Pre-filled WhatsApp message as specified in master prompt
  const prefilledMessage = settings.whatsappMessageTemplate
    .replace('{course_title}', course.titleBn)
    .replace('{course_id}', course.id);

  const whatsappUrl = `https://wa.me/${settings.phoneIntl}?text=${encodeURIComponent(
    `${prefilledMessage}\n\nStudent Name: ${currentUser.fullName}\nPhone: ${currentUser.phone || 'N/A'}`
  )}`;

  const handleWhatsAppClick = () => {
    // Record WhatsApp Inquiry lead in database
    DatabaseService.createInquiry({
      courseId: course.id,
      courseTitle: course.titleBn,
      contactName: currentUser.fullName,
      contactPhone: currentUser.phone || 'N/A',
      userEmail: currentUser.email,
      message: prefilledMessage,
      userId: currentUser.id
    });
    window.open(whatsappUrl, '_blank', 'noopener,noreferrer');
  };

  const handleManualPaymentSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setManualError('');
    if (!transactionRef.trim()) {
      setManualError('অনুগ্রহ করে ট্রানজেকশন আইডি (TrxID) লিখুন।');
      return;
    }
    if (!senderPhone.trim()) {
      setManualError('যে নম্বর থেকে টাকা পাঠিয়েছেন সেই bKash/Nagad নম্বরটি লিখুন।');
      return;
    }

    setIsSubmitting(true);
    try {
      DatabaseService.recordPayment({
        userId: currentUser.id,
        userEmail: currentUser.email,
        courseId: course.id,
        courseTitle: course.titleBn,
        amountBdt: effectivePrice,
        paymentMethod: manualMethod,
        transactionRef: transactionRef.trim(),
        senderPhone: senderPhone.trim(),
        verificationStatus: 'pending',
        adminNotes: `Manual payment submitted via website. Method: ${manualMethod.toUpperCase()}, Sender: ${senderPhone}`
      });

      // Also create an access request so admin can approve directly
      DatabaseService.createAccessRequest({
        userId: currentUser.id,
        userEmail: currentUser.email,
        userName: currentUser.fullName,
        userPhone: senderPhone,
        courseId: course.id,
        courseTitle: course.titleBn,
        message: `TrxID: ${transactionRef.trim()} (${manualMethod.toUpperCase()})`
      });

      setIsSubmitting(false);
      setManualSubmitted(true);
      setTimeout(() => {
        onSuccess();
      }, 2500);
    } catch (err: unknown) {
      setIsSubmitting(false);
      setManualError((err as Error).message || 'পেমেন্ট জমা দিতে সমস্যা হয়েছে।');
    }
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full overflow-hidden border border-slate-200 animate-in fade-in zoom-in-95 duration-150">
        {/* Header */}
        <div className="px-6 py-4 bg-slate-900 text-white flex items-center justify-between">
          <div>
            <h3 className="text-base font-bold text-white">কোর্স ভর্তি ও পেমেন্ট (bKash / Nagad)</h3>
            <p className="text-xs text-slate-300 truncate max-w-xs">{course.titleBn}</p>
          </div>
          <button onClick={onClose} className="p-1 rounded text-slate-400 hover:text-white transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Price & Summary */}
        <div className="p-6 pb-4 border-b border-slate-100 bg-slate-50/70">
          <div className="flex items-baseline justify-between">
            <span className="text-xs font-medium text-slate-600">কোর্স ফি:</span>
            <div className="flex items-baseline gap-2">
              {course.promotionalPriceBdt && (
                <span className="text-xs text-slate-400 line-through font-mono">
                  ৳{course.regularPriceBdt.toLocaleString()}
                </span>
              )}
              <span className="text-2xl font-bold text-blue-950 font-mono">
                ৳{effectivePrice.toLocaleString()} BDT
              </span>
            </div>
          </div>

          {/* Coupon Input */}
          <form onSubmit={handleApplyCoupon} className="mt-3 flex gap-2">
            <div className="relative flex-1">
              <input
                type="text"
                placeholder="কুপন কোড (যেমন: BCS2026)"
                value={couponCode}
                onChange={e => setCouponCode(e.target.value.toUpperCase())}
                className="w-full px-3 py-1.5 text-xs rounded border border-slate-300 focus:outline-none focus:ring-1 focus:ring-blue-600 uppercase font-mono"
              />
            </div>
            <button
              type="submit"
              className="px-3 py-1.5 text-xs font-semibold bg-slate-800 text-white hover:bg-slate-700 rounded transition-colors whitespace-nowrap"
            >
              প্রয়োগ
            </button>
          </form>

          {couponResult && (
            <p className={`mt-1.5 text-xs ${couponResult.discount > 0 ? 'text-emerald-700 font-medium' : 'text-rose-600'}`}>
              {couponResult.message}
            </p>
          )}
        </div>

        {/* Content area */}
        <div className="p-6 space-y-4">
          <div className="text-xs text-slate-600 space-y-2">
            <p>
              <strong>ধাপ ১:</strong> নিচের বোতামে ক্লিক করে সরাসরি আবরার স্যারের অফিসিয়াল হোয়াটসঅ্যাপে মেসেজ দিন:
            </p>
            <div className="p-2.5 rounded bg-emerald-50 border border-emerald-200 text-emerald-950 font-mono text-[11px] leading-relaxed break-words">
              {prefilledMessage}
            </div>
          </div>

          <button
            type="button"
            onClick={handleWhatsAppClick}
            className="w-full py-2.5 px-4 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold flex items-center justify-center gap-2 shadow-sm transition-colors"
          >
            <MessageCircle className="w-4 h-4" />
            <span>হোয়াটসঅ্যাপে যোগাযোগ করুন ({settings.phoneLocal})</span>
            <ExternalLink className="w-3.5 h-3.5 ml-auto" />
          </button>

          <div className="relative my-3">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-slate-200"></div>
            </div>
            <div className="relative flex justify-center text-xs">
              <span className="px-2 bg-white text-slate-500 font-medium">
                ধাপ ২: ফি পাঠিয়ে TrxID সাবমিট করুন
              </span>
            </div>
          </div>

          {/* Payment instructions */}
          <div className="p-3 rounded bg-slate-100 border border-slate-200 text-xs text-slate-700 space-y-1">
            <p className="font-semibold text-slate-900">অফিসিয়াল পেমেন্ট নম্বর:</p>
            <p>
              • bKash Personal / Merchant: <span className="font-mono font-bold text-slate-900">{settings.bkashMerchantNumber}</span> (Send Money / Payment)
            </p>
            <p>
              • Nagad: <span className="font-mono font-bold text-slate-900">{settings.nagadMerchantNumber}</span> (Send Money)
            </p>
            {settings.bankAccountDetails && (
              <p className="text-[11px] text-slate-500 pt-1 border-t border-slate-200">
                {settings.bankAccountDetails}
              </p>
            )}
          </div>

          {manualSubmitted ? (
            <div className="p-4 bg-emerald-50 border border-emerald-200 rounded-lg text-center space-y-1">
              <CheckCircle className="w-7 h-7 text-emerald-600 mx-auto" />
              <p className="text-xs font-bold text-emerald-900">পেমেন্ট বিবরণী সফলভাবে জমা হয়েছে!</p>
              <p className="text-[11px] text-emerald-700">
                এডমিন প্যানেলে TrxID যাচাই করার সাথে সাথে আপনার একাউন্টে কোর্সটি অ্যাক্টিভ হয়ে যাবে।
              </p>
            </div>
          ) : (
            <form onSubmit={handleManualPaymentSubmit} className="space-y-3">
              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">পেমেন্ট মাধ্যম</label>
                  <select
                    value={manualMethod}
                    onChange={e => setManualMethod(e.target.value as any)}
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-600"
                  >
                    <option value="bkash">bKash</option>
                    <option value="nagad">Nagad</option>
                    <option value="rocket">Rocket</option>
                    <option value="whatsapp_manual">Bank Transfer / অন্যান্য</option>
                  </select>
                </div>
                <div>
                  <label className="block text-[11px] font-medium text-slate-700 mb-1">প্রেরকের মোবাইল নম্বর</label>
                  <input
                    type="text"
                    placeholder="017XXXXXXXX"
                    value={senderPhone}
                    onChange={e => setSenderPhone(e.target.value)}
                    className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-600 font-mono"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-[11px] font-medium text-slate-700 mb-1">
                  ট্রানজেকশন আইডি (TrxID)
                </label>
                <input
                  type="text"
                  placeholder="যেমন: 9B7K2X44Q1"
                  value={transactionRef}
                  onChange={e => setTransactionRef(e.target.value)}
                  className="w-full text-xs px-2.5 py-1.5 border border-slate-300 rounded focus:ring-1 focus:ring-blue-600 font-mono uppercase"
                  required
                />
              </div>

              {manualError && (
                <div className="flex items-center gap-1.5 text-xs text-rose-600">
                  <AlertCircle className="w-3.5 h-3.5 shrink-0" />
                  <span>{manualError}</span>
                </div>
              )}

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full py-2.5 px-4 rounded bg-blue-900 hover:bg-blue-800 disabled:bg-slate-400 text-white text-xs font-semibold transition-colors"
              >
                {isSubmitting ? 'জমা হচ্ছে...' : 'পেমেন্ট ভেরিফিকেশনের জন্য পাঠান'}
              </button>
            </form>
          )}
        </div>
      </div>
    </div>
  );
};
