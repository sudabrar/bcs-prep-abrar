import React, { useState } from 'react';
import { 
  X, 
  CheckCircle, 
  Bookmark as BookmarkIcon, 
  FileText, 
  ExternalLink, 
  Lock, 
  Play, 
  HelpCircle,
  Share2,
  Clock,
  BookOpen
} from 'lucide-react';
import { Lecture, UserProfile } from '../types';
import { DatabaseService } from '../services/db';

interface LecturePlayerModalProps {
  lecture: Lecture | null;
  isOpen: boolean;
  onClose: () => void;
  currentUser: UserProfile;
  onEnrollClick?: (courseId: string) => void;
}

export const LecturePlayerModal: React.FC<LecturePlayerModalProps> = ({
  lecture,
  isOpen,
  onClose,
  currentUser,
  onEnrollClick
}) => {
  const [activeTab, setActiveTab] = useState<'video' | 'notes'>('video');
  const [copiedLink, setCopiedLink] = useState(false);

  if (!isOpen || !lecture) return null;

  // Check access permissions
  const accessCheck = DatabaseService.canUserAccessLecture(lecture, currentUser);
  const isAllowed = accessCheck.allowed;

  // Student progress
  const progressList = DatabaseService.getProgress(currentUser.id);
  const isCompleted = progressList.some(p => p.lectureId === lecture.id && p.isCompleted);

  // Bookmarks
  const bookmarks = DatabaseService.getBookmarks(currentUser.id);
  const isBookmarked = bookmarks.some(b => b.lectureId === lecture.id);

  // Extract YouTube ID safely
  const getYouTubeEmbedUrl = (url: string) => {
    if (!url) return '';
    try {
      const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
      const match = url.match(regExp);
      const videoId = match && match[2].length === 11 ? match[2] : null;
      if (videoId) {
        return `https://www.youtube-nocookie.com/embed/${videoId}?autoplay=1&rel=0`;
      }
      return url;
    } catch {
      return url;
    }
  };

  const handleToggleCompleted = () => {
    DatabaseService.toggleLectureCompleted(currentUser.id, lecture.id);
  };

  const handleToggleBookmark = () => {
    DatabaseService.toggleBookmark(currentUser.id, lecture.id);
  };

  const handleShare = () => {
    navigator.clipboard.writeText(window.location.href);
    setCopiedLink(true);
    setTimeout(() => setCopiedLink(false), 2000);
  };

  // Convert Google Drive view URL to preview embed URL if possible
  const getDriveEmbedUrl = (url: string) => {
    if (!url) return '';
    if (url.includes('drive.google.com') && url.includes('/view')) {
      return url.replace('/view', '/preview');
    }
    return url;
  };

  return (
    <div className="fixed inset-0 z-50 overflow-y-auto bg-slate-950/80 backdrop-blur-xs flex items-center justify-center p-2 sm:p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-4xl w-full overflow-hidden border border-slate-200 flex flex-col max-h-[92vh]">
        {/* Top Header */}
        <div className="px-5 py-3.5 bg-slate-900 text-white flex items-center justify-between shrink-0">
          <div className="flex items-center gap-2.5 truncate pr-4">
            <span className="w-6 h-6 rounded bg-teal-500 text-slate-950 font-bold text-xs flex items-center justify-center shrink-0">
              {lecture.lectureNumber}
            </span>
            <div className="truncate">
              <h3 className="text-sm font-bold text-white truncate">{lecture.titleBn}</h3>
              <p className="text-[11px] text-slate-400 truncate">{lecture.titleEn}</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-1 rounded text-slate-400 hover:text-white transition-colors shrink-0"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Access Check: Allowed vs Locked */}
        {isAllowed ? (
          <>
            {/* Viewport Stage: Video vs Drive Notes */}
            <div className="bg-black relative aspect-video w-full shrink-0 flex items-center justify-center">
              {activeTab === 'video' ? (
                <iframe
                  src={getYouTubeEmbedUrl(lecture.youtubeUrl)}
                  title={lecture.titleBn}
                  className="w-full h-full border-0"
                  allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
                  allowFullScreen
                />
              ) : (
                <div className="w-full h-full bg-slate-900 flex flex-col items-center justify-center p-6 text-center text-white">
                  <FileText className="w-12 h-12 text-teal-400 mb-3" />
                  <h4 className="text-sm font-semibold mb-1">গুগল ড্রাইভ ক্লাস নোট ও হ্যান্ডআউট</h4>
                  <p className="text-xs text-slate-400 max-w-md mb-4">
                    লেকচারের বিস্তারিত পিডিএফ হ্যান্ডনোট, বিগত বছরের বিসিএস প্রশ্নের সমাধান ও হাইলাইটেড শিট।
                  </p>
                  <div className="flex items-center gap-3">
                    <a
                      href={lecture.driveNotesUrl || '#'}
                      target="_blank"
                      rel="noreferrer"
                      className="px-4 py-2 bg-teal-500 hover:bg-teal-400 text-slate-950 font-semibold text-xs rounded-lg flex items-center gap-2 transition-colors shadow-sm"
                    >
                      <span>গুগল ড্রাইভ ফোল্ডারে খুলুন</span>
                      <ExternalLink className="w-3.5 h-3.5" />
                    </a>
                    <button
                      onClick={() => setActiveTab('video')}
                      className="px-3.5 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs rounded-lg transition-colors"
                    >
                      ভিডিওতে ফিরুন
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Bottom Controls & Metadata */}
            <div className="p-5 overflow-y-auto space-y-4">
              {/* Action Toolbar */}
              <div className="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-slate-100">
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setActiveTab('video')}
                    className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                      activeTab === 'video'
                        ? 'bg-blue-900 text-white'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    <Play className="w-3 h-3" />
                    <span>ভিডিও লেকচার</span>
                  </button>

                  {lecture.driveNotesUrl && (
                    <button
                      onClick={() => setActiveTab('notes')}
                      className={`px-3 py-1.5 rounded text-xs font-semibold flex items-center gap-1.5 transition-colors ${
                        activeTab === 'notes'
                          ? 'bg-teal-700 text-white'
                          : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                      }`}
                    >
                      <FileText className="w-3 h-3 text-teal-600" />
                      <span>ক্লাস নোট (PDF)</span>
                    </button>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    onClick={handleToggleCompleted}
                    className={`px-3 py-1.5 rounded text-xs font-medium flex items-center gap-1.5 transition-colors ${
                      isCompleted
                        ? 'bg-emerald-100 text-emerald-800 border border-emerald-300'
                        : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
                    }`}
                  >
                    <CheckCircle className={`w-3.5 h-3.5 ${isCompleted ? 'text-emerald-600' : 'text-slate-400'}`} />
                    <span>{isCompleted ? 'সম্পন্ন হয়েছে' : 'পড়া শেষ হিসেবে চিহ্নিত করুন'}</span>
                  </button>

                  <button
                    onClick={handleToggleBookmark}
                    className={`p-1.5 rounded text-xs transition-colors ${
                      isBookmarked
                        ? 'bg-amber-100 text-amber-800 border border-amber-300'
                        : 'bg-slate-100 text-slate-600 hover:bg-slate-200'
                    }`}
                    title="Bookmark Lecture"
                  >
                    <BookmarkIcon className={`w-4 h-4 ${isBookmarked ? 'text-amber-600 fill-amber-600' : ''}`} />
                  </button>

                  <button
                    onClick={handleShare}
                    className="p-1.5 rounded bg-slate-100 text-slate-600 hover:bg-slate-200 transition-colors"
                    title="Share"
                  >
                    <Share2 className="w-4 h-4" />
                  </button>
                </div>
              </div>

              {/* Lecture Description & Teacher info */}
              <div className="space-y-3">
                <div className="flex flex-wrap items-center gap-3 text-xs text-slate-500">
                  <span className="flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5" />
                    <span className="font-mono">{lecture.durationMinutes} মিনিট</span>
                  </span>
                  <span>·</span>
                  <span>শিক্ষক: <strong className="text-slate-800">{lecture.teacherName}</strong></span>
                  <span>·</span>
                  <span className="capitalize text-slate-700">{lecture.examType} Exam</span>
                  {lecture.isFreePreview && (
                    <>
                      <span>·</span>
                      <span className="text-teal-700 font-semibold">ফ্রি ডেমো লেকচার</span>
                    </>
                  )}
                </div>

                <p className="text-xs text-slate-700 leading-relaxed whitespace-pre-line">
                  {lecture.description}
                </p>

                {/* Tags */}
                {lecture.tags && lecture.tags.length > 0 && (
                  <div className="flex flex-wrap items-center gap-1.5 pt-2 text-[11px] text-slate-500">
                    <span className="font-medium text-slate-600">টপিক:</span>
                    {lecture.tags.map((tag, idx) => (
                      <span key={idx} className="bg-slate-100 px-2 py-0.5 rounded text-slate-600">
                        #{tag}
                      </span>
                    ))}
                  </div>
                )}
              </div>
            </div>
          </>
        ) : (
          /* Locked State Gate */
          <div className="p-8 text-center space-y-5 my-auto">
            <div className="w-16 h-16 rounded-full bg-blue-50 text-blue-900 mx-auto flex items-center justify-center">
              <Lock className="w-8 h-8" />
            </div>

            <div className="max-w-md mx-auto space-y-2">
              <h3 className="text-base font-bold text-slate-900">এই লেকচারটি প্রিমিয়াম বিসিএস কোর্সের অন্তর্ভুক্ত</h3>
              <p className="text-xs text-slate-600 leading-relaxed">
                {accessCheck.reason || 'এই লেকচার ও ক্লাস নোট দেখতে অনুগ্রহ করে কোর্সে ভর্তি হোন অথবা আবরার স্যারের সাথে হোয়াটসঅ্যাপে যোগাযোগ করুন।'}
              </p>
            </div>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-3 pt-2">
              {lecture.courseIds && lecture.courseIds[0] && onEnrollClick && (
                <button
                  onClick={() => {
                    onClose();
                    onEnrollClick(lecture.courseIds[0]);
                  }}
                  className="w-full sm:w-auto px-5 py-2.5 bg-blue-900 hover:bg-blue-800 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors"
                >
                  কোর্সে ভর্তি ও ফি প্রদান (bKash / Nagad / WhatsApp)
                </button>
              )}

              <a
                href={`https://wa.me/${DatabaseService.getSettings().phoneIntl}?text=${encodeURIComponent(
                  `Assalamu Alaikum Abrar Sir. I want to access Lecture: ${lecture.titleBn} (Lecture ID: ${lecture.id}). Please guide me on enrollment.`
                )}`}
                target="_blank"
                rel="noreferrer"
                className="w-full sm:w-auto px-4 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white text-xs font-semibold rounded-lg shadow-sm transition-colors flex items-center justify-center gap-2"
              >
                <span>হোয়াটসঅ্যাপে অনুমতি চান</span>
                <ExternalLink className="w-3 h-3" />
              </a>
            </div>

            <p className="text-[11px] text-slate-400 max-w-sm mx-auto">
              নোট: আপনি যদি ইতিমধ্যে পেমেন্ট করে থাকেন, তবে এডমিন প্যানেল থেকে ভেরিফাই হওয়া পর্যন্ত অপেক্ষা করুন অথবা আপনার TrxID হোয়াটসঅ্যাপে পাঠান।
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
