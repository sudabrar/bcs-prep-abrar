-- ========================================================
-- BCS PREPARATION WITH ABRAR - SUPABASE SCHEMA & RLS RULES
-- ========================================================

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Profiles table
CREATE TABLE IF NOT EXISTS public.profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'student' CHECK (role IN ('super_admin', 'content_manager', 'student', 'guest')),
  status TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'approved', 'suspended', 'rejected')),
  district TEXT,
  target_bcs_cadre TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Subjects table
CREATE TABLE IF NOT EXISTS public.subjects (
  id TEXT PRIMARY KEY,
  title_bn TEXT NOT NULL,
  title_en TEXT NOT NULL,
  code TEXT NOT NULL UNIQUE,
  description TEXT,
  exam_type TEXT NOT NULL CHECK (exam_type IN ('preliminary', 'written', 'both')),
  order_index INTEGER DEFAULT 0,
  is_published BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Chapters table
CREATE TABLE IF NOT EXISTS public.chapters (
  id TEXT PRIMARY KEY,
  subject_id TEXT REFERENCES public.subjects(id) ON DELETE CASCADE,
  title_bn TEXT NOT NULL,
  title_en TEXT NOT NULL,
  order_index INTEGER DEFAULT 0,
  is_published BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Topics table
CREATE TABLE IF NOT EXISTS public.topics (
  id TEXT PRIMARY KEY,
  chapter_id TEXT REFERENCES public.chapters(id) ON DELETE CASCADE,
  title_bn TEXT NOT NULL,
  title_en TEXT NOT NULL,
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Lectures table
CREATE TABLE IF NOT EXISTS public.lectures (
  id TEXT PRIMARY KEY,
  subject_id TEXT REFERENCES public.subjects(id) ON DELETE CASCADE,
  chapter_id TEXT REFERENCES public.chapters(id) ON DELETE CASCADE,
  topic_id TEXT REFERENCES public.topics(id) ON DELETE SET NULL,
  course_ids TEXT[] DEFAULT '{}',
  batch_ids TEXT[] DEFAULT '{}',
  title_bn TEXT NOT NULL,
  title_en TEXT NOT NULL,
  exam_type TEXT NOT NULL CHECK (exam_type IN ('preliminary', 'written', 'both')),
  description TEXT,
  youtube_url TEXT NOT NULL,
  drive_notes_url TEXT,
  teacher_name TEXT DEFAULT 'Abrar',
  lecture_number INTEGER NOT NULL,
  duration_minutes INTEGER DEFAULT 45,
  tags TEXT[] DEFAULT '{}',
  is_free_preview BOOLEAN DEFAULT false,
  publication_status TEXT DEFAULT 'published' CHECK (publication_status IN ('published', 'draft', 'archived')),
  access_type TEXT DEFAULT 'enrolled_students' CHECK (access_type IN ('public', 'free_preview', 'approved_students', 'enrolled_students', 'selected_students', 'specific_batch', 'specific_course')),
  order_index INTEGER DEFAULT 0,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Courses table
CREATE TABLE IF NOT EXISTS public.courses (
  id TEXT PRIMARY KEY,
  title_bn TEXT NOT NULL,
  title_en TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  category TEXT NOT NULL CHECK (category IN ('complete', 'preliminary', 'written', 'subject_wise')),
  description TEXT,
  thumbnail_url TEXT,
  subject_ids TEXT[] DEFAULT '{}',
  duration_weeks INTEGER DEFAULT 16,
  regular_price_bdt NUMERIC NOT NULL,
  promotional_price_bdt NUMERIC,
  start_date DATE,
  end_date DATE,
  enrollment_status TEXT DEFAULT 'open' CHECK (enrollment_status IN ('open', 'closed', 'upcoming')),
  features JSONB DEFAULT '[]'::jsonb,
  access_days INTEGER DEFAULT 365,
  is_published BOOLEAN DEFAULT true,
  is_featured BOOLEAN DEFAULT false,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Batches table
CREATE TABLE IF NOT EXISTS public.batches (
  id TEXT PRIMARY KEY,
  course_id TEXT REFERENCES public.courses(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  description TEXT,
  start_date DATE,
  end_date DATE,
  max_students INTEGER DEFAULT 100,
  is_active BOOLEAN DEFAULT true,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Enrollments table
CREATE TABLE IF NOT EXISTS public.enrollments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  course_id TEXT REFERENCES public.courses(id) ON DELETE CASCADE,
  batch_id TEXT REFERENCES public.batches(id) ON DELETE SET NULL,
  status TEXT DEFAULT 'active' CHECK (status IN ('active', 'expired', 'revoked', 'pending')),
  start_date TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()),
  expires_at TIMESTAMPTZ NOT NULL,
  granted_by UUID REFERENCES public.profiles(id),
  payment_id TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Granular permissions table
CREATE TABLE IF NOT EXISTS public.student_permissions (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  entity_type TEXT NOT NULL CHECK (entity_type IN ('course', 'subject', 'chapter', 'lecture')),
  entity_id TEXT NOT NULL,
  is_granted BOOLEAN DEFAULT true,
  granted_by UUID REFERENCES public.profiles(id),
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Student progress table
CREATE TABLE IF NOT EXISTS public.student_progress (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID REFERENCES public.profiles(id) ON DELETE CASCADE,
  lecture_id TEXT REFERENCES public.lectures(id) ON DELETE CASCADE,
  is_completed BOOLEAN DEFAULT false,
  completed_at TIMESTAMPTZ,
  last_opened_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()),
  UNIQUE(user_id, lecture_id)
);

-- Payments table
CREATE TABLE IF NOT EXISTS public.payments (
  id TEXT PRIMARY KEY,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  user_email TEXT NOT NULL,
  course_id TEXT REFERENCES public.courses(id) ON DELETE SET NULL,
  course_title TEXT NOT NULL,
  amount_bdt NUMERIC NOT NULL,
  currency TEXT DEFAULT 'BDT',
  payment_method TEXT NOT NULL,
  transaction_ref TEXT UNIQUE,
  sender_phone TEXT,
  verification_status TEXT DEFAULT 'pending' CHECK (verification_status IN ('pending', 'verified', 'rejected', 'refunded')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()),
  verified_at TIMESTAMPTZ
);

-- WhatsApp inquiries table
CREATE TABLE IF NOT EXISTS public.course_inquiries (
  id TEXT PRIMARY KEY,
  course_id TEXT REFERENCES public.courses(id) ON DELETE SET NULL,
  course_title TEXT NOT NULL,
  user_id UUID REFERENCES public.profiles(id) ON DELETE SET NULL,
  contact_name TEXT NOT NULL,
  contact_phone TEXT NOT NULL,
  user_email TEXT,
  message TEXT NOT NULL,
  status TEXT DEFAULT 'new' CHECK (status IN ('new', 'contacted', 'awaiting_payment', 'payment_confirmed', 'access_granted', 'closed')),
  admin_notes TEXT,
  created_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW()),
  updated_at TIMESTAMPTZ DEFAULT TIMEZONE('utc', NOW())
);

-- Row Level Security (RLS) Policies
ALTER TABLE public.profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.subjects ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.chapters ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.lectures ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.batches ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.enrollments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_permissions ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.student_progress ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.payments ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.course_inquiries ENABLE ROW LEVEL SECURITY;

-- Public read access
CREATE POLICY "Public read published subjects" ON public.subjects FOR SELECT USING (is_published = true);
CREATE POLICY "Public read published chapters" ON public.chapters FOR SELECT USING (is_published = true);
CREATE POLICY "Public read published courses" ON public.courses FOR SELECT USING (is_published = true);
CREATE POLICY "Public read free preview lectures" ON public.lectures FOR SELECT USING (is_free_preview = true OR access_type = 'public');

-- Student read access to own progress and enrollments
CREATE POLICY "Users read own progress" ON public.student_progress FOR ALL USING (auth.uid() = user_id);
CREATE POLICY "Users read own enrollments" ON public.enrollments FOR SELECT USING (auth.uid() = user_id);

-- Super admin policies
CREATE POLICY "Super admin manage all profiles" ON public.profiles FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'super_admin')
);
CREATE POLICY "Super admin manage all subjects" ON public.subjects FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'super_admin')
);
CREATE POLICY "Super admin manage all lectures" ON public.lectures FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'super_admin')
);
CREATE POLICY "Super admin manage all courses" ON public.courses FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'super_admin')
);
CREATE POLICY "Super admin manage all enrollments" ON public.enrollments FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'super_admin')
);
CREATE POLICY "Super admin manage all payments" ON public.payments FOR ALL USING (
  EXISTS (SELECT 1 FROM public.profiles WHERE id = auth.uid() AND role = 'super_admin')
);
